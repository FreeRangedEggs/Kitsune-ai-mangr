#!/usr/bin/env bash
# if this got started by another shell (sh/dash/zsh), re-exec under bash.
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi
# ============================================================
# ViMoon extension uninstaller - undoes install.sh completely:
#   - stops the editor server
#   - removes the injected launcher block from kitsune's index.html
#     (falls back to restoring index.html.vimoon-bak if markers are gone)
#   - removes vimoon/ and vimoon.sh
#
#   bash uninstall.sh [--dir /path/to/kitsune] [--yes] [--clean]
#     --yes    no questions (scripted use)
#     --clean  also delete the index.html.vimoon-bak backup
# ============================================================
SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET=""
ASSUME_YES=0
CLEAN=0

while [ $# -gt 0 ]; do
  case "$1" in
    --dir)   TARGET="${2:-}"; shift 2 ;;
    --yes)   ASSUME_YES=1; shift ;;
    --clean) CLEAN=1; shift ;;
    -h|--help) sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1 (try --help)"; exit 1 ;;
  esac
done

say() { printf '[vimoon] %s\n' "$1"; }

if [ -z "$TARGET" ]; then
  for c in "$PWD" "$SELF_DIR" "$SELF_DIR/.."; do
    if [ -f "$c/index.html" ] && { [ -d "$c/vimoon" ] || [ -f "$c/vimoon.sh" ]; }; then
      TARGET="$(cd "$c" && pwd)"; break
    fi
  done
fi
if [ -z "$TARGET" ]; then
  TARGET="$SELF_DIR"
fi
if [ ! -f "$TARGET/index.html" ] && [ ! -d "$TARGET/vimoon" ]; then
  printf '[vimoon] ERROR: nothing that looks like a ViMoon install in %s\n' "$TARGET"
  exit 1
fi

say "kitsune folder: $TARGET"

# ---------- 1. stop the server ----------
if [ -f "$TARGET/vimoon.sh" ]; then
  bash "$TARGET/vimoon.sh" stop >/dev/null 2>&1 || true
fi
[ -f "$TARGET/.vimoon.pid" ] && rm -f "$TARGET/.vimoon.pid"

# ---------- 2. remove the injected launcher ----------
INDEX="$TARGET/index.html"
if [ -f "$INDEX" ] && grep -q "ViMoon extension v" "$INDEX" 2>/dev/null; then
  python3 - "$INDEX" <<'PYEOF'
import io, sys
path = sys.argv[1]
src = io.open(path, encoding="utf-8").read()
begin = src.find("<!-- ViMoon extension v")
endmark = "<!-- /ViMoon extension -->"
end = src.find(endmark)
if begin != -1 and end != -1 and end > begin:
    io.open(path, "w", encoding="utf-8").write(src[:begin] + src[end + len(endmark):])
    print("[vimoon] launcher block removed from index.html")
else:
    print("[vimoon] markers not found in index.html - nothing removed")
PYEOF
elif [ -f "$INDEX.vimoon-bak" ]; then
  cp "$INDEX.vimoon-bak" "$INDEX"
  say "restored index.html from index.html.vimoon-bak"
else
  say "no injected launcher found in index.html - nothing to do"
fi
[ "$CLEAN" = "1" ] && [ -f "$INDEX.vimoon-bak" ] && rm -f "$INDEX.vimoon-bak"

# ---------- 2b. restore server.py if the CSP was widened ----------
SRV="$TARGET/server.py"
if [ -f "$SRV.vimoon-bak" ]; then
  if grep -q "localhost:8790" "$SRV" 2>/dev/null; then
    cp "$SRV.vimoon-bak" "$SRV"
    say "server.py restored from server.py.vimoon-bak (CSP back to stock - restart kitsune once)"
  fi
  if [ "$CLEAN" = "1" ]; then rm -f "$SRV.vimoon-bak"; fi
elif grep -q "localhost:8790" "$SRV" 2>/dev/null; then
  python3 - "$SRV" <<'PYEOF'
import io, sys
path = sys.argv[1]
src = io.open(path, encoding="utf-8").read()
src = src.replace(" http://localhost:8790 http://127.0.0.1:8790", "")
io.open(path, "w", encoding="utf-8").write(src)
print("[vimoon] removed the ViMoon origins from the CSP - restart kitsune once")
PYEOF
fi

# ---------- 3. ask, then remove the app folder ----------
if [ "$ASSUME_YES" != "1" ]; then
  printf '[vimoon] remove %s/vimoon and %s/vimoon.sh? [y/N] ' "$TARGET" "$TARGET"
  read -r ans
  case "$ans" in
    y|Y|yes|YES) ASSUME_YES=1 ;;
    *) say "kept the editor folder - only the kitsune integration was removed." ;;
  esac
fi

if [ "$ASSUME_YES" = "1" ]; then
  rm -rf "$TARGET/vimoon"
  rm -f "$TARGET/vimoon.sh" "$TARGET/vimoon.log"
  say "removed vimoon/ and vimoon.sh. the moon sets - bye."
else
  say "the editor is still available manually at $TARGET/vimoon (python3 vimoon/moon_server.py)."
fi
say "done."
