#!/usr/bin/env python3
# ============================================================
# ViMoon extension server  -  a moonlit code editor for
# kitsune//ai-mangr.  ONE plain python3 file, ZERO dependencies
# (same rule as kitsune's own server.py: no pip, no venv).
#
#   run:   python3 moon_server.py            (or: bash ../vimoon.sh)
#   port:  8790   (env VIMOON_PORT to change)
#   bind:  127.0.0.1 (this pc only); --lan or VIMOON_LAN=1 opens it
#          to the network - do that only with kitsune's own lan switch
#          on and a pin set, and never behind the kitsune https tunnel
#          (an http iframe inside an https page is blocked by design).
#
# workspace: the folder ViMoon edits. resolution order:
#   1. env VIMOON_WORKSPACE
#   2. "workspace" key in data/settings.json (the installer writes it
#      pointing at the kitsune folder, so bot .ai files, knowledge
#      files, config/*.conf and your own code are all in one tree)
#   3. <vimoon>/data/workspace (standalone default)
#
# ollama:  http://localhost:11434  (env OLLAMA_URL, or the MoonBot
#          settings in the UI - same precedence as the Flask original)
#
# api:     exactly the contract the ViMoon frontend already speaks:
#          /api/files/*  /api/search  /api/settings  /api/git/*
#          /api/ollama/*  /api/plugins  + static frontend/
# ============================================================

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

VERSION = "1.0.0"
PORT = int(os.environ.get("VIMOON_PORT", "8790"))
HOST = "127.0.0.1"

ROOT = os.path.dirname(os.path.abspath(__file__))            # .../vimoon
FRONTEND_DIR = os.path.join(ROOT, "frontend")
PLUGINS_DIR = os.path.join(ROOT, "plugins")
DATA_DIR = os.path.abspath(os.environ.get("VIMOON_DATA")
                           or os.path.join(ROOT, "data"))
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")

OLLAMA_URL = os.environ.get("OLLAMA_URL", "").rstrip("/")    # empty = settings decide
EDIT_HARD_LIMIT = 8 * 1024 * 1024                            # never open past 8 MB
MAX_BODY = 64 * 1024 * 1024

_settings_lock = threading.Lock()

SKIP_DIRS = {
    ".git", ".svn", ".hg", "node_modules", "__pycache__", ".venv", "venv",
    ".idea", ".vscode", ".mypy_cache", ".pytest_cache", "dist", "build",
}
BINARY_EXTS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".tiff", ".pdf",
    ".zip", ".gz", ".tgz", ".bz2", ".xz", ".tar", ".rar", ".7z", ".exe", ".dll",
    ".so", ".dylib", ".bin", ".o", ".a", ".class", ".jar", ".pyc", ".pyo",
    ".wasm", ".mp3", ".mp4", ".avi", ".mov", ".mkv", ".wav", ".ogg", ".flac",
    ".woff", ".woff2", ".ttf", ".otf", ".eot", ".db", ".sqlite", ".sqlite3",
}
MIME = {
    ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
    ".mjs": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp",
    ".ico": "image/x-icon", ".txt": "text/plain; charset=utf-8",
    ".md": "text/plain; charset=utf-8", ".map": "application/json",
    ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf",
    ".mp4": "video/mp4", ".webm": "video/webm", ".py": "text/plain; charset=utf-8",
}

DEFAULT_SETTINGS = {
    "theme": "moonlight",                       # moonlight | dark | dawn
    "font_size": 14,
    "font_family": "'Cascadia Code','JetBrains Mono','Fira Code','SF Mono',Consolas,monospace",
    "ui_font_family": "Inter,'Segoe UI',system-ui,-apple-system,sans-serif",
    "line_numbers": True,
    "word_wrap": False,
    "vim_mode": True,
    "auto_save": True,
    "tab_size": 4,
    "indent_with_tabs": False,
    "bracket_close": True,
    "auto_completion": True,
    "highlight_active_line": True,
    "code_folding": True,
    "ollama_url": "http://localhost:11434",
    "ollama_model": "",
    "large_file_limit_kb": 2048,
    "enabled_plugins": {},
    "ui": {"open_tabs": [], "active": "", "recent": []},
}

# settings keys a client may write -> expected python type
_WRITABLE = {
    "theme": str, "font_size": int, "font_family": str, "ui_font_family": str,
    "line_numbers": bool, "word_wrap": bool, "vim_mode": bool, "auto_save": bool,
    "tab_size": int, "indent_with_tabs": bool, "bracket_close": bool,
    "auto_completion": bool, "highlight_active_line": bool, "code_folding": bool,
    "ollama_url": str, "ollama_model": str, "large_file_limit_kb": int,
    "workspace": str,
}

SYSTEM_PROMPT = (
    "You are MoonBot, a concise coding assistant living inside the ViMoon editor. "
    "Answer with short, correct, actionable advice. Use fenced code blocks for code. "
    "Respond in the user's language."
)

# ------------------------------------------------------------
# workspace + settings
# ------------------------------------------------------------

def _read_settings_file(path, cfg):
    """Merge one settings.json into cfg (dict values like ui merge deep)."""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            stored = json.load(fh)
    except (OSError, ValueError):
        return cfg
    if not isinstance(stored, dict):
        return cfg
    for key, value in stored.items():
        if key == "ui" and isinstance(value, dict):
            cfg["ui"].update(value)
        else:
            cfg[key] = value
    return cfg


def load_settings():
    """defaults <- <vimoon>/settings.json (installer-written, wins) <- data/settings.json"""
    cfg = dict(DEFAULT_SETTINGS)
    cfg["ui"] = dict(DEFAULT_SETTINGS["ui"])
    cfg = _read_settings_file(os.path.join(ROOT, "settings.json"), cfg)
    cfg = _read_settings_file(SETTINGS_PATH, cfg)
    return cfg


def save_settings(cfg):
    with _settings_lock:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = SETTINGS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2, ensure_ascii=False)
        os.replace(tmp, SETTINGS_PATH)


def workspace():
    """The folder ViMoon edits, resolved per request (see module header).
    1. env VIMOON_WORKSPACE
    2. "workspace" key in settings.json (must exist)
    3. auto: the kitsune folder - when vimoon/ sits next to server.py,
       that folder is obviously the workspace (zero-config portable install)
    4. standalone default: <vimoon>/data/workspace
    """
    env = os.environ.get("VIMOON_WORKSPACE")
    if env:
        return os.path.abspath(env)
    cfg = load_settings()
    ws = str(cfg.get("workspace") or "").strip()
    if ws:
        return os.path.abspath(os.path.expanduser(ws))
    parent = os.path.dirname(ROOT)
    if os.path.isfile(os.path.join(parent, "server.py")):
        return parent
    return os.path.join(DATA_DIR, "workspace")


def ensure_dirs():
    os.makedirs(workspace(), exist_ok=True)
    os.makedirs(DATA_DIR, exist_ok=True)


def safe_join(rel_path):
    """Resolve rel_path inside the workspace; ValueError on traversal."""
    ws = os.path.realpath(workspace())
    rel = (rel_path or "").strip().replace("\\", "/").lstrip("/")
    if rel in ("", ".", "/"):
        return ws
    target = os.path.realpath(os.path.join(ws, rel))
    if target != ws and not target.startswith(ws + os.sep):
        raise ValueError("Path escapes the workspace: %r" % rel_path)
    return target


def to_rel(abs_path):
    return os.path.relpath(abs_path, workspace()).replace("\\", "/")


def is_binary_file(path):
    if os.path.splitext(path)[1].lower() in BINARY_EXTS:
        return True
    try:
        with open(path, "rb") as fh:
            return b"\x00" in fh.read(8192)
    except OSError:
        return True


def _fmt(num):
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return "%.1f %s" % (num, unit)
        num /= 1024.0

# ------------------------------------------------------------
# git helpers
# ------------------------------------------------------------

class GitError(Exception):
    pass


def _git(args, timeout=25):
    try:
        proc = subprocess.run(
            ["git"] + args, cwd=workspace(), capture_output=True, text=True,
            timeout=timeout)
    except FileNotFoundError:
        raise GitError("Git is not installed on this machine")
    except subprocess.TimeoutExpired:
        raise GitError("Git command timed out")
    if proc.returncode != 0:
        raise GitError((proc.stderr or proc.stdout or "git failed").strip())
    return proc.stdout


def _is_repo():
    try:
        top = os.path.realpath(_git(["rev-parse", "--show-toplevel"]).strip())
        return top == os.path.realpath(workspace())
    except GitError:
        return False


def _parse_status():
    out = _git(["status", "--porcelain=v1", "-b"])
    branch, ahead, behind = None, 0, 0
    staged, unstaged, untracked = [], [], []
    for i, line in enumerate(out.splitlines()):
        if i == 0 and line.startswith("## "):
            info = line[3:]
            if info.startswith("No commits yet on "):
                branch = info.replace("No commits yet on ", "")
            else:
                branch = info.split("...")[0].strip() or "HEAD"
                if "[ahead " in info:
                    try:
                        ahead = int(info.split("[ahead ")[1].split("]")[0].split(",")[0])
                    except (ValueError, IndexError):
                        pass
                if "[behind " in info:
                    try:
                        behind = int(info.split("[behind ")[1].split("]")[0].split(",")[0])
                    except (ValueError, IndexError):
                        pass
            continue
        if len(line) < 4:
            continue
        xy, path = line[:2], line[3:]
        entry = {"x": xy[0], "y": xy[1], "path": path}
        if " -> " in path:
            entry["orig_path"] = path.split(" -> ")[0]
            entry["path"] = path.split(" -> ")[1]
        if xy.startswith("??"):
            untracked.append(entry)
        else:
            if xy[0] not in (" ", "?"):
                staged.append(entry)
            if xy[1] not in (" ", "?"):
                unstaged.append(entry)
    return {"repo": True, "branch": branch or "HEAD", "ahead": ahead,
            "behind": behind, "staged": staged, "unstaged": unstaged,
            "untracked": untracked}

# ------------------------------------------------------------
# ollama helpers (plain urllib - no requests, no flask)
# ------------------------------------------------------------

def ollama_base():
    if OLLAMA_URL:
        return OLLAMA_URL
    return (load_settings().get("ollama_url") or "http://localhost:11434").rstrip("/")


def ollama_model(preferred=None):
    if preferred:
        return preferred
    configured = load_settings().get("ollama_model")
    if configured:
        return configured
    try:
        with urllib.request.urlopen(ollama_base() + "/api/tags", timeout=3) as r:
            models = json.loads(r.read().decode()).get("models") or []
        if models:
            return models[0].get("model") or models[0].get("name")
    except Exception:
        pass
    return "llama3.2"


def _ollama_request(path, payload, timeout):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        ollama_base() + path, data=data,
        headers={"Content-Type": "application/json"})
    return urllib.request.urlopen(req, timeout=timeout)

# ------------------------------------------------------------
# file api implementations (same contract as the Flask original)
# ------------------------------------------------------------

def api_files_tree(qs):
    ensure_dirs()
    ws = os.path.realpath(workspace())
    if (qs.get("recursive") or [""])[0] in ("1", "true"):
        collected = []
        for dirpath, dirnames, filenames in os.walk(ws):
            dirnames[:] = [d for d in sorted(dirnames)
                           if d not in SKIP_DIRS and not d.startswith(".")]
            for fname in sorted(filenames):
                if fname.startswith(".git"):
                    continue
                collected.append(to_rel(os.path.join(dirpath, fname)))
                if len(collected) >= 5000:
                    return 200, {"files": collected, "truncated": True}
        return 200, {"files": collected, "truncated": False}

    try:
        target = safe_join((qs.get("path") or [""])[0])
    except ValueError as exc:
        return 400, {"error": str(exc)}
    if not os.path.isdir(target):
        return 404, {"error": "Not a directory"}
    try:
        names = os.listdir(target)
    except OSError as exc:
        return 500, {"error": str(exc)}
    entries = []
    for name in names:
        if name == ".git" or name in SKIP_DIRS:
            continue
        full = os.path.join(target, name)
        try:
            st = os.stat(full)
        except OSError:
            continue
        entries.append({
            "name": name, "path": to_rel(full),
            "type": "dir" if os.path.isdir(full) else "file",
            "size": st.st_size if os.path.isfile(full) else None,
            "mtime": int(st.st_mtime),
        })
    entries.sort(key=lambda e: (e["type"] != "dir", e["name"].lower()))
    return 200, {"path": to_rel(target), "entries": entries}


def api_files_open(body):
    ensure_dirs()
    rel = body.get("path", "")
    force = bool(body.get("force"))
    try:
        target = safe_join(rel)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    if not os.path.isfile(target):
        return 404, {"error": "File not found: %s" % rel}
    size = os.path.getsize(target)
    limit = int(load_settings().get("large_file_limit_kb", 2048)) * 1024
    if size > EDIT_HARD_LIMIT:
        return 413, {"error": "File is too large to open (%s)." % _fmt(size),
                     "size": size}
    if size > limit and not force:
        return 413, {"error": "Large file (%s) - open read-only?" % _fmt(size),
                     "size": size, "confirm": True}
    if is_binary_file(target):
        return 415, {"error": "Binary files cannot be edited in ViMoon",
                     "binary": True}
    try:
        with open(target, "r", encoding="utf-8") as fh:
            content = fh.read()
        encoding = "utf-8"
    except UnicodeDecodeError:
        try:
            with open(target, "r", encoding="latin-1") as fh:
                content = fh.read()
            encoding = "latin-1"
        except OSError as exc:
            return 500, {"error": str(exc)}
    except OSError as exc:
        return 500, {"error": str(exc)}
    return 200, {"path": to_rel(target), "name": os.path.basename(target),
                 "content": content, "size": size,
                 "mtime": int(os.path.getmtime(target)), "encoding": encoding,
                 "readonly": size > limit}


def api_files_save(body):
    rel = body.get("path", "")
    content = body.get("content")
    if content is None:
        return 400, {"error": "Missing content"}
    try:
        target = safe_join(rel)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    try:
        os.makedirs(os.path.dirname(target), exist_ok=True)
        tmp = target + ".vimoon-tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            fh.write(content)
        os.replace(tmp, target)
    except OSError as exc:
        return 500, {"error": str(exc)}
    return 200, {"path": to_rel(target), "size": os.path.getsize(target),
                 "mtime": int(os.path.getmtime(target))}


def api_files_create(body):
    ensure_dirs()
    rel = body.get("path", "")
    kind = body.get("type", "file")
    try:
        target = safe_join(rel)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    if rel in ("", "."):
        return 400, {"error": "Invalid name"}
    if os.path.exists(target):
        return 409, {"error": "Already exists: %s" % rel}
    try:
        if kind == "dir":
            os.makedirs(target, exist_ok=True)
        else:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, "w", encoding="utf-8") as fh:
                fh.write(body.get("content", ""))
    except OSError as exc:
        return 500, {"error": str(exc)}
    return 200, {"ok": True, "path": to_rel(target)}


def api_files_rename(body):
    try:
        src = safe_join(body.get("path", ""))
        dst = safe_join(body.get("new_path", ""))
    except ValueError as exc:
        return 400, {"error": str(exc)}
    if not os.path.exists(src):
        return 404, {"error": "Not found"}
    if os.path.exists(dst):
        return 409, {"error": "Target already exists"}
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        os.rename(src, dst)
    except OSError as exc:
        return 500, {"error": str(exc)}
    return 200, {"ok": True, "path": to_rel(dst)}


def api_files_delete(body):
    try:
        target = safe_join(body.get("path", ""))
    except ValueError as exc:
        return 400, {"error": str(exc)}
    if target == os.path.realpath(workspace()):
        return 400, {"error": "Refusing to delete the workspace root"}
    if not os.path.exists(target):
        return 404, {"error": "Not found"}
    try:
        if os.path.isdir(target):
            shutil.rmtree(target)
        else:
            os.remove(target)
    except OSError as exc:
        return 500, {"error": str(exc)}
    return 200, {"ok": True}


def api_files_meta():
    ensure_dirs()
    count = sum(len(files) for _, _, files in os.walk(workspace()))
    return 200, {"workspace": workspace(), "file_count": count}

# ------------------------------------------------------------
# search api
# ------------------------------------------------------------

MAX_FILE_SCAN = 512 * 1024
MAX_MATCHES_PER_FILE = 60
MAX_RESULTS_TOTAL = 800


def api_search(body):
    ensure_dirs()
    query = body.get("query", "")
    if not query:
        return 200, {"results": [], "files_searched": 0, "truncated": False}
    case_sensitive = bool(body.get("case_sensitive"))
    use_regex = bool(body.get("regex"))
    ext = (body.get("ext") or "").lower().strip()
    if ext and not ext.startswith("."):
        ext = "." + ext
    flags = 0 if case_sensitive else re.IGNORECASE
    if use_regex:
        try:
            matcher = re.compile(query, flags)
        except re.error as exc:
            return 400, {"error": "Invalid regex: %s" % exc}

        def find(line):
            return matcher.search(line)
    else:
        needle = query if case_sensitive else query.lower()

        def find(line):
            haystack = line if case_sensitive else line.lower()
            idx = haystack.find(needle)
            if idx == -1:
                return None
            return type("M", (), {"start": lambda self: idx})()

    started = time.time()
    results, files_searched, total = [], 0, 0
    truncated = False
    ws = os.path.realpath(workspace())
    for dirpath, dirnames, filenames in os.walk(ws):
        dirnames[:] = [d for d in sorted(dirnames)
                       if d not in SKIP_DIRS and not d.startswith(".")]
        for fname in sorted(filenames):
            if fname.startswith(".git"):
                continue
            if ext and os.path.splitext(fname)[1].lower() != ext:
                continue
            full = os.path.join(dirpath, fname)
            if os.path.splitext(fname)[1].lower() in BINARY_EXTS:
                continue
            try:
                if os.path.getsize(full) > MAX_FILE_SCAN:
                    continue
                with open(full, "rb") as fh:
                    if b"\x00" in fh.read(4096):
                        continue
                with open(full, "r", encoding="utf-8", errors="replace") as fh:
                    lines = fh.readlines()
            except OSError:
                continue
            files_searched += 1
            file_matches = []
            for lineno, raw in enumerate(lines, start=1):
                m = find(raw.rstrip("\r\n"))
                if m:
                    text = raw.rstrip("\r\n")[:240]
                    file_matches.append({"line": lineno, "col": m.start(),
                                         "text": text})
                    total += 1
                    if total >= MAX_RESULTS_TOTAL:
                        truncated = True
                        break
                if len(file_matches) >= MAX_MATCHES_PER_FILE:
                    break
            if file_matches:
                results.append({
                    "path": os.path.relpath(full, ws).replace("\\", "/"),
                    "matches": file_matches})
            if truncated:
                break
        if truncated:
            break
    return 200, {"query": query, "results": results,
                 "files_searched": files_searched, "matches": total,
                 "truncated": truncated,
                 "duration_ms": int((time.time() - started) * 1000)}

# ------------------------------------------------------------
# settings api
# ------------------------------------------------------------

def api_settings_get():
    return 200, load_settings()


def api_settings_put(body):
    cfg = load_settings()
    for key, value in body.items():
        if key == "enabled_plugins" and isinstance(value, dict):
            cfg["enabled_plugins"] = {str(k): bool(v) for k, v in value.items()}
            continue
        if key == "ui":
            if isinstance(value, dict):
                ui = cfg.setdefault("ui", dict(DEFAULT_SETTINGS["ui"]))
                for ui_key in ("open_tabs", "active", "recent"):
                    if ui_key in value:
                        ui[ui_key] = value[ui_key]
            continue
        expected = _WRITABLE.get(key)
        if expected is None:
            continue
        if expected is int and isinstance(value, bool):
            continue
        if isinstance(value, expected):
            if key == "font_size":
                value = max(9, min(32, int(value)))
            if key == "tab_size":
                value = max(1, min(16, int(value)))
            cfg[key] = value
    save_settings(cfg)
    return 200, load_settings()

# ------------------------------------------------------------
# git api
# ------------------------------------------------------------

def api_git_status():
    ensure_dirs()
    if not _is_repo():
        return 200, {"repo": False, "workspace": workspace()}
    try:
        data = _parse_status()
    except GitError as exc:
        return 500, {"error": str(exc)}
    data["workspace"] = workspace()
    return 200, data


def api_git_action(body):
    kind = body.get("action")
    paths = body.get("paths") or []
    if not paths:
        return 400, {"error": "No paths given"}
    try:
        if kind == "stage":
            _git(["add", "--"] + paths)
        elif kind == "unstage":
            try:
                _git(["reset", "-q", "HEAD", "--"] + paths)
            except GitError:
                _git(["rm", "--cached", "-q", "--"] + paths)
        elif kind == "discard":
            _git(["checkout", "-q", "--"] + paths)
        else:
            return 400, {"error": "Unknown action: %s" % kind}
    except GitError as exc:
        return 500, {"error": str(exc)}
    return 200, {"ok": True}


def api_git_commit(body):
    message = (body.get("message") or "").strip()
    if not message:
        return 400, {"error": "Commit message is empty"}
    try:
        if body.get("stage_all"):
            _git(["add", "-A"])
        out = _git(["commit", "-m", message])
    except GitError as exc:
        text = str(exc)
        friendly = ("nothing to commit" in text or "no changes added" in text)
        return 400, {"error": "Nothing to commit" if friendly else text,
                     "friendly": friendly}
    return 200, {"ok": True, "output": out.strip()}


def api_git_log(qs):
    if not _is_repo():
        return 200, {"repo": False, "commits": []}
    try:
        limit = min(int((qs.get("limit") or ["100"])[0]), 500)
    except ValueError:
        limit = 100
    try:
        out = _git(["log", "-n", str(limit), "--date=iso",
                    "--pretty=format:%H%x09%h%x09%an%x09%aI%x09%s%x09%D"])
    except GitError as exc:
        if "does not have any commits yet" in str(exc):
            return 200, {"repo": True, "commits": []}
        return 500, {"error": str(exc)}
    commits = []
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) >= 5:
            commits.append({"hash": parts[0], "short": parts[1],
                            "author": parts[2], "date": parts[3],
                            "message": parts[4],
                            "refs": parts[5] if len(parts) > 5 else ""})
    return 200, {"repo": True, "commits": commits}


def api_git_diff(qs):
    if not _is_repo():
        return 200, {"repo": False, "diff": ""}
    args = ["diff", "--no-color"]
    if (qs.get("staged") or [""])[0] in ("1", "true"):
        args.append("--cached")
    path = (qs.get("path") or [""])[0]
    if path:
        args += ["--", path]
    try:
        return 200, {"repo": True, "diff": _git(args)}
    except GitError as exc:
        return 500, {"error": str(exc)}


def api_git_show(qs):
    commit_hash = (qs.get("hash") or ["HEAD"])[0].strip()
    if not all(c.isalnum() for c in commit_hash.replace("-", "")):
        return 400, {"error": "Invalid hash"}
    try:
        out = _git(["show", "--no-color", "--stat", "--patch",
                    "--format=commit %H%nAuthor: %an <%ae>%nDate: %aI%n%n    %s",
                    commit_hash])
    except GitError as exc:
        return 500, {"error": str(exc)}
    return 200, {"diff": out}


def api_git_branches():
    if not _is_repo():
        return 200, {"repo": False, "branches": [], "current": None}
    try:
        current = _git(["rev-parse", "--abbrev-ref", "HEAD"]).strip()
        out = _git(["for-each-ref", "--format=%(refname:short)", "refs/heads/"])
        branch_list = [b for b in out.splitlines() if b.strip()]
    except GitError as exc:
        return 500, {"error": str(exc)}
    return 200, {"repo": True, "current": current, "branches": branch_list}


def api_git_checkout(body):
    branch = (body.get("branch") or "").strip()
    if not branch or any(c in branch for c in " \t;|&$><`\\\"'"):
        return 400, {"error": "Invalid branch name"}
    try:
        args = ["checkout", "-q"]
        if body.get("create"):
            args += ["-b"]
        args.append(branch)
        _git(args)
    except GitError as exc:
        return 500, {"error": str(exc)}
    return 200, {"ok": True, "branch": branch}


def api_git_init():
    ensure_dirs()
    try:
        out = _git(["init"])
        try:
            if not _git(["config", "user.email"]).strip():
                _git(["config", "user.email", "vimoon@localhost"])
                _git(["config", "user.name", "ViMoon User"])
        except GitError:
            pass
    except GitError as exc:
        return 500, {"error": str(exc)}
    return 200, {"ok": True, "output": out.strip()}

# ------------------------------------------------------------
# ollama api
# ------------------------------------------------------------

def _ollama_error(exc):
    if isinstance(exc, urllib.error.URLError):
        return 502, {
            "error": "Ollama is not reachable at %s" % ollama_base(),
            "hint": "Install Ollama (https://ollama.com), run `ollama serve`, "
                    "pull a model (e.g. `ollama pull llama3.2`), then set the "
                    "URL under Settings > MoonBot. You can also start "
                    "mock_ollama.py to try the UI without Ollama."}
    return 500, {"error": str(exc)}


def api_ollama_status():
    url = ollama_base()
    try:
        with urllib.request.urlopen(url + "/api/tags", timeout=2.5) as r:
            models = json.loads(r.read().decode()).get("models") or []
        names = [m.get("model") or m.get("name") or "" for m in models]
        return 200, {"reachable": True, "url": url, "models": names,
                     "default_model": load_settings().get("ollama_model") or ""}
    except Exception as exc:
        return 200, {"reachable": False, "url": url, "error": str(exc)}


def api_plugins_list():
    found = []
    if os.path.isdir(PLUGINS_DIR):
        for name in sorted(os.listdir(PLUGINS_DIR)):
            if not re.match(r"^[a-z0-9][a-z0-9_-]*$", name):
                continue
            manifest_path = os.path.join(PLUGINS_DIR, name, "manifest.json")
            if not os.path.isfile(manifest_path):
                continue
            try:
                with open(manifest_path, "r", encoding="utf-8") as fh:
                    m = json.load(fh)
            except (OSError, ValueError):
                continue
            main = m.get("main", "main.js")
            found.append({
                "id": name, "name": m.get("name", name),
                "version": m.get("version", "0.0.0"),
                "description": m.get("description", ""),
                "author": m.get("author", "unknown"), "main": main,
                "installed": os.path.isfile(os.path.join(PLUGINS_DIR, name, main))})
    enabled = load_settings().get("enabled_plugins", {})
    for p in found:
        p["enabled"] = bool(enabled.get(p["id"], True))
    return 200, {"plugins": found, "directory": PLUGINS_DIR}


def api_plugins_toggle(body):
    pid = body.get("id", "")
    if not re.match(r"^[a-z0-9][a-z0-9_-]*$", pid):
        return 400, {"error": "Invalid plugin id"}
    if pid not in {p["id"] for p in api_plugins_list()[1]["plugins"]}:
        return 404, {"error": "Unknown plugin"}
    cfg = load_settings()
    state = cfg.setdefault("enabled_plugins", {})
    state[pid] = bool(body.get("enabled", True))
    save_settings(cfg)
    return 200, {"ok": True, "id": pid, "enabled": state[pid]}

# ------------------------------------------------------------
# http handler: routing + static + streaming
# ------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    server_version = "ViMoon/" + VERSION
    protocol_version = "HTTP/1.1"

    # ---- plumbing ----
    def log_message(self, fmt, *args):     # quiet, kitsune-style one-liner
        sys.stderr.write("[vimoon] %s\n" % (fmt % args))

    def _cors_allow(self):
        """Echo the Origin header only when it points at THIS machine
        (same hostname as our Host header, any port) - the kitsune page
        on :8788 probes /api/health cross-origin, but a random website
        in your browser must not be able to read the local editor api."""
        origin = self.headers.get("Origin")
        if not origin:
            return None
        try:
            o = urllib.parse.urlsplit(origin)
            host_header = self.headers.get("Host", "")
            hhost = urllib.parse.urlsplit("//" + host_header).hostname or ""
            return (o.hostname or "") == hhost or o.hostname in ("localhost", "127.0.0.1")
        except Exception:
            return False

    def _cors_headers(self):
        if self._cors_allow():
            origin = self.headers.get("Origin")
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")

    def _send_json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self._cors_headers()
        self.end_headers()
        self.wfile.write(data)

    def _read_body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            return {}
        raw = self.rfile.read(length)
        try:
            obj = json.loads(raw.decode("utf-8"))
            return obj if isinstance(obj, dict) else {}
        except (ValueError, UnicodeDecodeError):
            return {}

    def _origin_ok(self):
        """Mirror kitsune's rule: state-changing requests must come from
        the app's own origin, so other websites can't drive the API."""
        if self.command in ("GET", "HEAD"):
            return True
        origin = self.headers.get("Origin")
        if not origin:
            return True                     # curl / same-origin form posts
        host = self.headers.get("Host", "")
        try:
            return urllib.parse.urlsplit(origin).netloc == host
        except Exception:
            return False

    def _serve_file(self, path, attachment=False):
        if not os.path.isfile(path):
            return self._send_json({"error": "Not found"}, 404)
        ctype = MIME.get(os.path.splitext(path)[1].lower(),
                         "application/octet-stream")
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except OSError:
            return self._send_json({"error": "Unreadable"}, 500)
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if attachment:
            self.send_header("Content-Disposition",
                             "attachment; filename=\"%s\"" % os.path.basename(path))
        else:
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self._cors_headers()
        self.end_headers()
        self.wfile.write(data)

    def _serve_frontend(self, asset):
        full = os.path.realpath(os.path.join(FRONTEND_DIR, asset))
        root = os.path.realpath(FRONTEND_DIR)
        if full != root and not full.startswith(root + os.sep):
            return self._send_json({"error": "Not found"}, 404)
        self._serve_file(full)

    # ---- methods ----
    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")

    def do_PUT(self):
        self._route("PUT")

    def do_HEAD(self):
        self._route("GET")

    def do_OPTIONS(self):
        """CORS preflight - answer plainly; real gating stays on the
        actual GET/POST handlers."""
        self.send_response(204)
        self._cors_headers()
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _route(self, method):
        path = self.path.split("?")[0]
        qs = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        try:
            if method in ("POST", "PUT") and not self._origin_ok():
                return self._send_json({"error": "Cross-origin request refused"}, 403)
            body = self._read_body() if method in ("POST", "PUT") else {}

            # ---- api: files ----
            if path == "/api/files/tree":
                return self._j(*api_files_tree(qs))
            if path == "/api/files/open" and method == "POST":
                return self._j(*api_files_open(body))
            if path == "/api/files/save" and method == "POST":
                return self._j(*api_files_save(body))
            if path == "/api/files/create" and method == "POST":
                return self._j(*api_files_create(body))
            if path == "/api/files/rename" and method == "POST":
                return self._j(*api_files_rename(body))
            if path == "/api/files/delete" and method == "POST":
                return self._j(*api_files_delete(body))
            if path == "/api/files/download":
                try:
                    target = safe_join((qs.get("path") or [""])[0])
                except ValueError as exc:
                    return self._send_json({"error": str(exc)}, 400)
                return self._serve_file(target, attachment=True)
            if path == "/api/files/meta":
                return self._j(*api_files_meta())

            # ---- api: search / settings ----
            if path == "/api/search" and method == "POST":
                return self._j(*api_search(body))
            if path == "/api/settings" and method in ("GET", "HEAD"):
                return self._j(*api_settings_get())
            if path == "/api/settings" and method == "PUT":
                return self._j(*api_settings_put(body))

            # ---- api: git ----
            if path == "/api/git/status":
                return self._j(*api_git_status())
            if path == "/api/git/action" and method == "POST":
                return self._j(*api_git_action(body))
            if path == "/api/git/commit" and method == "POST":
                return self._j(*api_git_commit(body))
            if path == "/api/git/log":
                return self._j(*api_git_log(qs))
            if path == "/api/git/diff":
                return self._j(*api_git_diff(qs))
            if path == "/api/git/show":
                return self._j(*api_git_show(qs))
            if path == "/api/git/branches":
                return self._j(*api_git_branches())
            if path == "/api/git/checkout" and method == "POST":
                return self._j(*api_git_checkout(body))
            if path == "/api/git/init" and method == "POST":
                return self._j(*api_git_init())

            # ---- api: ollama ----
            if path == "/api/ollama/status":
                return self._j(*api_ollama_status())
            if path == "/api/ollama/chat" and method == "POST":
                return self.handle_ollama_chat(body)
            if path == "/api/ollama/complete" and method == "POST":
                return self.handle_ollama_complete(body)

            # ---- api: plugins ----
            if path == "/api/plugins":
                return self._j(*api_plugins_list())
            if path == "/api/plugins/toggle" and method == "POST":
                return self._j(*api_plugins_toggle(body))

            # ---- api: health ----
            if path == "/api/health":
                ensure_dirs()
                git_ok = shutil.which("git") is not None
                try:
                    with urllib.request.urlopen(ollama_base() + "/api/tags",
                                                timeout=1.5):
                        ollama_ok = True
                except Exception:
                    ollama_ok = False
                return self._send_json({
                    "ok": True, "name": "ViMoon", "version": VERSION,
                    "app": "vimoon-extension",
                    "workspace": workspace(), "data_dir": DATA_DIR,
                    "git": git_ok, "ollama": ollama_ok})

            # ---- static: plugins ----
            m = re.match(r"^/plugins/([a-z0-9][a-z0-9_-]*)/(.+)$", path)
            if m:
                root = os.path.realpath(os.path.join(PLUGINS_DIR, m.group(1)))
                full = os.path.realpath(os.path.join(root, m.group(2)))
                if full != root and not full.startswith(root + os.sep):
                    return self._send_json({"error": "Not found"}, 404)
                return self._serve_file(full)

            # ---- static: frontend ----
            if path in ("/", "/index.html"):
                return self._serve_frontend("index.html")
            if path.startswith("/"):
                return self._serve_frontend(path.lstrip("/"))

            self._send_json({"error": "Not found"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            try:
                self._send_json({"error": "Internal error: %s" % exc}, 500)
            except Exception:
                pass

    def _j(self, code, obj):
        self._send_json(obj, code)

    # ---- ollama chat: SSE stream or plain json ----
    def handle_ollama_chat(self, body):
        messages = body.get("messages") or []
        if not messages:
            return self._send_json({"error": "No messages"}, 400)
        want_stream = bool(body.get("stream", True))
        payload = {
            "model": ollama_model(body.get("model")),
            "messages": messages,
            "stream": want_stream,
            "options": {"temperature": body.get("temperature", 0.4)},
        }
        try:
            resp = _ollama_request("/api/chat", payload, 600)
        except Exception as exc:
            code, obj = _ollama_error(exc)
            return self._send_json(obj, code)

        if not want_stream:
            try:
                data = json.loads(resp.read().decode())
                content = (data.get("message") or {}).get("content", "")
                return self._send_json({"content": content,
                                        "model": payload["model"]})
            except Exception as exc:
                return self._send_json({"error": str(exc)}, 500)
            finally:
                resp.close()

        # stream: re-encode ollama's ndjson as Server-Sent Events,
        # exactly what the flask + requests version did.
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        try:
            for raw in resp:
                line = raw.decode("utf-8", "replace").strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                if obj.get("error"):
                    self._sse({"error": obj["error"]})
                    break
                piece = (obj.get("message") or {}).get("content", "")
                if piece:
                    self._sse({"delta": piece})
                if obj.get("done"):
                    break
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception as exc:
            try:
                self._sse({"error": str(exc)})
            except Exception:
                pass
        finally:
            resp.close()
            try:
                self._sse({"done": True})
            except Exception:
                pass

    def _sse(self, obj):
        self.wfile.write(("data: %s\n\n" % json.dumps(obj)).encode())
        self.wfile.flush()

    # ---- ollama inline completion (Alt-\ ghost text) ----
    def handle_ollama_complete(self, body):
        prefix = (body.get("prefix") or "")[-2000:]
        suffix = (body.get("suffix") or "")[:800]
        try:
            max_tokens = int(body.get("max_tokens", 160))
        except (TypeError, ValueError):
            max_tokens = 160
        prompt = (
            "You are an inline code completion engine. Continue the code exactly at "
            "the <CURSOR> marker. Output ONLY the raw code that should be inserted - "
            "no explanations, no markdown fences, no repetition of existing code.\n\n"
            "%s<CURSOR>%s" % (prefix, suffix))
        payload = {
            "model": ollama_model(body.get("model")),
            "prompt": prompt, "stream": False, "raw": False,
            "options": {"num_predict": max_tokens, "temperature": 0.2,
                        "stop": ["\n\n\n", "<CURSOR>"]}}
        try:
            with _ollama_request("/api/generate", payload, 90) as resp:
                text = (json.loads(resp.read().decode()).get("response")
                        or "").strip("\n")
            if text.startswith("```"):
                text = text.split("```")[0]
            return self._send_json({"completion": text, "model": payload["model"]})
        except Exception as exc:
            code, obj = _ollama_error(exc)
            return self._send_json(obj, code)

# ------------------------------------------------------------
# main
# ------------------------------------------------------------

BANNER = r"""
   )\    ViMoon extension {version}  -  moonlit code editor for kitsune//ai-mangr
  (  )   Workspace : {ws}
 ( (  )  Frontend  : http://localhost:{port}
  ) ( (   API       : http://localhost:{port}/api/health
 _)..--.._  MoonBot  : ollama proxy at /api/ollama
"""


def main():
    global PORT, HOST
    argv = sys.argv[1:]
    if "--lan" in argv or os.environ.get("VIMOON_LAN") in ("1", "true", "yes"):
        HOST = "0.0.0.0"
        print("[vimoon] WARNING: reachable from the network - pair this with "
              "kitsune's pin lock, or keep it off shared wifi.", flush=True)
    if "--port" in argv:
        try:
            PORT = int(argv[argv.index("--port") + 1])
        except (IndexError, ValueError):
            pass
    os.makedirs(DATA_DIR, exist_ok=True)
    ensure_dirs()
    print(BANNER.format(version=VERSION, ws=workspace(), port=PORT), flush=True)
    try:
        httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print("[vimoon] port %s unavailable: %s" % (PORT, exc), flush=True)
        sys.exit(1)
    httpd.daemon_threads = True
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[vimoon] bye - the moon sets.", flush=True)


if __name__ == "__main__":
    main()
