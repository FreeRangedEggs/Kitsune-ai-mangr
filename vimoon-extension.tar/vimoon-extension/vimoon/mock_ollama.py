#!/usr/bin/env python3
r"""
mock_ollama.py — a tiny simulated Ollama server for trying ViMoon's
MoonBot UI without installing Ollama.

It implements just enough of the Ollama HTTP API:
  GET  /api/tags            -> one fake model: moonbot-sim
  POST /api/chat            -> canned, rule-based replies (stream + non-stream)
  POST /api/generate        -> simple code continuation for Alt-\ ghost text

Run:  python scripts/mock_ollama.py        (listens on :11434)
Every reply is tagged (sim) so nobody mistakes it for a real model.
"""
import json
import re
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(__import__("os").environ.get("OLLAMA_PORT", "11434"))
MODEL = "moonbot-sim:latest"


def chat_reply(messages):
    last = ""
    for m in messages:
        if m.get("role") == "user":
            last = m.get("content", "")
    low = last.lower()
    code = re.search(r"```[\w]*\n(.*?)```", last, re.S)

    def fence(body, lang="python"):
        return f"```{lang}\n{body.strip()}\n```"

    if "bug" in low or "review" in low or "analyz" in low:
        body = code.group(1) if code else last
        lines = [l for l in body.splitlines() if l.strip()]
        risky = [l.strip() for l in lines if re.search(r"eval\(|except:|TODO|FIXME|open\(", l)]
        return ("(sim) Here is my analysis:\n\n"
                "**Summary** — code looks functional; a few habits worth improving.\n\n"
                "**Issues**\n"
                "1. Bare `except:` swallows real errors - catch specific types.\n"
                "2. Missing input validation at the boundaries.\n"
                + (f"3. Spotted risky lines: {risky[:2]}\n" if risky else "")
                + "\n**Quick wins** - add type hints, docstrings and unit tests.")

    if "test" in low:
        return ("(sim) Suggested tests:\n\n" + fence(
            "import pytest\n\n\ndef test_basic():\n    assert callable(target)\n\n\n"
            "@pytest.mark.parametrize(\"value,expected\", [(1, 1), (2, 4)])\n"
            "def test_squares(value, expected):\n    assert value ** 2 == expected", "python"))

    if "explain" in low:
        return ("(sim) In one line: the code coordinates inputs, transforms them, "
                "and returns a result. Step by step:\n\n"
                "1. Gather state and validate it.\n2. Apply the core transformation.\n"
                "3. Return the shaped output for the caller.")

    if low.strip().endswith("?"):
        return ("(sim) Short answer: yes - with caveats. Long answer: measure first, "
                "then optimize the part the profiler flags, not the one that looks slow.")

    return ("(sim) I heard you - paste a code block (``` fences) or ask me to "
            "analyze / explain / find bugs / suggest tests. I am a mock, the real "
            "MoonBot speaks fluent code once you install Ollama.")


def ghost_complete(prefix):
    """Very dumb continuation: complete the current line like a code gremlin."""
    lines = prefix.split("\n")
    cur = lines[-1] if lines else ""
    stripped = cur.strip()
    if not stripped:
        return "# (sim) keep typing - or install Ollama for real suggestions\n"
    if stripped.startswith("def "):
        name = re.search(r"def\s+(\w+)", stripped)
        indent = cur[: len(cur) - len(cur.lstrip())]
        return f"{indent}    \"\"\"TODO: {name.group(1) if name else 'do something'}\"\"\"\n{indent}    pass\n"
    if stripped.startswith("for ") and stripped.endswith(":"):
        indent = cur[: len(cur) - len(cur.lstrip())]
        return f"{indent}    pass  # (sim) loop body\n"
    if stripped.startswith("//") or stripped.startswith("#"):
        return ""
    return "  # (sim) continuation\n"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):  # silence request spam
        pass

    def _send(self, obj, status=200):
        body = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/api/tags"):
            self._send({"models": [{"model": MODEL, "name": MODEL,
                                    "size": 1, "details": {"family": "sim"}}]})
        else:
            self._send({"error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError:
            self._send({"error": "bad json"}, 400)
            return

        if self.path.startswith("/api/chat"):
            if payload.get("stream"):
                self.send_response(200)
                self.send_header("Content-Type", "application/x-ndjson")
                self.end_headers()
                text = chat_reply(payload.get("messages", []))
                for i in range(0, len(text), 24):
                    chunk = {"model": MODEL,
                             "message": {"role": "assistant", "content": text[i:i + 24]},
                             "done": False}
                    self.wfile.write((json.dumps(chunk) + "\n").encode())
                    self.wfile.flush()
                    time.sleep(0.02)
                done = {"model": MODEL, "message": {"role": "assistant", "content": ""},
                        "done": True, "done_reason": "stop"}
                self.wfile.write((json.dumps(done) + "\n").encode())
            else:
                self._send({"model": MODEL,
                            "message": {"role": "assistant",
                                        "content": chat_reply(payload.get("messages", []))},
                            "done": True})
        elif self.path.startswith("/api/generate"):
            text = ghost_complete(payload.get("prompt", ""))
            self._send({"model": MODEL, "response": text, "done": True})
        else:
            self._send({"error": "not found"}, 404)


if __name__ == "__main__":
    print(f"(sim) mock Ollama listening on http://localhost:{PORT} - model '{MODEL}'")
    try:
        HTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
    except OSError as e:
        print(f"(sim) could not bind :{PORT} ({e}) - is real Ollama running?")
