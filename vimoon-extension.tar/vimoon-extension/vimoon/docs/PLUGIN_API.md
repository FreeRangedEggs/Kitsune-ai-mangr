# ViMoon Plugin API

Plugins are folders inside `plugins/` that add commands, status-bar items
and event reactions to ViMoon — without touching the core.

```
plugins/
└── my-plugin/
    ├── manifest.json
    └── main.js          # (any name, referenced by "main" in the manifest)
```

## manifest.json

```json
{
  "id": "my-plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "author": "you",
  "description": "What it does, shown in the Plugins panel.",
  "main": "main.js"
}
```

- `id` must match the folder name: lowercase letters, digits, `-`, `_`.
- Users can enable/disable each plugin from the **Plugins panel**;
  the state is stored in `data/settings.json` under `enabled_plugins`
  and takes effect on the next page load.

## Registration

Your `main.js` runs as a normal script tag after ViMoon boots. Call the
global hook exactly once:

```js
ViMoon.register({
  id: "my-plugin",
  init: function (ctx) {
    // your plugin starts here
  },
});
```

Errors are caught and logged — a broken plugin never crashes the editor.

## Context API (`ctx`)

| Member | Signature | Purpose |
|---|---|---|
| `ctx.id` | `string` | Your plugin id |
| `ctx.editor` | `() => CodeMirror` | The active CodeMirror instance |
| `ctx.activeTab` | `() => tab \| null` | Active tab: `{id, path, name, doc, dirty, readOnly, modeMime, size, encoding}` |
| `ctx.settings` | `() => object` | Current settings (read-only usage) |
| `ctx.openFile` | `(path) => Promise<tab>` | Open (or focus) a file |
| `ctx.notify` | `(msg, type?)` | Toast: `info \| success \| warning \| error` |
| `ctx.registerCommand` | `(cmd)` | Add a palette command (below) |
| `ctx.addStatusItem` | `(el)` | Append a DOM node to the status bar |
| `ctx.on` | `(event, fn)` | Subscribe to the app event bus |

### registerCommand

```js
ctx.registerCommand({
  id: "my-plugin.action",      // unique
  title: "My Plugin: do the thing",
  key: "Alt+K",                // optional global chord (Ctrl+/Alt+/Shift prefixes)
  icon: "moon",                // any ViMoon icon name
  run: function () { /* ... */ },
});
```

Registered commands appear in the `Ctrl+P` command palette automatically.

### Events

| Event | Payload | Fired when |
|---|---|---|
| `file-opened` | tab | a file finishes loading |
| `file-saved` | tab | a file is written |
| `tab-activated` | tab | tab switch |
| `tab-closed` | tab | tab closed |
| `editor-change` | tab | any edit in the active document (throttle it!) |
| `theme-changed` | theme id | theme switch |
| `open-panel` | `"bot" \| "git" \| "plugins"` | a side panel was requested |

## Example

```js
ViMoon.register({
  id: "timestamp",
  init: function (ctx) {
    ctx.registerCommand({
      id: "timestamp.insert",
      title: "Insert current timestamp",
      icon: "clock",
      run: function () {
        var ed = ctx.editor();
        if (ed) ed.replaceSelection(new Date().toISOString() + " ");
      },
    });
  },
});
```

Live examples ship in `plugins/word-count` and `plugins/zen-moon`.
