/* word-count — ViMoon example plugin.
 * Adds a live "N words · M chars" item to the status bar. */
ViMoon.register({
  id: "word-count",
  init: function (ctx) {
    var item = document.createElement("div");
    item.className = "status-item";
    item.title = "Word Count plugin";
    item.textContent = "0 words";
    ctx.addStatusItem(item);

    var update = function () {
      var t = ctx.activeTab();
      if (!t || !t.doc) { item.textContent = ""; return; }
      var value = t.doc.getValue();
      var words = (value.match(/\S+/g) || []).length;
      item.textContent = words + " words · " + value.length + " chars";
    };

    var debounced = null;
    var schedule = function () {
      if (debounced) clearTimeout(debounced);
      debounced = setTimeout(update, 250);
    };

    ctx.on("tab-activated", update);
    ctx.on("file-opened", update);
    ctx.on("tab-closed", update);
    ctx.on("editor-change", schedule);
    ctx.on("file-saved", update);
    update();
  },
});
