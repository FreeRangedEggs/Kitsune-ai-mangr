/* zen-moon — ViMoon example plugin.
 * Registers a command + keyboard shortcut for distraction-free editing. */
ViMoon.register({
  id: "zen-moon",
  init: function (ctx) {
    var toggle = function () {
      document.body.classList.toggle("zen");
      var ed = ctx.editor();
      if (ed) setTimeout(function () { ed.refresh(); }, 60);
      ctx.notify(document.body.classList.contains("zen")
        ? "Zen mode — press Alt+Z (or Ctrl+P → Toggle Zen) to return"
        : "Welcome back to the observatory", "info");
    };
    ctx.registerCommand({
      id: "zen-moon.toggle",
      title: "Zen Moon: toggle focus mode",
      key: "Alt+Z",
      icon: "moon",
      run: toggle,
    });
  },
});
