/* ============================================================
 * ViMoon — core.js
 * DOM helpers, icons, API client, event bus, toasts, modals.
 * Exposes the global `Vi` namespace.
 * ============================================================ */
(function () {
  "use strict";

  const Vi = { version: "1.0.0" };
  window.Vi = Vi;

  /* ---------------- tiny DOM/utils ---------------- */
  Vi.$ = (sel, root) => (root || document).querySelector(sel);
  Vi.$$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  Vi.esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));

  Vi.debounce = (fn, ms) => {
    let t = null;
    return function (...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), ms);
    };
  };

  Vi.extOf = (name) => {
    const m = /\.([A-Za-z0-9]+)$/.exec(name || "");
    return m ? m[1].toLowerCase() : "";
  };

  Vi.fmtSize = (n) => {
    if (n == null) return "";
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
    return (n / 1048576).toFixed(1) + " MB";
  };

  Vi.relTime = (iso) => {
    const d = new Date(iso);
    const s = (Date.now() - d.getTime()) / 1000;
    if (isNaN(s)) return "";
    if (s < 60) return "just now";
    if (s < 3600) return Math.floor(s / 60) + "m ago";
    if (s < 86400) return Math.floor(s / 3600) + "h ago";
    if (s < 86400 * 30) return Math.floor(s / 86400) + "d ago";
    return d.toISOString().slice(0, 10);
  };

  /* subsequence fuzzy match; returns score or -1 */
  Vi.fuzzy = (query, target) => {
    if (!query) return 0;
    const q = query.toLowerCase(), t = target.toLowerCase();
    let qi = 0, score = 0, streak = 0;
    for (let ti = 0; ti < t.length && qi < q.length; ti++) {
      if (t[ti] === q[qi]) {
        streak++;
        score += 2 + streak + (ti === 0 ? 6 : 0);
        qi++;
      } else {
        streak = 0;
      }
    }
    return qi === q.length ? score : -1;
  };

  /* ---------------- icons (inline SVG, feather-style) ---------------- */
  const S = (inner, extra) =>
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ` +
    `stroke-linecap="round" stroke-linejoin="round" ${extra || ""}>${inner}</svg>`;

  Vi.icons = {
    moon: S('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>'),
    sun: S('<circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="20" x2="12" y2="22"/><line x1="4.9" y1="4.9" x2="6.3" y2="6.3"/><line x1="17.7" y1="17.7" x2="19.1" y2="19.1"/><line x1="2" y1="12" x2="4" y2="12"/><line x1="20" y1="12" x2="22" y2="12"/><line x1="4.9" y1="19.1" x2="6.3" y2="17.7"/><line x1="17.7" y1="6.3" x2="19.1" y2="4.9"/>'),
    file: S('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>'),
    folder: S('<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>'),
    chevron: S('<polyline points="9 18 15 12 9 6"/>'),
    plus: S('<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>'),
    save: S('<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>'),
    search: S('<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>'),
    git: S('<line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>'),
    bot: S('<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><circle cx="9" cy="10" r="1" fill="currentColor"/><circle cx="15" cy="10" r="1" fill="currentColor"/>'),
    plug: S('<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'),
    gear: S('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>'),
    x: S('<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>'),
    refresh: S('<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>'),
    trash: S('<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'),
    pen: S('<path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/>'),
    send: S('<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>'),
    stop: S('<rect x="6" y="6" width="12" height="12" rx="2"/>'),
    check: S('<polyline points="20 6 9 17 4 12"/>'),
    "panel-left": S('<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/>'),
    "panel-right": S('<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="15" y1="3" x2="15" y2="21"/>'),
    command: S('<path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/>'),
    help: S('<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>'),
    clock: S('<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>'),
    minus: S('<line x1="5" y1="12" x2="19" y2="12"/>'),
    undo: S('<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>'),
    zap: S('<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'),
    /* moon phases for the vim mode chip */
    "phase-normal": S('<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18z" fill="currentColor" stroke="none" opacity=".85"/>'),
    "phase-insert": S('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" fill="currentColor" stroke="none"/>'),
    "phase-visual": S('<circle cx="12" cy="12" r="9" fill="currentColor" stroke="none"/>'),
    "phase-replace": S('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5" fill="currentColor" stroke="none"/>'),
    "phase-command": S('<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18z" fill="currentColor" stroke="none" opacity=".85"/>'),
  };

  Vi.icon = (name) => Vi.icons[name] || "";

  /* populate all [data-icon] placeholders */
  Vi.paintIcons = (root) => {
    Vi.$$("[data-icon]", root || document).forEach((el) => {
      const name = el.getAttribute("data-icon");
      if (name && !el.firstChild) el.innerHTML = Vi.icon(name);
    });
  };

  /* ---------------- event bus ---------------- */
  const listeners = {};
  Vi.bus = {
    on(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); },
    off(ev, fn) {
      const arr = listeners[ev];
      if (arr) { const i = arr.indexOf(fn); if (i >= 0) arr.splice(i, 1); }
    },
    emit(ev, data) {
      (listeners[ev] || []).slice().forEach((fn) => {
        try { fn(data); } catch (e) { console.warn("[ViMoon] listener error", ev, e); }
      });
    },
  };

  /* ---------------- API client ---------------- */
  Vi.api = {
    async req(method, url, body) {
      let res;
      try {
        res = await fetch(url, {
          method,
          headers: body !== undefined ? { "Content-Type": "application/json" } : undefined,
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });
      } catch (err) {
        Vi.toast("Network error — is the ViMoon server running?", "error");
        throw err;
      }
      if (!res.ok) {
        let payload = {};
        try { payload = await res.json(); } catch (e) { /* not json */ }
        const err = new Error(payload.error || ("HTTP " + res.status));
        err.status = res.status;
        err.payload = payload;
        throw err;
      }
      const ct = res.headers.get("content-type") || "";
      return ct.includes("application/json") ? res.json() : res.text();
    },
    get: (u) => Vi.api.req("GET", u),
    post: (u, b) => Vi.api.req("POST", u, b || {}),
    put: (u, b) => Vi.api.req("PUT", u, b || {}),
  };

  /* ---------------- toasts ---------------- */
  Vi.toast = (msg, type, ms) => {
    const host = document.getElementById("toasts");
    if (!host) return;
    const el = document.createElement("div");
    el.className = "toast " + (type || "info");
    el.textContent = msg;
    host.appendChild(el);
    setTimeout(() => {
      el.style.transition = "opacity .3s";
      el.style.opacity = "0";
      setTimeout(() => el.remove(), 320);
    }, ms || 3200);
  };

  /* ---------------- modal system ---------------- */
  const modalStack = [];

  Vi.modal = function (opts) {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    const modal = document.createElement("div");
    modal.className = "modal" + (opts.wide ? " wide" : "");
    modal.innerHTML =
      '<div class="modal-head"><span class="modal-title">' + Vi.esc(opts.title || "") +
      '</span><button class="tbtn modal-x" title="Close">' + Vi.icon("x") + "</button></div>" +
      '<div class="modal-body"></div>' +
      '<div class="modal-foot"></div>';
    if (typeof opts.body === "string") {
      modal.querySelector(".modal-body").innerHTML = opts.body;
    } else if (opts.body instanceof HTMLElement) {
      modal.querySelector(".modal-body").appendChild(opts.body);
    }
    backdrop.appendChild(modal);
    (document.getElementById("modals") || document.body).appendChild(backdrop);

    const api = {
      el: backdrop,
      close() {
        backdrop.remove();
        const i = modalStack.indexOf(api);
        if (i >= 0) modalStack.splice(i, 1);
        document.removeEventListener("keydown", onKey, true);
        if (opts.onClose) opts.onClose();
      },
      body: modal.querySelector(".modal-body"),
    };

    function onKey(e) {
      if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); api.close(); }
    }

    modal.querySelector(".modal-x").addEventListener("click", () => api.close());
    backdrop.addEventListener("mousedown", (e) => {
      if (e.target === backdrop && !opts.persistent) api.close();
    });
    document.addEventListener("keydown", onKey, true);

    const foot = modal.querySelector(".modal-foot");
    (opts.buttons || [{ label: "Close" }]).forEach((b) => {
      const btn = document.createElement("button");
      btn.className = "btn " + (b.class || "");
      btn.textContent = b.label;
      btn.addEventListener("click", () => {
        const keep = b.onClick ? b.onClick(api) : undefined;
        if (!keep && b.close !== false) api.close();
      });
      foot.appendChild(btn);
    });

    modalStack.push(api);
    return api;
  };

  Vi.closeTopModal = () => {
    const top = modalStack[modalStack.length - 1];
    if (top) { top.close(); return true; }
    return false;
  };

  Vi.confirm = function (title, message, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      let answered = false;
      const m = Vi.modal({
        title,
        body: '<p style="color:var(--text)">' + Vi.esc(message) + "</p>",
        buttons: [
          { label: opts.cancelLabel || "Cancel", class: "", onClick: () => { answered = true; resolve(false); } },
          { label: opts.okLabel || "OK", class: opts.danger ? "danger" : "primary", onClick: () => { answered = true; resolve(true); } },
        ],
        onClose: () => { if (!answered) resolve(false); },
      });
      setTimeout(() => { const b = m.el.querySelector(".modal-foot .btn:last-child"); if (b) b.focus(); }, 30);
    });
  };

  /* 3-way choice for closing dirty tabs: 'save' | 'discard' | 'cancel' */
  Vi.confirm3 = function (title, message, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      let answered = false;
      const done = (v) => { answered = true; resolve(v); };
      Vi.modal({
        title,
        body: '<p style="color:var(--text)">' + Vi.esc(message) + "</p>",
        buttons: [
          { label: "Cancel", onClick: () => done("cancel") },
          { label: opts.discardLabel || "Discard", class: "danger", onClick: () => done("discard") },
          { label: opts.saveLabel || "Save", class: "primary", onClick: () => done("save") },
        ],
        onClose: () => { if (!answered) resolve("cancel"); },
      });
    });
  };

  Vi.prompt = function (title, label, value, placeholder) {
    return new Promise((resolve) => {
      let answered = false;
      const wrap = document.createElement("div");
      wrap.innerHTML =
        '<label style="display:block;margin-bottom:7px">' + Vi.esc(label || "") + "</label>" +
        '<input type="text" style="width:100%" spellcheck="false">';
      const input = wrap.querySelector("input");
      input.value = value || "";
      if (placeholder) input.placeholder = placeholder;
      const m = Vi.modal({
        title,
        body: wrap,
        buttons: [
          { label: "Cancel", onClick: () => { answered = true; resolve(null); } },
          { label: "OK", class: "primary", onClick: () => { answered = true; resolve(input.value.trim()); }, close: true },
        ],
        onClose: () => { if (!answered) resolve(null); },
      });
      setTimeout(() => input.focus(), 30);
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          answered = true;
          m.close();
          resolve(input.value.trim());
        }
      });
    });
  };
})();
