/* ============================================================
 * ViMoon — settings.js
 * Settings state, persistence, live application, and the
 * settings modal (font size, line numbers, theme, MoonBot…).
 * ============================================================ */
(function () {
  "use strict";

  const Settings = {
    _data: null,
    _themes: ["moonlight", "dark", "dawn"],

    raw() { return this._data || {}; },

    async load() {
      this._data = await Vi.api.get("/api/settings");
      document.body.dataset.theme = this._data.theme || "moonlight";
      document.documentElement.style.setProperty("--ui-font", this._data.ui_font_family);
      return this._data;
    },

    async put(patch) {
      this._data = await Vi.api.put("/api/settings", patch);
      document.documentElement.style.setProperty("--ui-font", this._data.ui_font_family);
      return this._data;
    },

    async set(key, value) {
      await this.put({ [key]: value });
      this.apply();
      Vi.toast("Saved: " + key, "success", 1400);
    },

    saveUIDebounced: Vi.debounce(function () {
      Settings.put({ ui: Settings.raw().ui }).catch(() => {});
    }, 600),

    apply() {
      const s = this._data;
      document.body.dataset.theme = s.theme;
      if (!window.editor) return;
      editor.setOption("lineNumbers", s.line_numbers);
      editor.setOption("lineWrapping", s.word_wrap);
      editor.setOption("indentUnit", s.tab_size);
      editor.setOption("tabSize", s.tab_size);
      editor.setOption("indentWithTabs", s.indent_with_tabs);
      editor.setOption("autoCloseBrackets", s.bracket_close);
      editor.setOption("styleActiveLine", s.highlight_active_line);
      editor.setOption("foldGutter", s.code_folding);
      editor.getWrapperElement().style.fontSize = s.font_size + "px";
      editor.getWrapperElement().style.fontFamily = s.font_family;
      editor.setOption("keyMap", s.vim_mode ? "vim" : "default");
      editor.refresh();
      StatusBar.updateIndent();
      if (s.vim_mode) StatusBar.setMode("normal");
      const themeBtn = document.getElementById("btn-theme");
      if (themeBtn) {
        themeBtn.innerHTML = Vi.icon(s.theme === "dawn" ? "sun" : "moon");
      }
    },

    cycleTheme() {
      const cur = this._data.theme;
      const next = this._themes[(this._themes.indexOf(cur) + 1) % this._themes.length];
      this.set("theme", next);
      Vi.toast("Theme: " + next, "info", 1400);
    },

    /* ---------------- settings modal ---------------- */
    openModal() {
      const d = JSON.parse(JSON.stringify(this._data));
      const wrap = document.createElement("div");

      const row = (label, hint, control) => {
        const r = document.createElement("div");
        r.className = "set-row";
        const l = document.createElement("label");
        l.className = "set-label";
        l.innerHTML = label + (hint ? '<span class="set-hint">' + hint + "</span>" : "");
        r.appendChild(l);
        r.appendChild(control);
        return r;
      };
      const select = (key, options) => {
        const el = document.createElement("select");
        for (const o of options) {
          const op = document.createElement("option");
          op.value = o.v; op.textContent = o.l;
          if (d[key] === o.v) op.selected = true;
          el.appendChild(op);
        }
        el.addEventListener("change", () => { d[key] = el.value; preview(); });
        return el;
      };
      const checkbox = (key) => {
        const el = document.createElement("button");
        el.className = "switch" + (d[key] ? " on" : "");
        el.type = "button";
        el.addEventListener("click", () => { d[key] = !d[key]; el.classList.toggle("on", d[key]); });
        return el;
      };
      const range = (key, min, max, suffix) => {
        const box = document.createElement("div");
        box.style.display = "flex"; box.style.alignItems = "center"; box.style.gap = "8px";
        const el = document.createElement("input");
        el.type = "range"; el.min = min; el.max = max; el.value = d[key];
        const val = document.createElement("span");
        val.className = "range-val";
        val.textContent = d[key] + (suffix || "");
        el.addEventListener("input", () => { d[key] = +el.value; val.textContent = el.value + (suffix || ""); });
        box.appendChild(el); box.appendChild(val);
        return box;
      };
      const text = (key, placeholder) => {
        const el = document.createElement("input");
        el.type = "text"; el.value = d[key] || ""; el.placeholder = placeholder || "";
        el.spellcheck = false;
        el.addEventListener("input", () => { d[key] = el.value; });
        return el;
      };
      function preview() {
        document.body.dataset.theme = d.theme;
      }

      const h = (t) => {
        const el = document.createElement("h4");
        el.textContent = t;
        return el;
      };
      wrap.appendChild(h("Appearance"));
      wrap.appendChild(row("Theme", "Moonlight · Midnight Dark · Dawn", select("theme", [
        { v: "moonlight", l: "Moonlight (dreamy)" },
        { v: "dark", l: "Midnight Dark (traditional)" },
        { v: "dawn", l: "Dawn (soft light)" },
      ])));
      wrap.appendChild(row("Editor font size", "9 – 24 px", range("font_size", 9, 24, "px")));
      wrap.appendChild(row("Editor font family", "CSS font stack", text("font_family")));
      wrap.appendChild(row("UI font family", "Used in panels and menus", text("ui_font_family")));

      wrap.appendChild(h("Editor"));
      wrap.appendChild(row("Line numbers", null, checkbox("line_numbers")));
      wrap.appendChild(row("Word wrap", null, checkbox("word_wrap")));
      wrap.appendChild(row("Vim mode", "Normal / Insert / Visual modes, ex commands (:w :q)", checkbox("vim_mode")));
      wrap.appendChild(row("Auto completion", "Suggest words and language keywords while typing", checkbox("auto_completion")));
      wrap.appendChild(row("Auto-close brackets", null, checkbox("bracket_close")));
      wrap.appendChild(row("Highlight active line", null, checkbox("highlight_active_line")));
      wrap.appendChild(row("Code folding", "Fold gutter in the margin", checkbox("code_folding")));
      wrap.appendChild(row("Indent size", "Spaces per indent", range("tab_size", 1, 8)));
      wrap.appendChild(row("Indent with tabs", "Use tab characters instead of spaces", checkbox("indent_with_tabs")));

      wrap.appendChild(h("Behavior"));
      wrap.appendChild(row("Auto save", "Save dirty files a moment after you stop typing", checkbox("auto_save")));

      wrap.appendChild(h("MoonBot (Ollama)"));
      wrap.appendChild(row("Ollama URL", "Where your Ollama server lives", text("ollama_url", "http://localhost:11434")));
      wrap.appendChild(row("Preferred model", "Leave empty to use the first available", text("ollama_model", "llama3.2")));
      wrap.appendChild(row("Large-file limit", "Files above this size open read-only", range("large_file_limit_kb", 256, 8192, " KB")));

      Vi.modal({
        title: "Settings",
        wide: true,
        body: wrap,
        buttons: [
          { label: "Cancel", onClick: () => { preview(); } },
          {
            label: "Save settings", class: "primary",
            onClick: async () => {
              const oldTheme = this._data.theme;
              await this.put(d);
              this.apply();
              Vi.toast("Settings saved", "success");
              if (oldTheme !== d.theme) Vi.bus.emit("theme-changed", d.theme);
            },
          },
        ],
        onClose: () => preview(),
      });
    },
  };

  window.Settings = Settings;
})();
