/* ============================================================
 * ViMoon — bot.js
 * MoonBot: the Ollama-powered coding companion.
 * Chat with streaming, quick analysis actions, and the inline
 * completion endpoint used by Alt-\ ghost suggestions.
 * ============================================================ */
(function () {
  "use strict";

  function mdToHtml(src) {
    // split on fenced code blocks; escape + light formatting elsewhere
    const parts = String(src).split(/```/);
    let out = "";
    for (let i = 0; i < parts.length; i++) {
      if (i % 2 === 1) {
        let code = parts[i];
        const nl = code.indexOf("\n");
        if (nl > -1 && nl < 24) code = code.slice(nl + 1); // drop language line
        out += "<pre><code>" + Vi.esc(code.replace(/\n$/, "")) + "</code></pre>";
      } else {
        let t = Vi.esc(parts[i]);
        t = t.replace(/`([^`\n]+)`/g, "<code>$1</code>");
        t = t.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
        t = t.replace(/^#{1,4}\s+(.+)$/gm, "<b>$1</b>");
        t = t.replace(/^\s*[-*]\s+/gm, "• ");
        t = t.replace(/\n/g, "<br>");
        out += t;
      }
    }
    return out;
  }

  const MoonBot = {
    status: null,
    checkedAt: 0,
    history: [],
    busy: false,
    abort: null,

    init() {
      this.dot = document.getElementById("bot-status-dot");
      this.modelSel = document.getElementById("bot-model");
      this.body = document.getElementById("bot-body");
      this.input = document.getElementById("bot-input");
      this.sendBtn = document.getElementById("bot-send");
      this.stopBtn = document.getElementById("bot-stop");

      document.getElementById("bot-refresh").addEventListener("click", () => this.refreshStatus(true));
      this.sendBtn.addEventListener("click", () => this.sendFromInput());
      this.stopBtn.addEventListener("click", () => this.stop());
      this.input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.sendFromInput(); }
      });
      this.input.addEventListener("input", () => {
        this.input.style.height = "auto";
        this.input.style.height = Math.min(110, this.input.scrollHeight) + "px";
      });
      document.querySelectorAll("#bot-quick .chip").forEach((chip) => {
        chip.addEventListener("click", () => this.quickAction(chip.dataset.qa));
      });
      this.renderEmpty();

      // auto-check on first open, silently
      this.refreshStatus(false);
    },

    async ensureStatus() {
      if (this.status && Date.now() - this.checkedAt < 30000) return this.status;
      return this.refreshStatus(false);
    },

    async refreshStatus(loud) {
      try {
        this.status = await Vi.api.get("/api/ollama/status");
      } catch (err) {
        this.status = { reachable: false, error: err.message };
      }
      this.checkedAt = Date.now();
      this.renderHead();
      if (loud) {
        Vi.toast(this.status.reachable
          ? "Ollama connected — " + this.status.models.length + " model(s)"
          : "Ollama not reachable", this.status.reachable ? "success" : "warning");
      }
      StatusBar.setBotOnline(!!(this.status && this.status.reachable));
      return this.status;
    },

    renderHead() {
      const st = this.status || {};
      this.dot.classList.toggle("online", !!st.reachable);
      this.dot.classList.toggle("offline", !st.reachable);
      this.modelSel.innerHTML = "";
      if (st.reachable && st.models && st.models.length) {
        const preferred = st.default_model || st.models[0];
        for (const m of st.models) {
          const opt = document.createElement("option");
          opt.value = m;
          opt.textContent = m;
          if (m === preferred) opt.selected = true;
          this.modelSel.appendChild(opt);
        }
      } else {
        this.modelSel.innerHTML = '<option>no models</option>';
      }
      if (!st.reachable) this.renderSetup();
      else if (!this.body.querySelector(".msg") && !this.body.querySelector(".bot-empty")) this.renderEmpty();
    },

    renderSetup() {
      this.body.innerHTML =
        '<div class="bot-setup">' +
        '<h4>' + Vi.icon("bot") + " MoonBot is asleep</h4>" +
        "MoonBot talks to a local <b>Ollama</b> server for real-time code analysis and suggestions." +
        "<br><br>1. Install Ollama from <b>ollama.com</b>" +
        "<br>2. <code>ollama pull llama3.2</code> (or any model you like)" +
        "<br>3. <code>ollama serve</code>" +
        "<br>4. Set the URL in <b>Settings → MoonBot</b> if it is not the default." +
        "<br><br>No Ollama yet? Run <code>python scripts/mock_ollama.py</code> to try the " +
        "interface with a simulated assistant." +
        '<br><button class="btn" id="bot-recheck">Check again</button>' +
        "</div>";
      this.body.querySelector("#bot-recheck").addEventListener("click", () => this.refreshStatus(true));
    },

    renderEmpty() {
      this.body.innerHTML =
        '<div class="bot-empty"><div class="bot-moon">' + Vi.icon("moon") + "</div>" +
        "Ask about your code, or use the quick actions below." +
        "<br>Analyze · explain · hunt bugs · draft tests.</div>";
    },

    currentModel() {
      return this.modelSel.value && this.modelSel.value !== "no models" ? this.modelSel.value : undefined;
    },

    activeContext(maxChars) {
      maxChars = maxChars || 6000;
      const t = Tabs.active();
      if (!t) return null;
      const code = t.doc.getValue();
      const clipped = code.length > maxChars
        ? code.slice(0, maxChars) + "\n… (truncated)"
        : code;
      return { name: t.name, lang: Modes.labelFor(t.name).toLowerCase().replace("*", ""), code: clipped };
    },

    quickAction(kind) {
      const ctx = this.activeContext();
      if (!ctx) { Vi.toast("Open a file first", "warning"); return; }
      const sel = editor && editor.somethingSelected() ? editor.getSelection() : null;
      const code = sel && kind !== "tests" && kind !== "analyze" ? sel : ctx.code;
      const scope = sel ? "the selected code" : "the file " + ctx.name;
      const prompts = {
        analyze: "Review this " + ctx.lang + " code. Structure: 1) one-line summary, 2) issues by severity, 3) quick wins.\n\n```" + ctx.lang + "\n" + code + "\n```",
        explain: "Explain what " + scope + " does, step by step, briefly.\n\n```" + ctx.lang + "\n" + code + "\n```",
        bugs: "List potential bugs, edge cases and risky patterns in this code. Be specific.\n\n```" + ctx.lang + "\n" + code + "\n```",
        tests: "Suggest unit tests (with code) for this " + ctx.lang + " file. Focus on interesting edge cases.\n\n```" + ctx.lang + "\n" + code + "\n```",
      };
      this.send(prompts[kind]);
    },

    sendFromInput() {
      const text = this.input.value.trim();
      if (!text || this.busy) return;
      this.input.value = "";
      this.input.style.height = "auto";
      this.send(text);
    },

    stop() {
      if (this.abort) { this.abort.abort(); this.abort = null; }
    },

    async send(userText) {
      if (this.busy) { Vi.toast("MoonBot is still answering…", "info"); return; }
      const st = await this.ensureStatus();
      if (!st.reachable) { this.renderHead(); Vi.toast("Ollama is not reachable — see setup steps in the panel", "warning"); return; }

      this.history.push({ role: "user", content: userText });
      this.renderMessage("user", userText);
      this.busy = true;
      this.sendBtn.classList.add("hidden");
      this.stopBtn.classList.remove("hidden");

      const botEl = this.renderMessage("bot", "");
      botEl.classList.add("thinking");
      const textEl = botEl.querySelector(".md");
      let full = "";
      this.abort = new AbortController();

      const messages = [{ role: "system", content: MoonBot.SYSTEM_PROMPT }]
        .concat(this.history.slice(-10));

      try {
        const res = await fetch("/api/ollama/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: this.currentModel(), messages, stream: true }),
          signal: this.abort.signal,
        });
        if (!res.ok) {
          let msg = "HTTP " + res.status;
          try { const j = await res.json(); msg = j.error || msg; if (j.hint) msg += " — " + j.hint; } catch (e) {}
          throw new Error(msg);
        }
        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = "";
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const chunks = buf.split("\n\n");
          buf = chunks.pop();
          for (const chunk of chunks) {
            const line = chunk.split("\n").find((l) => l.startsWith("data:"));
            if (!line) continue;
            let payload;
            try { payload = JSON.parse(line.slice(5).trim()); } catch (e) { continue; }
            if (payload.error) throw new Error(payload.error);
            if (payload.delta) {
              full += payload.delta;
              botEl.classList.remove("thinking");
              textEl.textContent = full;
              this.body.scrollTop = this.body.scrollHeight;
            }
          }
        }
        if (!full) full = "(empty response)";
        botEl.classList.remove("thinking");
        textEl.innerHTML = mdToHtml(full);
        this.history.push({ role: "assistant", content: full });
      } catch (err) {
        botEl.classList.remove("thinking");
        if (err.name === "AbortError") {
          textEl.innerHTML = mdToHtml(full + "\n\n*(stopped)*");
          if (full) this.history.push({ role: "assistant", content: full });
        } else {
          textEl.innerHTML = '<span style="color:var(--danger)">MoonBot: ' + Vi.esc(err.message) + "</span>";
          this.history.pop(); // drop the unanswered user turn
          this.renderHead();
        }
      } finally {
        this.busy = false;
        this.abort = null;
        this.sendBtn.classList.remove("hidden");
        this.stopBtn.classList.add("hidden");
        this.body.scrollTop = this.body.scrollHeight;
      }
    },

    renderMessage(role, text) {
      const empty = this.body.querySelector(".bot-empty, .bot-setup");
      if (empty) empty.remove();
      const el = document.createElement("div");
      el.className = "msg " + role;
      if (role === "bot") {
        el.innerHTML = '<div class="msg-role">' + Vi.icon("moon") + " MoonBot</div>" +
          '<div class="md"></div>';
        el.querySelector(".md").textContent = text;
      } else {
        el.textContent = text;
      }
      this.body.appendChild(el);
      this.body.scrollTop = this.body.scrollHeight;
      return el;
    },

    /* inline completion used by Alt-\ (Ghost AI) */
    async complete(opts) {
      return Vi.api.post("/api/ollama/complete", {
        model: this.currentModel(),
        prefix: opts.prefix || "",
        suffix: opts.suffix || "",
        max_tokens: opts.max_tokens,
      });
    },
  };

  MoonBot.SYSTEM_PROMPT =
    "You are MoonBot, a concise coding assistant living inside the ViMoon editor. " +
    "Give short, correct, actionable answers. Use fenced code blocks for code. " +
    "Respond in the user's language.";

  window.MoonBot = MoonBot;
})();
