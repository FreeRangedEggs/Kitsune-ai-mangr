/* ============================================================
 * ViMoon — search.js
 * Project-wide search (sidebar tab) + per-tab jump-to-match.
 * ============================================================ */
(function () {
  "use strict";

  const Search = {
    opts: { case_sensitive: false, regex: false, ext: "" },

    init() {
      this.input = document.getElementById("search-input");
      this.results = document.getElementById("search-results");
      this.btnCase = document.getElementById("opt-case");
      this.btnRegex = document.getElementById("opt-regex");
      this.selExt = document.getElementById("opt-ext");

      this.btnCase.addEventListener("click", () => {
        this.opts.case_sensitive = !this.opts.case_sensitive;
        this.btnCase.classList.toggle("active", this.opts.case_sensitive);
        this.run();
      });
      this.btnRegex.addEventListener("click", () => {
        this.opts.regex = !this.opts.regex;
        this.btnRegex.classList.toggle("active", this.opts.regex);
        this.run();
      });
      this.selExt.addEventListener("change", () => {
        this.opts.ext = this.selExt.value;
        this.run();
      });
      this.input.addEventListener("input", Vi.debounce(() => this.run(), 320));
      this.input.addEventListener("keydown", (e) => {
        if (e.key === "Escape") this.input.blur();
      });
    },

    focus() {
      // switch sidebar to the search tab and focus input
      Vi.$$(".side-tab").forEach((b) =>
        b.classList.toggle("active", b.dataset.side === "search"));
      document.getElementById("side-search").classList.add("active");
      document.getElementById("side-files").classList.remove("active");
      if (document.body.classList.contains("no-sidebar")) App.toggleSidebar(true);
      this.input.focus();
      this.input.select();
    },

    async run() {
      const q = this.input.value.trim();
      if (!q) {
        this.results.innerHTML = '<div class="sr-status">Type to search across every file in the workspace.</div>';
        return;
      }
      this.results.innerHTML = '<div class="sr-status">Searching…</div>';
      let r;
      try {
        r = await Vi.api.post("/api/search", {
          query: q,
          case_sensitive: this.opts.case_sensitive,
          regex: this.opts.regex,
          ext: this.opts.ext,
        });
      } catch (err) {
        this.results.innerHTML = '<div class="sr-error">' + Vi.esc(err.message) + "</div>";
        return;
      }
      if (r.error) {
        this.results.innerHTML = '<div class="sr-error">' + Vi.esc(r.error) + "</div>";
        return;
      }
      if (!r.results.length) {
        this.results.innerHTML = '<div class="sr-status">No matches in ' + r.files_searched + " files.</div>";
        return;
      }

      this.results.innerHTML = "";
      const summary = document.createElement("div");
      summary.className = "sr-status";
      summary.textContent = r.matches + " match" + (r.matches === 1 ? "" : "es") +
        " · " + r.results.length + " file" + (r.results.length === 1 ? "" : "s") +
        " · " + r.duration_ms + " ms" + (r.truncated ? " (truncated)" : "");
      this.results.appendChild(summary);

      for (const file of r.results) {
        const wrap = document.createElement("div");
        wrap.className = "sr-file";
        const head = document.createElement("div");
        head.className = "sr-file-head";
        head.innerHTML = Vi.icon("file").replace("<svg", '<svg width="12" height="12"') +
          " <span>" + Vi.esc(file.path) + '</span> <span class="count">' + file.matches.length + "</span>";
        head.addEventListener("click", () => Tabs.open(file.path));
        wrap.appendChild(head);

        for (const m of file.matches.slice(0, 12)) {
          const line = document.createElement("div");
          line.className = "sr-line";
          line.innerHTML = '<span class="ln">' + m.line + "</span>" + this.hilit(m.text, r.query, this.opts);
          line.addEventListener("click", () => this.jumpTo(file.path, m));
          wrap.appendChild(line);
        }
        if (file.matches.length > 12) {
          const more = document.createElement("div");
          more.className = "sr-status";
          more.style.paddingLeft = "18px";
          more.textContent = "… " + (file.matches.length - 12) + " more";
          wrap.appendChild(more);
        }
        this.results.appendChild(wrap);
      }
    },

    hilit(text, query, opts) {
      let idx = -1, len = query.length;
      try {
        if (opts.regex) {
          const m = new RegExp(query, opts.case_sensitive ? "" : "i").exec(text);
          if (m) { idx = m.index; len = m[0].length; }
        } else {
          idx = (opts.case_sensitive ? text : text.toLowerCase())
            .indexOf(opts.case_sensitive ? query : query.toLowerCase());
        }
      } catch (e) { /* invalid regex mid-typing */ }
      const esc = Vi.esc(text);
      if (idx < 0) return esc;
      return Vi.esc(text.slice(0, idx)) + "<mark>" + Vi.esc(text.slice(idx, idx + len)) + "</mark>" +
        Vi.esc(text.slice(idx + len));
    },

    async jumpTo(path, m) {
      const t = await Tabs.open(path);
      if (!t || !editor) return;
      editor.setCursor({ line: m.line - 1, ch: m.col });
      editor.setSelection(
        { line: m.line - 1, ch: m.col },
        { line: m.line - 1, ch: m.col + Math.max(1, m.text.trim().length ? 1 : 1) }
      );
      editor.scrollIntoView({ line: m.line - 1, ch: 0 }, 120);
      editor.focus();
    },
  };

  window.SearchPanel = Search;
})();
