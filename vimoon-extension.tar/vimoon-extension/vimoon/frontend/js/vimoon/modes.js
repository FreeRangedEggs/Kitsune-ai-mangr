/* ============================================================
 * ViMoon — modes.js
 * Language detection + lazy CodeMirror mode loading.
 * ============================================================ */
(function () {
  "use strict";

  const VENDOR = "/vendor/codemirror/mode/";

  /* ext -> [script, modeSpec, displayLabel] */
  const MAP = {
    py:      ["python", "text/x-python", "Python"],
    pyw:     ["python", "text/x-python", "Python"],
    js:      ["javascript", "text/javascript", "JavaScript"],
    mjs:     ["javascript", "text/javascript", "JavaScript"],
    jsx:     ["javascript", "text/javascript", "JavaScript"],
    ts:      ["javascript", "text/javascript", "TypeScript*"],
    json:    ["javascript", { name: "javascript", json: true }, "JSON"],
    html:    ["htmlmixed", "text/html", "HTML"],
    htm:     ["htmlmixed", "text/html", "HTML"],
    xml:     ["xml", "text/xml", "XML"],
    svg:     ["xml", "text/xml", "XML"],
    css:     ["css", "text/css", "CSS"],
    scss:    ["css", "text/x-scss", "SCSS"],
    less:    ["css", "text/x-less", "Less"],
    md:      ["markdown", "text/x-markdown", "Markdown"],
    markdown:["markdown", "text/x-markdown", "Markdown"],
    c:       ["clike", "text/x-csrc", "C"],
    h:       ["clike", "text/x-csrc", "C"],
    cpp:     ["clike", "text/x-c++src", "C++"],
    cc:      ["clike", "text/x-c++src", "C++"],
    cxx:     ["clike", "text/x-c++src", "C++"],
    hpp:     ["clike", "text/x-c++src", "C++"],
    java:    ["clike", "text/x-java", "Java"],
    cs:      ["clike", "text/x-csharp", "C#"],
    go:      ["go", "text/x-go", "Go"],
    rs:      ["rust", "text/x-rustsrc", "Rust"],
    sh:      ["shell", "text/x-sh", "Shell"],
    bash:    ["shell", "text/x-sh", "Shell"],
    zsh:     ["shell", "text/x-sh", "Shell"],
    yaml:    ["yaml", "text/x-yaml", "YAML"],
    yml:     ["yaml", "text/x-yaml", "YAML"],
    sql:     ["sql", "text/x-sql", "SQL"],
    php:     ["php", "application/x-httpd-php", "PHP"],
    dockerfile: ["dockerfile", "text/x-dockerfile", "Dockerfile"],
  };

  /* modes that must be loaded before the target mode */
  const DEPS = {
    htmlmixed: ["xml", "javascript", "css"],
    php: ["xml", "javascript", "css", "clike", "htmlmixed"],
    markdown: ["xml"],
  };

  const loaded = { "null": true };
  const pending = {};

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.onload = resolve;
      s.onerror = () => reject(new Error("Failed to load " + src));
      document.head.appendChild(s);
    });
  }

  async function loadMode(script) {
    if (loaded[script]) return;
    if (pending[script]) return pending[script];
    for (const dep of DEPS[script] || []) {
      await loadMode(dep);
    }
    pending[script] = loadScript(VENDOR + script + "/" + script + ".js")
      .then(() => { loaded[script] = true; })
      .catch((e) => { console.warn(e); })
      .finally(() => { delete pending[script]; });
    await pending[script];
  }

  window.Modes = {
    infoFor(fileName) {
      return MAP[Vi.extOf(fileName)] || null;
    },
    labelFor(fileName) {
      const m = MAP[Vi.extOf(fileName)];
      return m ? m[2] : "Plain Text";
    },
    async apply(tab, editor) {
      const info = MAP[Vi.extOf(tab.name)];
      if (!info) {
        tab.modeMime = "text/plain";
        if (editor) editor.setOption("mode", "text/plain");
        return;
      }
      await loadMode(info[0]);
      tab.modeMime = info[1];
      if (editor && window.Tabs && Tabs.activeId === tab.id) {
        editor.setOption("mode", info[1]);
      }
    },
  };
})();
