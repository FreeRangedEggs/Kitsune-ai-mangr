/* ============================================================
 * ViMoon — editor.js
 * CodeMirror instance, Vim integration + ex commands,
 * intelligent completion and MoonBot ghost suggestions.
 * ============================================================ */
(function () {
  "use strict";

  let editor = null;
  window.editor = null; // assigned after create

  /* ---------------------------------------------------------
   * Completion word pools (context = language + document words)
   * --------------------------------------------------------- */
  const WORDS = {
    python: [
      "def", "class", "return", "import", "from", "as", "if", "elif", "else",
      "for", "while", "break", "continue", "pass", "with", "try", "except",
      "finally", "raise", "yield", "lambda", "global", "nonlocal", "assert",
      "async", "await", "del", "in", "is", "not", "and", "or", "None", "True",
      "False", "print", "len", "range", "enumerate", "zip", "map", "filter",
      "sorted", "sum", "min", "max", "abs", "round", "isinstance", "type",
      "str", "int", "float", "list", "dict", "set", "tuple", "bool", "open",
      "super", "self", "cls", "classmethod", "staticmethod", "property",
      "dataclass", "Exception", "ValueError", "TypeError", "KeyError",
      "IndexError", "AttributeError", "os", "sys", "json", "re", "time",
      "datetime", "pathlib", "collections", "itertools", "typing", "Optional",
      "List", "Dict", "Set", "Tuple", "Any", "Callable", "__init__", "__str__",
      "__repr__", "__name__", "__main__",
    ],
    javascript: [
      "const", "let", "var", "function", "return", "if", "else", "for", "while",
      "do", "switch", "case", "break", "continue", "new", "class", "extends",
      "super", "this", "import", "export", "default", "from", "as", "async",
      "await", "yield", "try", "catch", "finally", "throw", "typeof",
      "instanceof", "delete", "in", "of", "null", "undefined", "true", "false",
      "console", "log", "error", "warn", "document", "window", "fetch", "then",
      "catch", "Promise", "Array", "Object", "String", "Number", "Boolean",
      "Math", "JSON", "Map", "Set", "Symbol", "Proxy", "Reflect", "setTimeout",
      "setInterval", "clearTimeout", "requestAnimationFrame", "querySelector",
      "querySelectorAll", "addEventListener", "removeEventListener",
      "createElement", "forEach", "map", "filter", "reduce", "find", "includes",
      "push", "pop", "slice", "splice", "join", "split", "trim", "replace",
    ],
    clike: [
      "int", "char", "float", "double", "void", "long", "short", "unsigned",
      "signed", "struct", "union", "enum", "typedef", "static", "const",
      "extern", "register", "volatile", "inline", "sizeof", "return", "if",
      "else", "for", "while", "do", "switch", "case", "default", "break",
      "continue", "goto", "printf", "scanf", "malloc", "calloc", "realloc",
      "free", "memcpy", "memset", "strlen", "strcmp", "strcpy", "NULL", "std",
      "cout", "cin", "endl", "vector", "string", "map", "set", "pair", "make_pair",
      "public", "private", "protected", "virtual", "override", "namespace",
      "template", "typename", "class", "new", "delete", "this", "bool", "true", "false",
    ],
  };

  function langKey(tab) {
    if (!tab) return null;
    const ext = Vi.extOf(tab.name);
    if (["py", "pyw"].includes(ext)) return "python";
    if (["js", "mjs", "jsx", "ts", "json"].includes(ext)) return "javascript";
    if (["c", "h", "cpp", "cc", "cxx", "hpp", "java", "cs", "go", "rs"].includes(ext)) return "clike";
    return null;
  }

  function vimoonHint(cm, callback) {
    const cur = cm.getCursor();
    const line = cm.getLine(cur.line);
    let start = cur.ch;
    while (start > 0 && /[\w$]/.test(line.charAt(start - 1))) start--;
    const prefix = line.slice(start, cur.ch);
    const token = cm.getTokenAt(cur);

    if (token && token.type && /comment/.test(token.type)) return callback(null);
    if (prefix.length < 2) return callback(null);

    const lang = langKey(window.Tabs ? Tabs.active() : null);
    const pool = new Set(WORDS[lang] || []);
    // words from the open document
    const text = cm.getValue();
    const matches = text.match(/[A-Za-z_$][\w$]{2,}/g) || [];
    for (let i = 0; i < matches.length && i < 6000; i++) pool.add(matches[i]);

    const lower = prefix.toLowerCase();
    const list = [];
    for (const w of pool) {
      if (w === prefix) continue;
      const wl = w.toLowerCase();
      if (wl.startsWith(lower)) list.push({ w, score: 0, exact: true });
      else if (wl.includes(lower) && prefix.length >= 3) list.push({ w, score: 1 });
    }
    list.sort((a, b) => a.score - b.score || a.w.length - b.w.length);
    callback({
      list: list.slice(0, 60).map((it) => ({ text: it.w, displayText: it.w })),
      from: CodeMirror.Pos(cur.line, start),
      to: cur,
    });
  }
  vimoonHint.async = true;

  /* ---------------------------------------------------------
   * MoonBot ghost completion (Alt-\)
   * --------------------------------------------------------- */
  const Ghost = {
    active: null,
    available: async function () {
      if (!window.MoonBot) return false;
      const st = await MoonBot.ensureStatus();
      return !!(st && st.reachable);
    },
    async trigger() {
      if (!editor || editor.getOption("readOnly")) {
        Vi.toast("Nothing to complete here", "warning");
        return;
      }
      if (!(await Ghost.available())) {
        Vi.toast("MoonBot needs Ollama — open the MoonBot panel for setup", "warning");
        Vi.bus.emit("open-panel", "bot");
        return;
      }
      Ghost.clear();
      const cur = editor.getCursor();
      const fromLine = Math.max(0, cur.line - 50);
      const prefix = editor.getRange({ line: fromLine, ch: 0 }, cur);
      const toLine = Math.min(editor.lineCount() - 1, cur.line + 15);
      const suffix = editor.getRange(cur, { line: toLine, ch: editor.getLine(toLine).length });

      StatusBar.botThinking(true);
      try {
        const r = await MoonBot.complete({ prefix, suffix });
        StatusBar.botThinking(false);
        let text = (r.completion || "").replace(/```[a-z]*\n?/gi, "").trimEnd();
        if (!text) { Vi.toast("MoonBot: no suggestion", "info"); return; }
        const lines = text.split("\n").slice(0, 3);
        text = lines.join("\n");
        const widget = document.createElement("span");
        widget.className = "cm-ghost";
        widget.textContent = text;
        const mark = editor.setBookmark(cur, { widget, insertLeft: false });
        Ghost.active = {
          mark, text,
          keymap: {
            Tab: () => { Ghost.accept(); },
            Esc: () => { Ghost.clear(); },
          },
        };
        editor.addKeyMap(Ghost.active.keymap);
      } catch (err) {
        StatusBar.botThinking(false);
        Vi.toast("MoonBot: " + err.message, "error");
      }
    },
    accept() {
      if (!Ghost.active) return;
      const g = Ghost.active;
      Ghost.clear();
      editor.replaceSelection(g.text);
    },
    clear() {
      if (!Ghost.active) return;
      try { Ghost.active.mark.clear(); } catch (e) { /* already gone */ }
      editor.removeKeyMap(Ghost.active.keymap);
      Ghost.active = null;
    },
  };
  window.GhostAI = Ghost;

  /* ---------------------------------------------------------
   * Vim ex commands
   * --------------------------------------------------------- */
  function defineEx(name, alias, fn) {
    if (CodeMirror.Vim) CodeMirror.Vim.defineEx(name, alias, fn);
  }

  function setupVim() {
    if (!CodeMirror.Vim) return;

    defineEx("write", "w", () => { App.saveActive(); });
    defineEx("wq", "wq", () => { App.saveActive(true).then(() => Tabs.closeActive()); });
    defineEx("x", "x", () => { App.saveActive(true).then(() => Tabs.closeActive()); });
    defineEx("quit", "q", () => {
      const t = Tabs.active();
      if (t && t.dirty && !t.readOnly) {
        Vi.toast("No write since last change (use :wq or :q!)", "warning");
        return;
      }
      Tabs.closeActive();
    });
    defineEx("qall", "qa", () => { window.close(); });
    defineEx("nohlsearch", "noh", (cm) => {
      if (cm) cm.execCommand("clearSearch");
    });
    defineEx("set", "set", (cm, params) => {
      const arg = (params.args && params.args[0]) || "";
      const on = !arg.startsWith("no");
      const key = arg.replace(/^no/, "");
      if (key === "nu" || key === "number") Settings.set("line_numbers", on);
      else if (key === "wrap") Settings.set("word_wrap", on);
      else if (key === "vim") Settings.set("vim_mode", on);
      else if (key === "spell") Vi.toast("Spell check is not available (MoonBot proofreads better)", "info");
      else Vi.toast(":set supports nu/nonu, wrap/nowrap, vim/novim", "info");
    });
    defineEx("theme", "theme", (_cm, params) => {
      const arg = params.args && params.args[0];
      if (["moonlight", "dark", "dawn"].includes(arg)) Settings.set("theme", arg);
      else Vi.toast("themes: moonlight · dark · dawn", "info");
    });
    defineEx("bot", "bot", () => { Vi.bus.emit("open-panel", "bot"); });
    defineEx("git", "git", () => { Vi.bus.emit("open-panel", "git"); });
    defineEx("settings", "settings", () => { Settings.openModal(); });
    defineEx("plugins", "plugins", () => { Vi.bus.emit("open-panel", "plugins"); });
    defineEx("zen", "zen", () => { document.body.classList.toggle("zen"); setTimeout(() => editor.refresh(), 60); });
  }

  /* ---------------------------------------------------------
   * Editor factory
   * --------------------------------------------------------- */
  const Editor = {
    create(textarea) {
      const S = Settings.raw();
      editor = CodeMirror.fromTextArea(textarea, {
        mode: "text/plain",
        theme: "vimoon",
        keyMap: S.vim_mode ? "vim" : "default",
        lineNumbers: S.line_numbers,
        lineWrapping: S.word_wrap,
        indentUnit: S.tab_size,
        tabSize: S.tab_size,
        indentWithTabs: S.indent_with_tabs,
        autoCloseBrackets: S.bracket_close,
        matchBrackets: true,
        styleActiveLine: S.highlight_active_line,
        foldGutter: S.code_folding,
        gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
        inputStyle: "textarea",
        scrollbarStyle: "native",
        extraKeys: {
          "Ctrl-Space": "autocomplete",
          "Ctrl-F": "findPersistent",
          "Cmd-F": "findPersistent",
          "Ctrl-H": "replace",
          "Alt-G": "jumpToLine",
          "Ctrl-/": "toggleComment",
          "Cmd-/": "toggleComment",
          "Alt-\\": () => Ghost.trigger(),
          "Shift-Alt-\\": () => Ghost.trigger(),
        },
        hintOptions: { hint: vimoonHint, completeSingle: false, alignWithWord: true },
      });
      window.editor = editor;

      /* --- events --- */
      editor.on("cursorActivity", () => {
        Ghost.clear();
        StatusBar.updateCursor();
      });
      editor.on("change", (_cm, change) => {
        if (change.origin === "setValue") return;
        const t = Tabs.active();
        if (t && !t.readOnly) {
          t.lastChange = Date.now();
          const clean = t.doc.isClean(t.cleanGen);
          if (!clean && !t.dirty) Tabs.markDirty(t, true);
          Vi.bus.emit("editor-change", t);
        }
      });
      editor.on("inputRead", (cm, change) => {
        if (!Settings.raw().auto_completion) return;
        const text = change.text.join("");
        if (!/^[A-Za-z_][\w$]?$/.test(text)) return;
        const cur = cm.getCursor();
        const line = cm.getLine(cur.line);
        let start = cur.ch;
        while (start > 0 && /[\w$]/.test(line.charAt(start - 1))) start--;
        if (cur.ch - start < 2) return;
        cm.showHint({
          hint: vimoonHint,
          completeSingle: false,
          alignWithWord: true,
          closeCharacters: /[\s()\[\]{};:>,]/,
        });
      });
      editor.on("vim-mode-change", (e) => {
        StatusBar.setMode(e.mode);
      });

      setupVim();
      if (S.vim_mode) StatusBar.setMode("normal");
      return editor;
    },

    vimoonHint,
  };

  window.Editor = Editor;
})();
