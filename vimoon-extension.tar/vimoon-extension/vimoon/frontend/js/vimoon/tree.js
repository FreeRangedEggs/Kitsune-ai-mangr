/* ============================================================
 * ViMoon — tree.js
 * Sidebar file explorer: lazy directory expansion, create /
 * rename / delete, open-on-click.
 * ============================================================ */
(function () {
  "use strict";

  const Tree = {
    expanded: new Set([""]),
    cache: {},

    init() {
      this.el = document.getElementById("file-tree");
      this.render();
      document.getElementById("btn-refresh-tree").addEventListener("click", () => this.refresh());
    },

    invalidate() { this.cache = {}; },

    async children(rel) {
      if (this.cache[rel]) return this.cache[rel];
      const r = await Vi.api.get("/api/files/tree?path=" + encodeURIComponent(rel || ""));
      this.cache[rel] = r.entries || [];
      return this.cache[rel];
    },

    async refresh() {
      this.invalidate();
      await this.render();
    },

    async render() {
      const rootEntries = await this.children("").catch(() => []);
      this.el.innerHTML = "";
      if (!rootEntries.length) {
        this.el.innerHTML = '<div class="tree-empty">Workspace is empty.<br>Create your first file with <b>+</b> above.</div>';
        return;
      }
      this.renderLevel(rootEntries, this.el, 0);
      const active = Tabs.active();
      if (active) this.highlight(active.path);
    },

    renderLevel(entries, container, depth) {
      for (const e of entries) {
        container.appendChild(this.row(e, depth));
        if (e.type === "dir" && this.expanded.has(e.path)) {
          const wrap = document.createElement("div");
          wrap.className = "tree-children";
          wrap.dataset.dir = e.path;
          container.appendChild(wrap);
          if (this.cache[e.path]) this.renderLevel(this.cache[e.path], wrap, depth + 1);
          else this.loadChildrenInto(e.path, wrap, depth + 1);
        }
      }
    },

    async loadChildrenInto(rel, wrap, depth) {
      const kids = await this.children(rel).catch(() => []);
      wrap.innerHTML = "";
      this.renderLevel(kids, wrap, depth);
    },

    row(e, depth) {
      const el = document.createElement("div");
      el.className = "tree-row " + (e.type === "dir" ? "dir" : "file");
      el.style.paddingLeft = 8 + depth * 14 + "px";
      el.dataset.path = e.path;
      el.dataset.type = e.type;
      const isDir = e.type === "dir";
      el.innerHTML =
        (isDir
          ? '<span class="twist">' + Vi.icon("chevron") + "</span>" +
            '<span class="ficon">' + Vi.icon("folder") + "</span>"
          : '<span class="twist"></span><span class="ficon">' + Vi.icon("file") + "</span>") +
        '<span class="fname">' + Vi.esc(e.name) + "</span>" +
        '<span class="row-actions">' +
        (isDir ? '<button class="tbtn sm act-newfile" title="New file here">' + Vi.icon("plus") + "</button>" : "") +
        '<button class="tbtn sm act-rename" title="Rename">' + Vi.icon("pen") + "</button>" +
        '<button class="tbtn sm act-delete" title="Delete">' + Vi.icon("trash") + "</button>" +
        "</span>";

      el.addEventListener("click", async (ev) => {
        if (ev.target.closest(".row-actions")) return;
        if (isDir) {
          const kidsWrap = el.nextElementSibling;
          if (this.expanded.has(e.path)) {
            this.expanded.delete(e.path);
            if (kidsWrap) kidsWrap.remove();
            el.classList.remove("open");
          } else {
            this.expanded.add(e.path);
            el.classList.add("open");
            const wrap = document.createElement("div");
            wrap.className = "tree-children";
            el.after(wrap);
            await this.loadChildrenInto(e.path, wrap, depth + 1);
          }
        } else {
          Tabs.open(e.path);
        }
      });

      el.querySelector(".act-newfile")?.addEventListener("click", async (ev) => {
        ev.stopPropagation();
        const name = await Vi.prompt("New file", "Create a file inside " + (e.path || "./") + ":", "", "e.g. script.py");
        if (name) {
          await Vi.api.post("/api/files/create", { path: (e.path ? e.path + "/" : "") + name, type: "file" });
          this.expanded.add(e.path);
          await this.refresh();
          Tabs.open((e.path ? e.path + "/" : "") + name);
        }
      });
      el.querySelector(".act-rename")?.addEventListener("click", async (ev) => {
        ev.stopPropagation();
        const nn = await Vi.prompt("Rename", "New name for " + e.name + ":", e.name);
        if (nn && nn !== e.name) {
          const parent = e.path.includes("/") ? e.path.slice(0, e.path.lastIndexOf("/")) : "";
          await Vi.api.post("/api/files/rename", { path: e.path, new_path: (parent ? parent + "/" : "") + nn });
          await this.refresh();
          Vi.toast("Renamed to " + nn, "success", 1800);
        }
      });
      el.querySelector(".act-delete")?.addEventListener("click", async (ev) => {
        ev.stopPropagation();
        const ok = await Vi.confirm("Delete", "Delete " + (isDir ? "folder" : "file") + ' "' + e.name + '"? This cannot be undone.', { danger: true, okLabel: "Delete" });
        if (ok) {
          await Vi.api.post("/api/files/delete", { path: e.path });
          const t = Tabs.byPath(e.path);
          if (t) Tabs.close(t.id, { noConfirm: true });
          await this.refresh();
          Vi.toast("Deleted " + e.name, "success", 1800);
        }
      });
      return el;
    },

    highlight(path) {
      Vi.$$(".tree-row", this.el).forEach((r) => {
        r.classList.toggle("active-file", r.dataset.path === path);
      });
    },
  };

  window.Tree = Tree;
})();
