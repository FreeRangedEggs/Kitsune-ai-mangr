/* ============================================================
 * ViMoon — plugins.js
 * Plugin loader + the small API surface plugins receive
 * (see docs/PLUGIN_API.md).
 * ============================================================ */
(function () {
  "use strict";

  const Plugins = {
    registry: [],

    init() {
      this.root = document.getElementById("plugins-root");
      this.load();
    },

    async load() {
      try {
        const r = await Vi.api.get("/api/plugins");
        this.registry = r.plugins || [];
      } catch (err) {
        this.registry = [];
      }
      this.render();
      // activate enabled plugins
      for (const p of this.registry) {
        if (!p.enabled || !p.installed) continue;
        this.inject(p);
      }
    },

    inject(p) {
      const s = document.createElement("script");
      s.src = "/plugins/" + p.id + "/" + p.main;
      s.onerror = () => console.warn("[ViMoon] plugin failed to load:", p.id);
      document.head.appendChild(s);
    },

    contextFor(id) {
      return {
        id,
        version: Vi.version,
        editor: () => window.editor,
        activeTab: () => (window.Tabs ? Tabs.active() : null),
        settings: () => Settings.raw(),
        openFile: (p) => Tabs.open(p),
        notify: (msg, type) => Vi.toast(String(msg), type || "info"),
        registerCommand: (cmd) => {
          if (window.App && cmd && cmd.id && cmd.title && typeof cmd.run === "function") {
            App.addCommand({
              id: cmd.id, title: cmd.title, key: cmd.key || null,
              icon: cmd.icon || "plug", run: cmd.run,
            });
          }
        },
        addStatusItem: (el) => {
          const host = document.getElementById("plugin-status-items");
          if (host) host.appendChild(el);
        },
        on: (ev, fn) => Vi.bus.on(ev, fn),
      };
    },

    async toggle(id, enabled) {
      try {
        await Vi.api.post("/api/plugins/toggle", { id, enabled });
        Vi.toast(enabled
          ? "Plugin enabled — it will load on the next reload"
          : "Plugin disabled — it will unload on the next reload", "info", 2600);
      } catch (err) {
        Vi.toast(err.message, "error");
      }
      await this.load();
    },

    render() {
      if (!this.root) return;
      if (!this.registry.length) {
        this.root.innerHTML =
          '<div class="git-empty">' + Vi.icon("plug") +
          "<br>No plugins found." +
          '<br>Drop a plugin folder into <code style="font-family:var(--code-font);color:var(--accent)">plugins/</code> and reload.' +
          '<br>See docs/PLUGIN_API.md to build your own.</div>';
        return;
      }
      this.root.innerHTML = "";
      for (const p of this.registry) {
        const card = document.createElement("div");
        card.className = "plugin-card";
        card.innerHTML =
          '<div class="p-head"><span class="p-name">' + Vi.esc(p.name) + "</span>" +
          '<span class="p-ver">v' + Vi.esc(p.version) + "</span>" +
          '<button class="switch' + (p.enabled ? " on" : "") + '" style="margin-left:auto"></button></div>' +
          '<div class="p-desc">' + Vi.esc(p.description) + "</div>" +
          '<div class="p-author">by ' + Vi.esc(p.author) + (p.installed ? "" : " · main file missing") + "</div>";
        card.querySelector(".switch").addEventListener("click", (e) => {
          const now = !e.target.classList.contains("on");
          this.toggle(p.id, now);
        });
        this.root.appendChild(card);
      }
      const note = document.createElement("div");
      note.className = "plugins-note";
      note.innerHTML = "Plugins are folders inside <code>plugins/</code> with a " +
        "<code>manifest.json</code> and a <code>main.js</code>. They can add commands " +
        "to the palette, status-bar items and react to editor events. Full API: " +
        "<code>docs/PLUGIN_API.md</code>.";
      this.root.appendChild(note);
    },
  };

  /* global hook every plugin calls */
  window.ViMoon = {
    register(def) {
      try {
        if (!def || !def.id || typeof def.init !== "function") {
          console.warn("[ViMoon] invalid plugin registration", def && def.id);
          return;
        }
        def.init(Plugins.contextFor(def.id));
        console.info("[ViMoon] plugin ready:", def.id);
      } catch (err) {
        console.warn("[ViMoon] plugin error:", def && def.id, err);
      }
    },
  };

  window.Plugins = Plugins;
})();
