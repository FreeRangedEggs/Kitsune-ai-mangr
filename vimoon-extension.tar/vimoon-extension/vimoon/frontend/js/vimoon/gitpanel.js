/* ============================================================
 * ViMoon — gitpanel.js
 * Git integration UI: status, staging, commit, history, diffs.
 * ============================================================ */
(function () {
  "use strict";

  const Git = {
    data: null,

    init() {
      this.root = document.getElementById("git-root");
      Vi.bus.on("open-panel", (name) => { if (name === "git") this.refresh(); });
      Vi.bus.on("file-saved", Vi.debounce(() => {
        if (this.root.offsetParent !== null) this.refresh();
      }, 1200));
    },

    async refresh() {
      try {
        this.data = await Vi.api.get("/api/git/status");
      } catch (err) {
        this.root.innerHTML = '<div class="git-empty">' + Vi.esc(err.message) + "</div>";
        return;
      }
      this.render();
      StatusBar.setBranch(this.data.repo ? this.data.branch : null);
    },

    async render() {
      const d = this.data;
      if (!d || !d.repo) {
        this.root.innerHTML =
          '<div class="git-empty">' + Vi.icon("git") +
          "<br>This workspace is not a git repository yet." +
          "<br>Version your moonlight masterpiece:" +
          '<br><button class="btn primary" id="git-init" style="margin-top:12px">Initialize repository</button></div>';
        this.root.querySelector("#git-init").addEventListener("click", async () => {
          try {
            await Vi.api.post("/api/git/init", {});
            Vi.toast("Git repository initialized", "success");
            this.refresh();
          } catch (err) { Vi.toast(err.message, "error"); }
        });
        return;
      }

      const staged = d.staged || [], unstaged = d.unstaged || [], untracked = d.untracked || [];
      this.root.innerHTML =
        this.branchCard() +
        this.fileCard("Staged", staged, "staged") +
        this.fileCard("Changes", unstaged, "unstaged") +
        this.fileCard("Untracked", untracked, "untracked") +
        this.commitCard() +
        '<div class="git-card" id="git-log-card"><h4>' + Vi.icon("clock") + ' History <span class="cnt"></span></h4><div id="git-log">Loading…</div></div>';

      // wiring
      this.root.querySelector("#git-branch-sel")?.addEventListener("change", async (e) => {
        const b = e.target.value;
        if (b && b !== d.branch) {
          try { await Vi.api.post("/api/git/checkout", { branch: b }); Vi.toast("Switched to " + b, "success"); }
          catch (err) { Vi.toast(err.message, "error"); }
          this.refresh();
        }
      });
      this.root.querySelector("#git-stage-all")?.addEventListener("click", async () => {
        const paths = unstaged.map((f) => f.path).concat(untracked.map((f) => f.path));
        if (paths.length) {
          await Vi.api.post("/api/git/action", { action: "stage", paths }).catch((e) => Vi.toast(e.message, "error"));
          this.refresh();
        }
      });
      const commitBtn = this.root.querySelector("#git-commit-btn");
      const msgBox = this.root.querySelector("#git-msg");
      commitBtn.addEventListener("click", async () => {
        const message = msgBox.value.trim();
        if (!message) { Vi.toast("Write a commit message first", "warning"); msgBox.focus(); return; }
        try {
          await Vi.api.post("/api/git/commit", { message });
          msgBox.value = "";
          Vi.toast("Committed under the moon", "success", 2000);
          this.refresh();
        } catch (err) { Vi.toast(err.message, "error"); }
      });
      msgBox.addEventListener("keydown", (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === "Enter") commitBtn.click();
      });

      // file actions
      this.root.querySelectorAll(".git-file").forEach((el) => {
        const group = el.dataset.group;
        const path = el.dataset.path;
        el.addEventListener("click", (e) => {
          if (e.target.closest("button")) return;
          if (group === "untracked") Tabs.open(path);
          else this.diffModal(path, group === "staged");
        });
        el.querySelector(".act-stage")?.addEventListener("click", async () => {
          await Vi.api.post("/api/git/action", { action: "stage", paths: [path] }).catch((e2) => Vi.toast(e2.message, "error"));
          this.refresh();
        });
        el.querySelector(".act-unstage")?.addEventListener("click", async () => {
          await Vi.api.post("/api/git/action", { action: "unstage", paths: [path] }).catch((e2) => Vi.toast(e2.message, "error"));
          this.refresh();
        });
        el.querySelector(".act-discard")?.addEventListener("click", async () => {
          if (group === "untracked") {
            const ok = await Vi.confirm("Delete file", "Delete untracked file " + path + "?", { danger: true, okLabel: "Delete" });
            if (!ok) return;
            await Vi.api.post("/api/files/delete", { path }).catch((e2) => Vi.toast(e2.message, "error"));
            const t = Tabs.byPath(path); if (t) Tabs.close(t.id, { noConfirm: true });
          } else {
            const ok = await Vi.confirm("Discard changes", "Discard local changes to " + path + "? This cannot be undone.", { danger: true, okLabel: "Discard" });
            if (!ok) return;
            await Vi.api.post("/api/git/action", { action: "discard", paths: [path] }).catch((e2) => Vi.toast(e2.message, "error"));
          }
          this.refresh();
        });
      });

      this.loadLog();
    },

    branchCard() {
      const d = this.data;
      const ahead = d.ahead ? '<span class="git-ahead">↑' + d.ahead + "</span>" : "";
      const behind = d.behind ? '<span class="git-ahead">↓' + d.behind + "</span>" : "";
      return (
        '<div class="git-card"><h4>' + Vi.icon("git") + " Repository</h4>" +
        '<div class="git-branch-row"><span class="dot online"></span>' + ahead + behind +
        '<select class="select" id="git-branch-sel"></select></div></div>'
      );
    },

    async fillBranches() {
      const sel = this.root.querySelector("#git-branch-sel");
      if (!sel) return;
      try {
        const r = await Vi.api.get("/api/git/branches");
        sel.innerHTML = "";
        for (const b of r.branches || []) {
          const o = document.createElement("option");
          o.value = o.textContent = b;
          if (b === r.current) o.selected = true;
          sel.appendChild(o);
        }
      } catch (e) { /* non-fatal */ }
    },

    fileCard(title, files, group) {
      const stClass = { M: "m", A: "a", D: "d", R: "r", C: "a", "?": "u", "U": "d" };
      const rows = files.map((f) => {
        const st = (group === "untracked" ? "?" : (f.x !== " " && f.x !== "?" ? f.x : f.y));
        const stageBtn = group === "unstaged" || group === "untracked"
          ? '<button class="tbtn sm act-stage" title="Stage">' + Vi.icon("plus") + "</button>" : "";
        const unstageBtn = group === "staged"
          ? '<button class="tbtn sm act-unstage" title="Unstage">' + Vi.icon("minus") + "</button>" : "";
        const discardBtn = group !== "staged"
          ? '<button class="tbtn sm act-discard" title="' + (group === "untracked" ? "Delete" : "Discard") + '">' + Vi.icon("undo") + "</button>" : "";
        return (
          '<div class="git-file" data-path="' + Vi.esc(f.path) + '" data-group="' + group + '" title="' + Vi.esc(f.path) + '">' +
          '<span class="st ' + (stClass[st] || "m") + '">' + Vi.esc(st) + "</span>" +
          '<span class="gp">' + Vi.esc(f.path) + "</span>" +
          '<span class="gf-act">' + stageBtn + unstageBtn + discardBtn + "</span></div>"
        );
      }).join("");
      return (
        '<div class="git-card"><h4>' + Vi.esc(title) +
        ' <span class="cnt">' + files.length + "</span>" +
        (group === "unstaged" && files.length ||
         group === "untracked" && files.length
          ? ' <button class="chip" id="git-stage-all" style="margin-left:auto">Stage all</button>'
          : "") + "</h4>" +
        (rows || '<div class="git-hint">Nothing here — clean as moonlight.</div>') +
        "</div>"
      );
    },

    commitCard() {
      return (
        '<div class="git-card git-commit-box"><h4>Commit</h4>' +
        '<textarea id="git-msg" placeholder="Commit message…  (Ctrl+Enter to commit)"></textarea>' +
        '<div class="git-commit-actions">' +
        '<button class="btn primary" id="git-commit-btn">' + Vi.icon("check").replace("<svg", '<svg width="13" height="13"') + " Commit staged</button>" +
        '<span class="git-hint">Staged files will be included.</span>' +
        "</div></div>"
      );
    },

    async loadLog() {
      const box = this.root.querySelector("#git-log");
      if (!box) return;
      try {
        const r = await Vi.api.get("/api/git/log?limit=40");
        const commits = r.commits || [];
        const cnt = this.root.querySelector("#git-log-card .cnt");
        if (cnt) cnt.textContent = commits.length;
        if (!commits.length) {
          box.innerHTML = '<div class="git-hint">No commits yet — make your first one above.</div>';
        } else {
          box.innerHTML = commits.map((c) =>
            '<div class="commit-item" data-hash="' + c.hash + '">' +
            '<div class="cm-msg">' + Vi.esc(c.message) + (c.refs ? ' <span class="cm-refs">' + Vi.esc(c.refs) + "</span>" : "") + "</div>" +
            '<div class="cm-meta"><span class="cm-hash">' + Vi.esc(c.short) + "</span>" +
            "<span>" + Vi.esc(c.author) + "</span><span>" + Vi.relTime(c.date) + "</span></div></div>"
          ).join("");
          box.querySelectorAll(".commit-item").forEach((el) => {
            el.addEventListener("click", () => this.showCommit(el.dataset.hash));
          });
        }
      } catch (e) {
        box.innerHTML = '<div class="git-hint">' + Vi.esc(e.message) + "</div>";
      }
      this.fillBranches();
    },

    diffLine(line) {
      if (line.startsWith("+++") || line.startsWith("---")) return '<span class="meta">' + Vi.esc(line) + "</span>";
      if (line.startsWith("@@")) return '<span class="hunk">' + Vi.esc(line) + "</span>";
      if (line.startsWith("+")) return '<span class="add">' + Vi.esc(line) + "</span>";
      if (line.startsWith("-")) return '<span class="del">' + Vi.esc(line) + "</span>";
      return Vi.esc(line);
    },

    async diffModal(path, staged) {
      try {
        const r = await Vi.api.get("/api/git/diff?path=" + encodeURIComponent(path) + "&staged=" + (staged ? "1" : "0"));
        const diffText = r.diff || "(no differences)";
        Vi.modal({
          title: "Diff — " + path + (staged ? " (staged)" : ""),
          wide: true,
          body: '<div class="diff-view">' + diffText.split("\n").map((l) => this.diffLine(l)).join("\n") + "</div>",
          buttons: [{ label: "Close" }],
        });
      } catch (err) { Vi.toast(err.message, "error"); }
    },

    async showCommit(hash) {
      try {
        const r = await Vi.api.get("/api/git/show?hash=" + encodeURIComponent(hash));
        Vi.modal({
          title: "Commit " + hash.slice(0, 9),
          wide: true,
          body: '<div class="diff-view">' + (r.diff || "").split("\n").map((l) => this.diffLine(l)).join("\n") + "</div>",
          buttons: [{ label: "Close" }],
        });
      } catch (err) { Vi.toast(err.message, "error"); }
    },
  };

  window.GitPanel = Git;
})();
