/* ============================================================
 * ViMoon — palette.js
 * Command palette + fuzzy file finder (Ctrl+P).
 * ============================================================ */
(function () {
  "use strict";

  const Palette = {
    fileIndex: null,
    items: [],
    selected: 0,

    init() {
      this.overlay = document.getElementById("palette");
      this.input = document.getElementById("palette-input");
      this.list = document.getElementById("palette-list");

      this.overlay.addEventListener("mousedown", (e) => {
        if (e.target === this.overlay) this.close();
      });
      this.input.addEventListener("input", () => this.render());
      this.input.addEventListener("keydown", (e) => {
        if (e.key === "ArrowDown") { e.preventDefault(); this.move(1); }
        else if (e.key === "ArrowUp") { e.preventDefault(); this.move(-1); }
        else if (e.key === "Enter") { e.preventDefault(); this.choose(); }
        else if (e.key === "Escape") { e.preventDefault(); this.close(); }
      });
    },

    open() {
      this.overlay.classList.remove("hidden");
      this.input.value = "";
      this.render();
      setTimeout(() => this.input.focus(), 10);
    },

    close() {
      this.overlay.classList.add("hidden");
      this.input.blur();
    },

    isOpen() { return !this.overlay.classList.contains("hidden"); },

    async fileIndexList() {
      if (this.fileIndex) return this.fileIndex;
      try {
        const r = await Vi.api.get("/api/files/tree?recursive=1");
        this.fileIndex = r.files || [];
      } catch (e) {
        this.fileIndex = [];
      }
      return this.fileIndex;
    },

    async buildItems() {
      const cmdItems = App.commands.map((c) => ({
        label: c.title, icon: c.icon || "zap", hint: c.key || "command",
        run: c.run,
      }));
      const staticItems = [
        { label: "Toggle file explorer", icon: "panel-left", hint: "Ctrl+B", run: () => App.toggleSidebar() },
        { label: "Toggle side panel", icon: "panel-right", hint: "Ctrl+'", run: () => App.toggleRight() },
        { label: "Open settings", icon: "gear", hint: "Ctrl+,", run: () => Settings.openModal() },
        { label: "Search in files", icon: "search", hint: "Ctrl+Shift+F", run: () => SearchPanel.focus() },
        { label: "New file", icon: "plus", hint: "", run: () => App.newFile() },
        { label: "Save file", icon: "save", hint: "Ctrl+S", run: () => App.saveActive() },
        { label: "Show keyboard shortcuts", icon: "help", hint: "F1", run: () => App.showHelp() },
        { label: "Open MoonBot panel", icon: "bot", hint: "Ctrl+'", run: () => { Vi.bus.emit("open-panel", "bot"); App.toggleRight(true); } },
        { label: "Open Git panel", icon: "git", hint: "", run: () => { Vi.bus.emit("open-panel", "git"); App.toggleRight(true); } },
        { label: "Toggle Zen mode", icon: "moon", hint: "Alt+Z", run: () => { document.body.classList.toggle("zen"); setTimeout(() => editor.refresh(), 60); } },
      ];
      const files = await this.fileIndexList();
      const fileItems = files.map((f) => ({
        label: f, icon: "file", hint: "file",
        run: () => Tabs.open(f),
      }));
      this.items = cmdItems.concat(staticItems).concat(fileItems);
    },

    async render() {
      const q = this.input.value.trim();
      await this.buildItems();
      let scored;
      if (!q) {
        scored = this.items.slice(0, 30).map((it) => ({ it, s: 0 }));
      } else {
        scored = [];
        for (const it of this.items) {
          const s = Vi.fuzzy(q, it.label);
          if (s >= 0) scored.push({ it, s });
        }
        scored.sort((a, b) => b.s - a.s);
        scored = scored.slice(0, 40);
      }
      this.selected = 0;
      if (!scored.length) {
        this.list.innerHTML = '<div class="pal-empty">No matches — try another word.</div>';
        this._current = [];
        return;
      }
      this._current = scored.map((x) => x.it);
      this.list.innerHTML = "";
      scored.forEach((entry, i) => {
        const el = document.createElement("div");
        el.className = "pal-item" + (i === 0 ? " selected" : "");
        el.innerHTML =
          '<span class="pal-ico">' + Vi.icon(entry.it.icon) + "</span>" +
          "<span>" + Vi.esc(entry.it.label) + "</span>" +
          '<span class="pal-hint">' + Vi.esc(entry.it.hint || "") + "</span>";
        el.addEventListener("click", () => { this.close(); entry.it.run(); });
        el.addEventListener("mousemove", () => {
          this.selected = i;
          this.paint();
        });
        this.list.appendChild(el);
      });
    },

    paint() {
      Vi.$$(".pal-item", this.list).forEach((el, i) => {
        el.classList.toggle("selected", i === this.selected);
      });
      const cur = this.list.children[this.selected];
      if (cur) cur.scrollIntoView({ block: "nearest" });
    },

    move(dir) {
      if (!this._current || !this._current.length) return;
      const n = this._current.length;
      this.selected = (this.selected + dir + n) % n;
      this.paint();
    },

    choose() {
      const it = this._current && this._current[this.selected];
      if (!it) return;
      this.close();
      it.run();
    },
  };

  window.Palette = Palette;
})();
