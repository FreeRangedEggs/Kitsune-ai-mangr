/* ============================================================
 * ViMoon — tabs.js
 * Multi-file tab management: one CodeMirror instance, one Doc
 * per file (fast tab switching + small memory footprint).
 * ============================================================ */
(function () {
  "use strict";

  let seq = 0;

  const Tabs = {
    list: [],
    activeId: null,

    init() {
      this.el = document.getElementById("tabs");
      this.el.addEventListener("click", (e) => {
        const tabEl = e.target.closest(".tab");
        if (!tabEl) return;
        const t = this.get(tabEl.dataset.id);
        if (!t) return;
        if (e.target.closest(".t-close")) this.close(t.id);
        else this.activate(t.id);
      });
      this.el.addEventListener("auxclick", (e) => {
        if (e.button !== 1) return;
        const tabEl = e.target.closest(".tab");
        if (tabEl) this.close(tabEl.dataset.id);
      });
    },

    get(id) { return this.list.find((t) => t.id === id); },
    byPath(p) { return this.list.find((t) => t.path === p); },
    active() { return this.get(this.activeId); },

    async open(path, opts) {
      opts = opts || {};
      const existing = this.byPath(path);
      if (existing) { this.activate(existing.id); return existing; }

      let data;
      try {
        data = await Vi.api.post("/api/files/open", { path, force: opts.force });
      } catch (err) {
        if (err.status === 413 && err.payload && err.payload.confirm && !opts.force) {
          const ok = await Vi.confirm(
            "Large file",
            (path.split("/").pop() || path) + " is " + Vi.fmtSize(err.payload.size) +
            ". Files this big open read-only to keep the editor fast. Open it?",
            { okLabel: "Open read-only" }
          );
          if (ok) return this.open(path, { force: true });
          return null;
        }
        Vi.toast(err.message, "error");
        return null;
      }

      const t = {
        id: "t" + (++seq),
        path: data.path,
        name: data.name,
        doc: CodeMirror.Doc(data.content, "text/plain"),
        modeMime: "text/plain",
        readOnly: !!data.readonly,
        encoding: data.encoding || "UTF-8",
        size: data.size,
        dirty: false,
        lastChange: Date.now(),
        cursor: null,
        scroll: null,
      };
      t.cleanGen = t.doc.changeGeneration(true);
      this.list.push(t);
      Modes.apply(t, editor);
      this.activate(t.id);
      this.addRecent(data.path);
      this.persist();
      Vi.bus.emit("file-opened", t);
      return t;
    },

    activate(id) {
      const t = this.get(id);
      if (!t || !editor) return;
      const prev = this.active();
      if (prev && prev.id !== id) {
        prev.scroll = editor.getScrollInfo();
        prev.cursor = editor.getCursor();
      }
      this.activeId = id;
      editor.swapDoc(t.doc);
      editor.setOption("mode", t.modeMime || "text/plain");
      editor.setOption("readOnly", t.readOnly);
      if (t.cursor) editor.setCursor(t.cursor);
      if (t.scroll) editor.scrollTo(t.scroll.left, t.scroll.top);
      if (Settings.raw().vim_mode) StatusBar.setMode("normal");
      StatusBar.updateForTab(t);
      this.render();
      this.updateWelcome();
      editor.focus();
      Vi.bus.emit("tab-activated", t);
    },

    async close(id, opts) {
      opts = opts || {};
      const t = this.get(id);
      if (!t) return;
      if (t.dirty && !t.readOnly && !opts.noConfirm) {
        const choice = await Vi.confirm3(
          "Unsaved changes",
          '"' + t.name + '" has unsaved changes. What should happen to them?'
        );
        if (choice === "cancel") return;
        if (choice === "save") await this.save(t, true);
      }
      const idx = this.list.indexOf(t);
      this.list.splice(idx, 1);
      if (this.activeId === id) {
        const next = this.list[idx] || this.list[idx - 1];
        if (next) this.activate(next.id);
        else {
          this.activeId = null;
          this.render();
          this.updateWelcome();
          StatusBar.updateForTab(null);
        }
      } else {
        this.render();
      }
      this.persist();
      Vi.bus.emit("tab-closed", t);
    },

    closeActive() { if (this.activeId) this.close(this.activeId); },

    async save(t, silent) {
      t = t || this.active();
      if (!t || t.readOnly) return;
      try {
        const res = await Vi.api.post("/api/files/save", {
          path: t.path, content: t.doc.getValue(),
        });
        t.size = res.size;
        t.dirty = false;
        t.cleanGen = t.doc.changeGeneration(true);
        this.render();
        StatusBar.updateForTab(t);
        if (!silent) Vi.toast("Saved " + t.name, "success", 1500);
        Vi.bus.emit("file-saved", t);
      } catch (err) {
        Vi.toast("Save failed: " + err.message, "error");
      }
    },

    saveAll() {
      return Promise.all(this.list.filter((t) => t.dirty && !t.readOnly)
        .map((t) => this.save(t, true)));
    },

    markDirty(t, dirty) {
      t.dirty = dirty;
      this.render();
    },

    addRecent(path) {
      const ui = Settings.raw().ui;
      ui.recent = [path].concat(ui.recent.filter((p) => p !== path)).slice(0, 8);
      this.persist();
      if (window.App) App.renderRecent();
    },

    persist: Vi.debounce(function () {
      const ui = Settings.raw().ui;
      ui.open_tabs = Tabs.list.map((t) => t.path);
      ui.active = Tabs.active() ? Tabs.active().path : "";
      Settings.saveUIDebounced();
    }, 500),

    updateWelcome() {
      const w = document.getElementById("welcome");
      if (w) w.classList.toggle("visible", this.list.length === 0);
    },

    render() {
      if (!this.el) return;
      this.el.innerHTML = "";
      for (const t of this.list) {
        const el = document.createElement("div");
        el.className = "tab" + (t.id === this.activeId ? " active" : "") + (t.dirty ? " dirty" : "");
        el.dataset.id = t.id;
        el.title = t.path + (t.readOnly ? " (read-only)" : "");
        el.innerHTML =
          '<span class="t-ico">' + Vi.icon("file") + "</span>" +
          '<span class="t-name">' + Vi.esc(t.name) + "</span>" +
          (t.readOnly ? '<span class="t-ro">RO</span>' : "") +
          '<span class="t-dirty" title="Unsaved changes"></span>' +
          '<span class="t-close">' + Vi.icon("x") + "</span>";
        this.el.appendChild(el);
      }
    },
  };

  window.Tabs = Tabs;
})();
