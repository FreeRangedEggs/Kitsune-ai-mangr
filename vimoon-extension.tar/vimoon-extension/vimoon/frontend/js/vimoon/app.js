/* ============================================================
 * ViMoon — app.js
 * Bootstrap: status bar, topbar wiring, global shortcuts,
 * auto-save, session restore, plugin/recent handling.
 * ============================================================ */
(function () {
  "use strict";

  /* ----------------------------------------------------------
   * Status bar
   * ---------------------------------------------------------- */
  const StatusBar = {
    init() {
      this.modeEl = document.getElementById("status-mode");
      this.modeIcon = this.modeEl.querySelector(".mode-icon");
      this.modeText = document.getElementById("mode-text");
      this.branchEl = document.getElementById("status-branch");
      this.langEl = document.getElementById("status-lang");
      this.cursorEl = document.getElementById("status-cursor");
      this.indentEl = document.getElementById("status-indent");
      this.encEl = document.getElementById("status-encoding");
      this.sizeEl = document.getElementById("status-size");
      this.botEl = document.getElementById("status-bot");

      this.modeEl.addEventListener("click", () => Settings.openModal());
      this.branchEl.addEventListener("click", () => {
        App.toggleRight(true);
        Vi.bus.emit("open-panel", "git");
        GitPanel.refresh();
      });
      this.botEl.addEventListener("click", () => {
        App.toggleRight(true);
        Vi.bus.emit("open-panel", "bot");
      });

      Vi.bus.on("open-panel", (name) => App.showPanel(name));
      Vi.bus.on("file-opened", () => Tree.refresh && Tree.highlight(Tabs.active() && Tabs.active().path));
      Vi.bus.on("tab-activated", (t) => Tree.highlight(t.path));
    },

    setMode(mode) {
      if (!this.modeIcon) return; // status bar not wired yet
      const m = (mode || "normal").replace("-mode", "");
      const map = {
        normal: ["phase-normal", "NORMAL", "m-normal"],
        insert: ["phase-insert", "INSERT", "m-insert"],
        visual: ["phase-visual", "VISUAL", "m-visual"],
        replace: ["phase-replace", "REPLACE", "m-replace"],
        command: ["phase-command", "CMD", "m-command"],
      };
      const entry = map[m] || map.normal;
      this.modeIcon.innerHTML = Vi.icon(entry[0]);
      this.modeText.textContent = entry[1];
      this.modeEl.className = "status-item mode-chip " + entry[2];
    },

    updateCursor() {
      if (!editor) return;
      const c = editor.getCursor();
      const sel = editor.getSelection().length;
      this.cursorEl.textContent = "Ln " + (c.line + 1) + ", Col " + (c.ch + 1) +
        (sel ? "  (" + sel + " sel)" : "");
    },

    updateIndent() {
      const s = Settings.raw();
      this.indentEl.textContent = (s.indent_with_tabs ? "Tabs" : "Spaces") + ": " + s.tab_size;
    },

    updateForTab(t) {
      if (!t) {
        this.langEl.textContent = "—";
        this.cursorEl.textContent = "Ln 1, Col 1";
        this.encEl.textContent = "";
        this.sizeEl.textContent = "";
        return;
      }
      this.langEl.textContent = Modes.labelFor(t.name);
      this.encEl.textContent = (t.encoding || "UTF-8").toUpperCase();
      this.sizeEl.textContent = t.dirty ? "modified" : Vi.fmtSize(t.size);
      this.updateIndent();
      this.updateCursor();
    },

    setBranch(branch) {
      if (!branch) { this.branchEl.style.display = "none"; return; }
      this.branchEl.style.display = "";
      this.branchEl.innerHTML = Vi.icon("git").replace("<svg", '<svg width="12" height="12"') + " " + Vi.esc(branch);
      this.branchEl.classList.add("clickable");
    },

    setBotOnline(ok) {
      const dot = document.getElementById("bot-dot");
      if (!dot) return;
      dot.classList.toggle("online", ok);
      dot.classList.toggle("offline", !ok);
    },

    botThinking(on) {
      this.modeText.textContent = on ? "…" : this.modeText.textContent;
    },

    addItem(el) {
      document.getElementById("plugin-status-items").appendChild(el);
    },
  };
  window.StatusBar = StatusBar;

  /* ----------------------------------------------------------
   * App
   * ---------------------------------------------------------- */
  const App = {
    commands: [],

    addCommand(c) {
      const existing = this.commands.findIndex((x) => x.id === c.id);
      if (existing >= 0) this.commands[existing] = c;
      else this.commands.push(c);
    },

    async boot() {
      Vi.paintIcons();
      await Settings.load();
      Settings.apply();

      StatusBar.init();
      Editor.create(document.getElementById("cm-host"));
      Tabs.init();
      Tree.init();
      SearchPanel.init();
      MoonBot.init();
      GitPanel.init();
      Plugins.init();
      Palette.init();
      this.wireTopbar();
      this.wireGlobalKeys();
      this.registerCoreCommands();
      this.autosaveLoop();
      this.renderRecent();
      this.refreshGitSilently();

      Vi.bus.on("theme-changed", () => Settings.apply());
      Vi.bus.on("open-panel", (name) => App.showPanel(name));

      await this.restoreSession();
      console.info("%c☾ ViMoon ready", "color:#b3c3ff");
    },

    async restoreSession() {
      const ui = Settings.raw().ui || {};
      const open = ui.open_tabs || [];

      /* deep link from the kitsune//ai-mangr launcher button:
         /?open=bots/aria.ai  ->  open that file after boot */
      let deepLink = null;
      try {
        deepLink = new URLSearchParams(location.search).get("open");
      } catch (e) { /* older browsers */ }
      if (deepLink) deepLink = deepLink.replace(/^\/+/, "");

      for (const p of open.slice(0, 20)) {
        try { await Tabs.open(p); } catch (e) { /* file may be gone */ }
      }
      if (ui.active && Tabs.byPath(ui.active)) Tabs.activate(Tabs.byPath(ui.active).id);
      if (deepLink && !Tabs.byPath(deepLink)) {
        try {
          await Tabs.open(deepLink);
          Vi.toast("Opened from kitsune: " + deepLink, "info", 2400);
        } catch (e) {
          Vi.toast("kitsune asked to open '" + deepLink + "' but it is not in the workspace", "warning", 4000);
        }
      } else if (deepLink && Tabs.byPath(deepLink)) {
        Tabs.activate(Tabs.byPath(deepLink).id);
      }
      Tabs.updateWelcome();
    },

    wireTopbar() {
      document.getElementById("btn-new-file").addEventListener("click", () => this.newFile());
      document.getElementById("btn-new-file-side").addEventListener("click", () => this.newFile());
      document.getElementById("btn-save").addEventListener("click", () => this.saveActive());
      document.getElementById("btn-search-files").addEventListener("click", () => SearchPanel.focus());
      document.getElementById("btn-palette").addEventListener("click", () => Palette.open());
      document.getElementById("btn-sidebar").addEventListener("click", () => this.toggleSidebar());
      document.getElementById("btn-rightpanel").addEventListener("click", () => this.toggleRight());
      document.getElementById("btn-close-rightpanel").addEventListener("click", () => this.toggleRight(false));
      document.getElementById("btn-theme").addEventListener("click", () => Settings.cycleTheme());
      document.getElementById("btn-settings").addEventListener("click", () => Settings.openModal());
      document.getElementById("btn-help").addEventListener("click", () => this.showHelp());

      document.querySelectorAll(".side-tab").forEach((b) => {
        b.addEventListener("click", () => {
          document.querySelectorAll(".side-tab").forEach((x) => x.classList.toggle("active", x === b));
          document.getElementById("side-files").classList.toggle("active", b.dataset.side === "files");
          document.getElementById("side-search").classList.toggle("active", b.dataset.side === "search");
        });
      });

      document.querySelectorAll(".panel-tab").forEach((b) => {
        b.addEventListener("click", () => this.showPanel(b.dataset.panel));
      });

      document.getElementById("welcome-new").addEventListener("click", () => this.newFile());
      document.getElementById("welcome-open").addEventListener("click", () => Palette.open());
      document.getElementById("welcome-search").addEventListener("click", () => SearchPanel.focus());
    },

    registerCoreCommands() {
      this.addCommand({ id: "file.new", title: "New file", key: "Ctrl+Alt+N", icon: "plus", run: () => this.newFile() });
      this.addCommand({ id: "file.save", title: "Save current file", key: "Ctrl+S", icon: "save", run: () => this.saveActive() });
      this.addCommand({ id: "file.saveAll", title: "Save all files", icon: "save", run: () => Tabs.saveAll().then(() => Vi.toast("All files saved", "success", 1600)) });
      this.addCommand({ id: "view.theme", title: "Cycle theme", key: "Ctrl+Alt+T", icon: "moon", run: () => Settings.cycleTheme() });
      this.addCommand({ id: "view.zen", title: "Toggle Zen mode", key: "Alt+Z", icon: "moon", run: () => { document.body.classList.toggle("zen"); setTimeout(() => editor.refresh(), 60); } });
      this.addCommand({ id: "view.sidebar", title: "Toggle file explorer", key: "Ctrl+B", icon: "panel-left", run: () => this.toggleSidebar() });
      this.addCommand({ id: "view.panel", title: "Toggle side panel", key: "Ctrl+'", icon: "panel-right", run: () => this.toggleRight() });
      this.addCommand({ id: "bot.open", title: "Open MoonBot (Ollama)", icon: "bot", run: () => { this.toggleRight(true); this.showPanel("bot"); } });
      this.addCommand({ id: "git.open", title: "Open Git panel", icon: "git", run: () => { this.toggleRight(true); this.showPanel("git"); GitPanel.refresh(); } });
      this.addCommand({ id: "help.shortcuts", title: "Keyboard shortcuts & vim help", key: "F1", icon: "help", run: () => this.showHelp() });
    },

    showPanel(name) {
      document.querySelectorAll(".panel-tab").forEach((b) =>
        b.classList.toggle("active", b.dataset.panel === name));
      document.querySelectorAll(".panel-page").forEach((p) =>
        p.classList.toggle("active", p.id === "panel-" + name));
      if (name === "git") GitPanel.refresh();
      if (name === "bot") MoonBot.refreshStatus(false);
      if (name === "plugins") Plugins.render();
    },

    toggleSidebar(force) {
      const body = document.body;
      const show = force !== undefined ? force : body.classList.contains("no-sidebar");
      body.classList.toggle("no-sidebar", !show);
      document.getElementById("btn-sidebar").classList.toggle("active", show);
      setTimeout(() => editor && editor.refresh(), 60);
    },

    toggleRight(force) {
      const body = document.body;
      const show = force !== undefined ? force : body.classList.contains("no-right");
      body.classList.toggle("no-right", !show);
      document.getElementById("btn-rightpanel").classList.toggle("active", show);
      setTimeout(() => editor && editor.refresh(), 60);
    },

    async newFile() {
      const name = await Vi.prompt("New file", "File name (folders allowed, e.g. notes/ideas.md):", "", "untitled.py");
      if (!name) return;
      try {
        await Vi.api.post("/api/files/create", { path: name, type: "file" });
        Tree.refresh();
        Tabs.open(name);
      } catch (err) { Vi.toast(err.message, "error"); }
    },

    async saveActive(silent) {
      const t = Tabs.active();
      if (!t) return;
      await Tabs.save(t, silent);
    },

    refreshGitSilently() {
      try { GitPanel.refresh(); } catch (e) { /* ignore */ }
    },

    renderRecent() {
      const host = document.getElementById("welcome-recent");
      if (!host) return;
      const recent = (Settings.raw().ui && Settings.raw().ui.recent) || [];
      host.innerHTML = "";
      for (const p of recent.slice(0, 6)) {
        const chip = document.createElement("button");
        chip.className = "chip";
        chip.textContent = p;
        chip.title = "Open " + p;
        chip.addEventListener("click", () => Tabs.open(p));
        host.appendChild(chip);
      }
    },

    autosaveLoop() {
      setInterval(() => {
        if (!Settings.raw().auto_save) return;
        const now = Date.now();
        for (const t of Tabs.list) {
          if (t.dirty && !t.readOnly && now - t.lastChange > 1800) {
            Tabs.save(t, true);
          }
        }
      }, 1500);
    },

    wireGlobalKeys() {
      document.addEventListener("keydown", (e) => {
        const mod = e.ctrlKey || e.metaKey;
        const inEditor = !!(e.target.closest && e.target.closest(".CodeMirror"));
        const inInput = /^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName || ""));

        if (e.key === "F1") { e.preventDefault(); this.showHelp(); return; }
        if (mod && e.altKey && (e.key === "t" || e.key === "T")) { e.preventDefault(); Settings.cycleTheme(); return; }
        if (mod && e.altKey && (e.key === "n" || e.key === "N")) { e.preventDefault(); this.newFile(); return; }
        if (mod && e.shiftKey && (e.key === "f" || e.key === "F")) { e.preventDefault(); SearchPanel.focus(); return; }
        if (mod && (e.key === "p" || e.key === "P")) { e.preventDefault(); Palette.isOpen() ? Palette.close() : Palette.open(); return; }
        if (mod && (e.key === "s" || e.key === "S")) {
          e.preventDefault();
          if (e.shiftKey) Tabs.saveAll().then(() => Vi.toast("All files saved", "success", 1600));
          else this.saveActive();
          return;
        }
        if (mod && (e.key === "b" || e.key === "B") && !inInput) { e.preventDefault(); this.toggleSidebar(); return; }
        if (mod && e.key === "'") { e.preventDefault(); this.toggleRight(); return; }
        if (mod && (e.key === ",")) { e.preventDefault(); Settings.openModal(); return; }

        // plugin-registered shortcuts (plain chords, e.g. Alt+Z)
        if (!inEditor || e.altKey) {
          const chord = (e.ctrlKey ? "Ctrl+" : "") + (e.metaKey ? "Cmd+" : "") +
            (e.altKey ? "Alt+" : "") + (e.shiftKey ? "Shift+" : "") +
            (e.key.length === 1 ? e.key.toUpperCase() : e.key);
          for (const c of this.commands) {
            if (c.key && c.key === chord) { e.preventDefault(); c.run(); return; }
          }
        }

        if (e.key === "Escape" && Palette.isOpen()) { Palette.close(); }
      }, true);
    },

    showHelp() {
      const rows = [
        ["Ctrl+P", "Command palette & fuzzy file finder"],
        ["Ctrl+S / Ctrl+Shift+S", "Save file / save all"],
        ["Ctrl+B", "Toggle file explorer"],
        ["Ctrl+'", "Toggle side panel (MoonBot · Git · Plugins)"],
        ["Ctrl+Shift+F", "Search in files"],
        ["Ctrl+F / Ctrl+H", "Search in file / search & replace"],
        ["Ctrl+G", "Jump to line (or :N in vim)"],
        ["Ctrl+Space", "Trigger completion"],
        ["Alt+\\", "MoonBot inline completion (ghost text) — Tab accepts"],
        ["Ctrl+Alt+T", "Cycle theme (Moonlight · Dark · Dawn)"],
        ["Ctrl+, / F1", "Settings / this help"],
        ["Alt+Z", "Zen mode"],
        ["", "— vim essentials —"],
        [":w :q :wq :x", "write · quit · write+quit · write+quit"],
        [":noh", "clear search highlight"],
        [":set nu / :set nonu", "toggle line numbers"],
        [":set wrap / :set nowrap", "toggle word wrap"],
        [":theme dark", "switch theme (moonlight · dark · dawn)"],
        [":bot / :git / :zen", "open MoonBot · Git panel · Zen mode"],
        ["i a o dd yy p u / …", "the full vim grammar, via CodeMirror Vim"],
      ];
      Vi.modal({
        title: "Keyboard & Vim reference",
        wide: true,
        body: '<table class="sc-table">' + rows.map((r) =>
          "<tr><td>" + (r[0] ? "<kbd>" + Vi.esc(r[0]) + "</kbd>" : "") + "</td><td>" + Vi.esc(r[1]) + "</td></tr>"
        ).join("") + "</table>",
        buttons: [{ label: "Close" }],
      });
    },
  };

  window.App = App;
  document.addEventListener("DOMContentLoaded", () => {
    App.boot().catch((err) => {
      console.error(err);
      Vi.toast("ViMoon failed to start: " + err.message, "error", 8000);
    });
  });
})();
