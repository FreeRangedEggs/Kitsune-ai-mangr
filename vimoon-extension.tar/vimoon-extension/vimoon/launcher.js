/* ============================================================
 * ViMoon extension for kitsune//ai-mangr  -  launcher
 * Injected into kitsune's index.html by install.sh (between
 * the VIMOON BEGIN / VIMOON END markers, removed by uninstall.sh).
 *
 * Adds to the web AI manager:
 *   - a moon button in the top bar -> opens ViMoon in an overlay
 *   - Ctrl+Alt+M does the same from the keyboard
 *   - a pop-out button so ViMoon can live in its own tab
 *
 * smart fallback: if kitsune's Content-Security-Policy does not
 * allow embedding :8790 (extension installed with --no-csp, or a
 * future kitsune changed its policy), the button pops ViMoon out
 * into its own browser tab instead - same one click, no overlay.
 * On a phone/lan address the overlay is skipped too (the editor
 * server binds this pc only by default).
 *
 * ViMoon itself is served by the extension server on :8790
 * (start it with:  bash vimoon.sh)
 * ============================================================ */
(function () {
  "use strict";
  var PORT = 8790;                       /* keep in sync with vimoon.sh */
  var OVERLAY_OPEN = false;
  var CSP_BLOCKED = false;               /* set by securitypolicyviolation */

  function isLocal() {
    var h = location.hostname;
    return h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "::1";
  }

  function base() {
    return location.protocol + "//" + location.hostname + ":" + PORT;
  }

  /* ---------- the moon chip toast (independent of kitsune's toast) ---------- */
  function chip(msg, ms) {
    var el = document.createElement("div");
    el.textContent = msg;
    el.style.cssText =
      "position:fixed;left:50%;bottom:24px;transform:translateX(-50%);" +
      "background:#0b1130;color:#e9edfb;border:1px solid #2c3a78;" +
      "box-shadow:0 6px 30px rgba(179,195,255,.25);border-radius:12px;" +
      "padding:10px 16px;font:13px/1.45 system-ui,sans-serif;z-index:99999;" +
      "max-width:78vw;text-align:center";
    document.body.appendChild(el);
    setTimeout(function () {
      el.style.transition = "opacity .35s";
      el.style.opacity = "0";
      setTimeout(function () { el.remove(); }, 380);
    }, ms || 3400);
  }

  /* ---------- overlay ---------- */
  function closeOverlay() {
    var ov = document.getElementById("vimoon-overlay");
    if (ov) ov.remove();
    OVERLAY_OPEN = false;
  }

  function popOut() {
    window.open(base() + "/?from=kitsune", "vimoon");
  }

  function openOverlay() {
    if (OVERLAY_OPEN) { closeOverlay(); return; }
    OVERLAY_OPEN = true;
    var ov = document.createElement("div");
    ov.id = "vimoon-overlay";
    ov.style.cssText =
      "position:fixed;inset:0;z-index:99998;background:rgba(4,7,24,.72);" +
      "backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center";

    var frame = document.createElement("div");
    frame.style.cssText =
      "position:relative;width:min(1280px,94vw);height:min(860px,92vh);" +
      "border-radius:16px;overflow:hidden;border:1px solid #2c3a78;" +
      "box-shadow:0 0 0 1px rgba(179,195,255,.12),0 0 60px rgba(120,140,255,.28)," +
      "0 24px 80px rgba(0,0,0,.6);background:#05081a";

    var bar = document.createElement("div");
    bar.style.cssText =
      "position:absolute;top:0;left:0;right:0;height:38px;display:flex;" +
      "align-items:center;gap:8px;padding:0 10px;z-index:2;" +
      "background:linear-gradient(90deg,rgba(11,17,48,.96),rgba(17,24,69,.92));" +
      "border-bottom:1px solid #1e2a5e";
    bar.innerHTML =
      '<span style="color:#b3c3ff;font:600 12.5px system-ui,sans-serif;letter-spacing:.4px">&#9789; ViMoon</span>' +
      '<span style="color:#6f7aa6;font:11px system-ui,sans-serif">extension for kitsune//ai-mangr</span>' +
      '<span style="flex:1"></span>';

    function mkbtn(label, title) {
      var b = document.createElement("button");
      b.textContent = label;
      b.title = title;
      b.style.cssText =
        "background:rgba(179,195,255,.1);border:1px solid #2c3a78;color:#e9edfb;" +
        "border-radius:8px;padding:3px 10px;font:12px system-ui,sans-serif;cursor:pointer";
      b.addEventListener("mouseenter", function () {
        b.style.background = "rgba(179,195,255,.22)";
      });
      b.addEventListener("mouseleave", function () {
        b.style.background = "rgba(179,195,255,.1)";
      });
      return b;
    }

    var pop = mkbtn("pop out", "Open ViMoon in its own browser tab");
    pop.addEventListener("click", function () { popOut(); closeOverlay(); });
    var close = mkbtn("close", "Close the overlay (Ctrl+Alt+M toggles)");
    close.addEventListener("click", closeOverlay);
    bar.appendChild(pop);
    bar.appendChild(close);

    var iframe = document.createElement("iframe");
    iframe.src = base() + "/?from=kitsune";
    iframe.setAttribute("allow", "clipboard-read; clipboard-write");
    iframe.style.cssText =
      "position:absolute;inset:38px 0 0 0;width:100%;height:calc(100% - 38px);" +
      "border:0;display:block;background:#05081a";

    frame.appendChild(bar);
    frame.appendChild(iframe);
    ov.appendChild(frame);
    document.body.appendChild(ov);

    ov.addEventListener("mousedown", function (e) {
      if (e.target === ov) closeOverlay();
    });

    /* if the CSP still refuses the embed, degrade to pop-out */
    var guard = setTimeout(function () {
      try {
        if (!iframe.contentWindow || iframe.contentWindow.length === undefined) throw 0;
      } catch (e) { /* cross-origin frames throw on access - that is fine */ }
    }, 4000);
    iframe.addEventListener("error", function () {
      clearTimeout(guard);
      closeOverlay();
      popOut();
    });
  }

  /* ---------- health probe, then overlay, pop-out, or hint ---------- */
  function launch() {
    if (CSP_BLOCKED || !isLocal()) {
      /* CSP refuses :8790, or we are on a phone/lan address where the
         overlay is pointless (editor binds this pc only) - pop out. */
      popOut();
      if (CSP_BLOCKED) {
        chip("opened in a new tab - the overlay needs the CSP patch " +
             "(re-run the ViMoon installer without --no-csp)", 4200);
      }
      return;
    }
    var ctrl = ("AbortController" in window) ? new AbortController() : null;
    var opts = ctrl ? { signal: ctrl.signal } : {};
    if (ctrl) setTimeout(function () { ctrl.abort(); }, 2500);
    fetch(base() + "/api/health", opts)
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        if (j && (j.app === "vimoon-extension" || j.name === "ViMoon")) openOverlay();
        else chip("ViMoon is not answering on :" + PORT + " - run  bash vimoon.sh  in the kitsune folder.");
      })
      .catch(function () {
        if (CSP_BLOCKED) { popOut(); return; }
        chip("ViMoon is not running - start it with:  bash vimoon.sh");
      });
  }

  /* ---------- watch for the CSP saying no ---------- */
  document.addEventListener("securitypolicyviolation", function (e) {
    if (e.blockedURL && e.blockedURL.indexOf(":" + PORT) !== -1) {
      CSP_BLOCKED = true;
      if (OVERLAY_OPEN) { closeOverlay(); popOut(); }
    }
  }, true);

  /* ---------- top bar button (kitsune's own button styling applies) ---------- */
  function addButton() {
    if (document.getElementById("vimoonbtn")) return;
    var btn = document.createElement("button");
    btn.id = "vimoonbtn";
    btn.title = "ViMoon - moonlit code editor (Ctrl+Alt+M)";
    btn.setAttribute("aria-label", "open vimoon editor");
    btn.innerHTML =
      '<svg class="ic" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
    btn.addEventListener("click", launch);
    var topbar = document.getElementById("topbar");
    if (!topbar) { document.body.appendChild(btn); btn.style.display = "none"; return; }
    var gear = document.getElementById("gearbtn");
    if (gear && gear.parentNode === topbar) topbar.insertBefore(btn, gear);
    else topbar.appendChild(btn);
  }

  /* ---------- keyboard: Ctrl+Alt+M ---------- */
  document.addEventListener("keydown", function (e) {
    if ((e.ctrlKey || e.metaKey) && e.altKey && (e.key === "m" || e.key === "M")) {
      e.preventDefault();
      launch();
    }
  }, true);

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", addButton);
  } else {
    addButton();
  }
})();
