#!/usr/bin/env bash
# if this got started by another shell (sh/dash/zsh), re-exec under bash -
# same guard as kitsune's own start.sh (parts below are bash-only).
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi
# ============================================================
# ViMoon extension - control the moonlit editor server
#
#   bash vimoon.sh           -> start the editor server (port 8790)
#   bash vimoon.sh stop      -> stop it
#   bash vimoon.sh restart   -> stop + start
#   bash vimoon.sh status    -> running? workspace? ollama up?
#   bash vimoon.sh log       -> tail the log
#
#   VIMOON_PORT=9000 bash vimoon.sh   -> run on another port
#                                        (also update the PORT line
#                                        inside the kitsune button's
#                                        injected block, or the moon
#                                        button will knock on 8790)
#
# ViMoon edits the kitsune folder itself (bots/, knowledge/, config/,
# your code), so whatever you save in the editor is saved straight to
# the same files the web AI manager reads - that IS the sync.
# ============================================================
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/vimoon/moon_server.py"
PID="$DIR/.vimoon.pid"
LOG="$DIR/vimoon.log"
PORT="${VIMOON_PORT:-8790}"
OLLAMA="${OLLAMA_URL:-http://127.0.0.1:11434}"

# the server is plain python. try python3 first, fall back to python
# (Windows Git Bash and some distros only ship the shorter name).
PY="$(command -v python3 2>/dev/null || command -v python 2>/dev/null || true)"

say() { printf '[vimoon] %s\n' "$1"; }

is_running() {
  [ -f "$PID" ] && kill -0 "$(cat "$PID" 2>/dev/null)" 2>/dev/null
}

wait_dead() {
  local i=0
  while kill -0 "$(cat "$PID" 2>/dev/null)" 2>/dev/null; do
    sleep 0.2; i=$((i + 1)); [ $i -gt 50 ] && break
  done
}

# is 127.0.0.1:$1 free? (0 = free)
port_free() {
  "$PY" - "$1" <<'PYEOF' 2>/dev/null
import socket, sys
s = socket.socket()
s.settimeout(1.0)
rc = s.connect_ex(("127.0.0.1", int(sys.argv[1])))
s.close()
sys.exit(0 if rc != 0 else 1)
PYEOF
}

start_server() {
  if [ -z "$PY" ]; then
    say "python not found - install python3 (python.org on Windows, tick 'Add to PATH')."
    exit 1
  fi
  if [ ! -f "$APP" ]; then
    say "moon_server.py is missing at: $APP"
    say "run the extension installer first:  bash install.sh"
    exit 1
  fi
  if is_running; then
    say "already running (pid $(cat "$PID")) - restart with: bash vimoon.sh restart"
    exit 0
  fi
  # a stale server on the port without a pidfile? say so clearly.
  if ! port_free "$PORT"; then
    say "port $PORT is busy and no .vimoon.pid points at it."
    say "another ViMoon copy may be running - check: bash vimoon.sh status"
    exit 1
  fi
  nohup env VIMOON_PORT="$PORT" "$PY" "$APP" >> "$LOG" 2>&1 &
  echo $! > "$PID"
  sleep 1
  if is_running; then
    say "started (pid $(cat "$PID")) - editor: http://localhost:$PORT"
    say "the moon button in kitsune's top bar opens it as an overlay."
  else
    say "failed to start - last log lines:"
    tail -5 "$LOG" 2>/dev/null
    exit 1
  fi
}

stop_server() {
  if ! is_running; then
    rm -f "$PID"
    say "not running."
    return 0
  fi
  local p="$(cat "$PID")"
  kill "$p" 2>/dev/null
  wait_dead
  kill -9 "$p" 2>/dev/null
  rm -f "$PID"
  say "stopped (was pid $p)."
}

status_server() {
  if is_running; then
    say "running (pid $(cat "$PID")) on port $PORT"
  else
    say "not running - start with: bash vimoon.sh"
  fi
  say "workspace: ${VIMOON_WORKSPACE:-(vimoon/data/settings.json / default)}"
  if curl -s --max-time 3 "$OLLAMA/api/tags" >/dev/null 2>&1; then
    say "ollama: up at $OLLAMA (MoonBot ready)"
  else
    say "ollama: not reachable at $OLLAMA (MoonBot will say so in the UI)"
  fi
  if command -v git >/dev/null 2>&1; then
    say "git: $(git --version | head -1)"
  else
    say "git: not installed (the Git panel needs it)"
  fi
}

case "${1:-start}" in
  start)   start_server ;;
  stop)    stop_server ;;
  restart) stop_server; start_server ;;
  status)  status_server ;;
  log)     tail -n 40 -f "$LOG" ;;
  *)       say "usage: bash vimoon.sh [start|stop|restart|status|log]"; exit 1 ;;
esac
