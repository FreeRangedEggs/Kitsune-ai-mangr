# ViMoon extension for kitsune//ai-mangr

**Version 1.0.0** — a moonlit code editor that lives inside your web AI manager.

A crescent moon appears in kitsune's top bar. Click it (or press `Ctrl+Alt+M`) and ViMoon opens right there — a full text editor with a dreamy moonlight theme, vim compatibility, syntax highlighting, intelligent completion, a MoonBot panel wired to your local Ollama, multi-file tabs, search & replace, and Git integration. Everything you save lands **directly in the kitsune folder** — bot `.ai` files, knowledge files, `config/*.conf`, your own scripts — which is the sync: there is only one copy of every file, and both apps read it.

```
   )\      kitsune//ai-mangr  = your web AI manager (chat, bots, ollama)
  (  )     ViMoon extension  = the editor it was missing
 ( (  )    one workspace    = the kitsune folder itself
 _)..--.._
```

---

## What the extension adds

| Requirement | How it works |
| --- | --- |
| **Launch ViMoon** | Moon button in kitsune's top bar, `Ctrl+Alt+M`, or `http://localhost:8790`. Opens as an overlay inside kitsune, with a **pop out** button for its own tab. |
| **File handling** | ViMoon's workspace **is** the kitsune folder. Browse, open and edit bots, knowledge files, configs and code from the file explorer or `Ctrl+P` fuzzy finder. The launcher deep-link (`?open=<path>`) opens any file straight from the manager. |
| **Sync and save** | No export/import step exists on purpose. ViMoon writes the same files kitsune reads (bot definitions, knowledge, chats, theme). `Ctrl+S` saves; auto-save (on by default) saves 1.8 s after you stop typing. Every save is atomic (write temp + rename). |
| **Minimalistic UI** | Three rails: file explorer / search on the left, editor in the middle, MoonBot · Git · Plugins on the right. Command palette (`Ctrl+P`), status bar with vim mode, branch, cursor, encoding. |
| **Dreamy moonlight theme** | Dark starry sky with CSS starfield + moon glow, soft glowing text, pastel syntax palette. Two more themes ship: `dark` (classic dark mode) and `dawn`. Cycle with the moon button or `Ctrl+Alt+T`. |
| **Customizable settings** | Settings modal (`Ctrl+,`): font size + family, line numbers, word wrap, tab size, vim on/off, auto-save, bracket closing, completion, folding, theme, MoonBot model + URL, large-file limit. Stored in `vimoon/settings.json`, applied live. |
| **Vim compatibility** | CodeMirror's full vim keymap: modes (NORMAL/INSERT/VISUAL/REPLACE), motions, operators, counts, registers, marks, `/` search, `.repeat`, plus ViMoon ex commands (`:w :wq :q :noh :set nu :theme dark :bot :git :zen`). Toggleable in settings. |
| **Syntax highlighting** | 20+ languages via CodeMirror modes: Python, JavaScript/TypeScript, JSON, HTML, CSS/SCSS, Markdown, C/C++, Java, C#, Go, Rust, Shell, YAML, SQL, PHP, Ruby, Lua, XML and more — loaded lazily per file type. |
| **Code completion** | Context-aware: language keyword pools + every identifier in the document, fuzzy-scored. Auto-pops after 2 typed characters, `Ctrl+Space` forces it. Plus **MoonBot ghost text** (`Alt+\`): Ollama writes the next lines, `Tab` accepts. |
| **Ollama bot (MoonBot)** | Right panel chat with streaming replies. The backend proxies your local Ollama (browser never talks to it directly). Quick actions: **Analyze file**, **Explain selection**, **Find bugs**, **Suggest tests** — the active file (or selection) is attached automatically. |
| **Multi-file** | One CodeMirror document per file, tab bar with dirty dots, session restore (tabs + active file survive reloads), recent-files list on the welcome screen. |
| **Search & replace** | In-file: `Ctrl+F` / `Ctrl+H` (regex, case, replace all). Project-wide: `Ctrl+Shift+F` with case/regex/file-type filters, results grouped per file, click to jump. |
| **Version control** | Git panel: branch switcher, stage/unstage/discard, commit, history with per-commit diffs, unified diff view. Backend wraps the `git` CLI with a strict argument allowlist, confined to the workspace. |
| **Performance** | One shared CodeMirror instance with per-file documents (fast tab switching), lazy mode loading, debounced autosave, 8 MB hard open limit with a configurable soft limit (2 MB default) beyond which files open read-only. A 3,000-line / 131 KB file opens in ~50 ms. |
| **Responsive** | Panels collapse; the layout works from phones (kitsune LAN mode) to wide desktops. |

---

## Quick start

Built for Linux (Windows: use Git Bash, same as kitsune). You need **Python 3** — the editor server is one plain file with **zero pip dependencies**, matching kitsune's rule. Git is optional (only the Git panel needs it). Ollama is optional (only MoonBot needs it).

```bash
# 1. unpack and install into your kitsune folder
tar -xzf vimoon-extension-v1.0.0.tar.gz
cd vimoon-extension
bash install.sh                        # auto-finds kitsune, or: --dir /path/to/kitsune-ai-mangr

# 2. start the editor server
bash /path/to/kitsune-ai-mangr/vimoon.sh

# 3. restart kitsune once (the installer widened its Content-Security-Policy)
kitsune                                # or: bash start.sh

# 4. refresh kitsune in the browser -> click the moon
```

That is the whole build. There is nothing to compile — `install.sh` copies `vimoon/` next to `server.py`, injects the moon button into `index.html` between marked comments, and widens the CSP in `server.py` by exactly three directives so the page may embed and probe `http://localhost:8790`.

### What install.sh changes in kitsune (all reversible)

| File | Change | Backup |
| --- | --- | --- |
| `index.html` | launcher `<script>` appended before `</body>` between `<!-- ViMoon extension v1.0.0 -->` markers | `index.html.vimoon-bak` |
| `server.py` | CSP gains `http://localhost:8790 http://127.0.0.1:8790` on `img-src`, `connect-src`, and a new `frame-src` | `server.py.vimoon-bak` |
| `vimoon/`, `vimoon.sh` | new files (the editor + control script) | — |
| `vimoon/settings.json` | workspace = your kitsune folder | kept if present |

```bash
bash install.sh --no-csp      # skip the server.py edit: the moon button then
                              # opens ViMoon in a new tab (pop-out mode)
bash install.sh --no-button   # skip index.html entirely
bash uninstall.sh             # stop server, remove button, restore CSP,
                              # ask before deleting vimoon/  (--yes / --clean for scripted use)
```

kitsune serves `index.html` from disk with `Cache-Control: no-store`, so the moon button appears on refresh without a restart. Only the CSP change needs the one-time kitsune restart.

### The extension manager (settings > app)

kitsune has a small extension manager built in: open the gear, expand **app**, and every add-on that lives next to `server.py` and ships an `extension.json` manifest is listed there with a live status chip and **start / stop / launch** buttons. ViMoon's manifest ships at `vimoon/extension.json` and is copied into place by `install.sh`, so after installing you will see:

```
extensions  1 installed                                   [refresh]
  ViMoon  v1.0.0 · vimoon/          [running :8790] [stop] [launch]
    moonlit code editor - vim keys, 20+ languages, completion,
    MoonBot (ollama), git panel, multi-tab.
```

- **launch** clicks the same moon button logic - the editor opens as an overlay inside kitsune (or a new tab when the CSP patch was skipped).
- **start / stop** run `bash vimoon.sh start|stop` - the manager only ever calls the extension's own control script, no shell strings.
- the chip is a real probe of `http://localhost:8790/api/health`, not a guess.

Writing your own kit-sune extension is one JSON file away - see the extensions README in the repo this came from.

---

## The vim grammar (cheat sheet)

Press `F1` in ViMoon any time for this table.

| Keys | Action |
| --- | --- |
| `i a I A o O` | insert before / after / line-start / line-end / open line below / above |
| `h j k l w b e 0 $ ^ gg G { } %` | motions |
| `dd yy cc x r J` | delete / yank / change line, delete char, replace char, join |
| `d c y` + motion | operator + movement (`dw`, `ci"`, `y$`…) |
| `p P` | paste after / before |
| `u Ctrl+r` | undo / redo |
| `v V` | visual / visual-line, then `d y > < ~` |
| `/text ?text n N * #` | search forward / backward, repeat, word under cursor |
| `:w :q :wq :x :q! :qa` | write · quit · both · both · quit! · quit all |
| `:s/a/b/` `:%s/a/b/g` | substitute on line / whole file |
| `:noh` | clear search highlight |
| `:set nu` `:set wrap` `:set vim` | line numbers · word wrap · vim mode |
| `:theme dark` | switch theme (`moonlight` · `dark` · `dawn`) |
| `:bot` `:git` `:settings` | open MoonBot panel · Git panel · settings |
| `Ctrl+P` | command palette + fuzzy file finder |
| `Ctrl+Space` | trigger completion |
| `Alt+\` | MoonBot inline completion (ghost text, `Tab` accepts) |
| `Ctrl+G` | jump to line |

---

## Customizing

### The moonlight theme

`vimoon/frontend/css/themes/moonlight.css` is a single CSS-variable block — edit it and refresh, no build:

```css
body[data-theme="moonlight"] {
  --bg0: #05081a;            /* deep space background        */
  --accent: #b3c3ff;         /* moonbeam - links, focus      */
  --accent2: #9ee8ff;        /* starlight - secondary glow   */
  --syn-keyword: #c7b6ff;    /* soft violet keywords         */
  --syn-string:  #b8f4d9;    /* pastel mint strings          */
  --syn-number:  #ffd9b3;    /* peach numbers                */
  --syn-comment:#7b87b3;     /* slate comments               */
  /* ... 20+ more tokens in the file ... */
}
```

Add your own theme by copying the block, renaming `body[data-theme="mynight"]`, adding the name to `_themes` in `frontend/js/vimoon/settings.js`, and listing it in `:theme`'s validation in `editor.js`. The starfield and moon glow live in `frontend/css/base.css` (`#stars`, `#moon-glow`).

### Ports, workspace, MoonBot

`vimoon/settings.json` (written by the installer, safe to edit, applied live):

```json
{
  "workspace": "/home/you/kitsune-ai-mangr",
  "theme": "moonlight",
  "font_size": 14,
  "vim_mode": true,
  "auto_save": true,
  "ollama_url": "http://localhost:11434",
  "ollama_model": ""
}
```

| Setting | Meaning |
| --- | --- |
| `workspace` | the folder ViMoon edits. Points at kitsune by default; any folder works (standalone use). |
| `ollama_url` / `ollama_model` | MoonBot target; env `OLLAMA_URL` wins. Empty model = first installed model. |
| `large_file_limit_kb` | files bigger than this open read-only (confirm to edit anyway). Hard cap 8 MB. |

Port: `VIMOON_PORT=9000 bash vimoon.sh` — and update `PORT` in the injected launcher block in `index.html` so the moon button knocks on the same door.

### The `vimoon.sh` control script

```bash
bash vimoon.sh start | stop | restart | status | log
```

`status` reports pid, port, workspace, Ollama reachability and git availability — the same one-address discipline as kitsune's `start.sh` (fixed port, refuses to start when a stranger owns it, pid file + log file).

### MoonBot without Ollama

`python3 vimoon/mock_ollama.py` fakes a tiny Ollama on `:11434` (model `moonbot-sim:latest`, rule-based replies tagged *(sim)*) so you can try the panel, streaming and ghost text before pulling a real model.

---

## Architecture

```
kitsune-ai-mangr/
├── server.py            kitsune (patched CSP only)
├── index.html           kitsune ui (+ injected launcher between markers)
├── vimoon.sh            start/stop/status for the editor server
└── vimoon/
    ├── moon_server.py   the whole backend: plain python3, zero deps,
    │                    ThreadingHTTPServer on :8790
    ├── extension.json   manifest - makes ViMoon show up in kitsune's
    │                    settings > app extension manager
    ├── settings.json    workspace + editor defaults
    ├── launcher.js      the injected moon-button script (also here for editing)
    ├── mock_ollama.py   fake ollama for offline demos
    ├── frontend/
    │   ├── index.html   editor shell
    │   ├── css/         base.css + themes/{moonlight,dark,dawn}.css
    │   ├── js/vimoon/   core · editor · tabs · tree · search · bot ·
    │   │                gitpanel · settings · plugins · palette · app
    │   └── vendor/      CodeMirror 5 + vim keymap + addons (vendored, no CDN)
    ├── plugins/         sample plugins (manifest.json + main.js each)
    └── docs/            PLUGIN_API.md and friends
```

**moon_server.py API** (all JSON under `/api`, same contract the frontend has always spoken):

| Route | Purpose |
| --- | --- |
| `GET /api/health` | ok, version, workspace, git + ollama flags |
| `GET/POST /api/files/tree·open·save·create·rename·delete·download·meta` | workspace file IO, sandboxed by realpath containment, atomic saves, binary sniffing |
| `POST /api/search` | project-wide grep (plain/regex, case toggle, ext filter) |
| `GET/PUT /api/settings` | editor settings (sanitized key allowlist) |
| `GET/POST /api/git/status·action·commit·log·diff·show·branches·checkout·init` | git CLI wrapper, arg-vector only (no shell), workspace-confined |
| `GET/POST /api/ollama/status·chat·complete` | Ollama proxy; `chat` streams Server-Sent Events |
| `GET/POST /api/plugins(/toggle)` | plugin manager |

**Security posture** (mirrors kitsune's): binds `127.0.0.1` (no LAN exposure by default), CORS `Access-Control-Allow-Origin` echoed **only** for same-machine origins, mutation requests require the app's own origin, path traversal refused, git executed without a shell, no cookies/sessions exist, and kitsune's PIN lock still gates kitsune itself. The CSP edit adds nothing broader than `http://localhost:8790` and `http://127.0.0.1:8790`.

---

## Demo

- `demo/demo-extension.mp4` (and `.webm`) — recorded inside kitsune: moon button click → overlay → vim editing (`gg`, `O`, `:w`) → MoonBot analysis → Git panel.
- `demo/vimoon-demo.mp4` — the full editor tour from the standalone ViMoon build.
- `demo/screenshots/01…11` — moonlight editor, multi-tab, MoonBot chat, Git panel + history, settings, palette, project search, dark/dawn themes, welcome.
- `screenshots/12…17` — the extension moments: moon button in kitsune's top bar, the overlay open over the manager, deep-link open, 3,000-line file, MoonBot analysis, Git panel on the kitsune workspace.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| Moon button click says "ViMoon is not running" | `bash vimoon.sh` in the kitsune folder (or `bash vimoon.sh status`). |
| Button opens a new tab instead of the overlay | The CSP patch is missing (installed with `--no-csp`, or kitsune was never restarted after install). Re-run `bash install.sh` and restart kitsune once. |
| Moon button missing | `grep "ViMoon extension" index.html` — if absent, re-run `bash install.sh`. Refresh the page; kitsune serves it uncached. |
| MoonBot says Ollama is unreachable | `ollama serve`, pull a model (`ollama pull llama3.2`), check the URL in Settings → MoonBot, or run `python3 vimoon/mock_ollama.py` for a simulated model. |
| Port 8790 busy | `VIMOON_PORT=9000 bash vimoon.sh` + update `PORT` in the injected block in `index.html`. |
| Overlay blocked on a phone | By design: the editor binds this PC only. Pop-out works from the manager on the phone only if you also started `vimoon.sh` with `--lan` — mind the security note in kitsune's README first. |
| Large file feels heavy | Files over `large_file_limit_kb` open read-only (confirm overrides). The 8 MB hard cap keeps the browser snappy. |
| Uninstall left backups | `index.html.vimoon-bak` / `server.py.vimoon-bak` are kept on purpose; `bash uninstall.sh --clean` removes them. |

## Version history

- **1.0.0** — first release: moon-button launcher (overlay + pop-out + `Ctrl+Alt+M`), zero-dependency `moon_server.py` port of the ViMoon API, workspace = kitsune folder sync, deep-link `?open=`, scoped CORS + CSP integration, three themes, MoonBot streaming, git panel, plugin manager, demo video + screenshots.
- **1.0.0 (repo pack)** — adds `vimoon/extension.json` so the editor registers itself in kitsune's extension manager (settings > app: live status chip, start/stop via `vimoon.sh`, launch into the overlay).
