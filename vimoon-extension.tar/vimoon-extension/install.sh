#!/usr/bin/env bash
# if this got started by another shell (sh/dash/zsh), re-exec under bash -
# same guard as kitsune's own install.sh.
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi
# ============================================================
# ViMoon extension installer - adds the moonlit code editor to
# an existing kitsune//ai-mangr installation.
#
#   bash install.sh                    install into the kitsune folder
#                                      found next to this script (or cwd)
#   bash install.sh --dir /some/path   install into that folder
#   bash install.sh --no-button        skip patching kitsune's index.html
#                                      (ViMoon stays reachable at :8790)
#   bash install.sh --uninstall        same as uninstall.sh
#
# what it does
#   1. copies vimoon/ (editor + zero-dependency server) into the kitsune folder
#   2. copies vimoon.sh (start/stop/status) next to kitsune's start.sh
#   3. writes vimoon/settings.json pointing the workspace at the kitsune
#      folder - that is the sync: saves land in the same files kitsune reads
#   4. injects the launcher (moon button + Ctrl+Alt+M) between marked
#      comment lines in index.html; kitsune serves index.html from disk
#      with no-store caching, so the button appears without a restart
#   everything is reversible with uninstall.sh
# ============================================================
SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET=""
NO_BUTTON=0
NO_CSP=0
CSP_PATCHED=0

while [ $# -gt 0 ]; do
  case "$1" in
    --dir)       TARGET="${2:-}"; shift 2 ;;
    --no-button) NO_BUTTON=1; shift ;;
    --no-csp)    NO_CSP=1; shift ;;
    --uninstall) exec bash "$SELF_DIR/uninstall.sh" "${@:2}" ;;
    -h|--help)   sed -n '2,34p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1 (try --help)"; exit 1 ;;
  esac
done

say() { printf '[vimoon] %s\n' "$1"; }
fail() { printf '[vimoon] ERROR: %s\n' "$1"; exit 1; }

# ---------- find the kitsune folder ----------
if [ -z "$TARGET" ]; then
  for c in "$PWD" "$SELF_DIR" "$SELF_DIR/.."; do
    if [ -f "$c/server.py" ] && [ -f "$c/index.html" ]; then TARGET="$(cd "$c" && pwd)"; break; fi
  done
fi
[ -n "$TARGET" ] || fail "could not find a kitsune//ai-mangr folder. cd into it, or pass --dir /path/to/kitsune-ai-mangr"
[ -f "$TARGET/server.py" ] || fail "no server.py in $TARGET - that does not look like kitsune//ai-mangr"
[ -f "$TARGET/index.html" ] || fail "no index.html in $TARGET - that does not look like kitsune//ai-mangr"
[ -f "$SELF_DIR/vimoon/moon_server.py" ] || fail "the vimoon/ folder is missing next to install.sh - re-extract the extension archive"

say "kitsune folder: $TARGET"

# ---------- 1. copy the editor ----------
mkdir -p "$TARGET/vimoon"
cp -R "$SELF_DIR/vimoon/." "$TARGET/vimoon/"
rm -f "$TARGET/vimoon/data/settings.json".tmp 2>/dev/null
say "copied vimoon/ (editor, server, plugins, docs)"

# ---------- 2. control script ----------
cp "$SELF_DIR/vimoon.sh" "$TARGET/vimoon.sh"
chmod +x "$TARGET/vimoon.sh" 2>/dev/null
say "wrote vimoon.sh (start/stop/status next to kitsune's start.sh)"

# ---------- 3. editor defaults (workspace is auto-detected: the
# kitsune folder, because vimoon/ sits next to server.py - no absolute
# path is written, so moving the kitsune folder never breaks anything) ----------
SETTINGS="$TARGET/vimoon/settings.json"
if [ ! -f "$SETTINGS" ]; then
  cat > "$SETTINGS" <<EOF
{
  "theme": "moonlight",
  "font_size": 14,
  "vim_mode": true,
  "auto_save": true
}
EOF
fi
say "workspace: $TARGET (auto-detected - bot files, knowledge, config: all editable)"

# ---------- 4. launcher button in kitsune's index.html ----------
INDEX="$TARGET/index.html"
BEGIN="<!-- ViMoon extension v1.0.0 - added by install.sh (uninstall.sh removes this) -->"
END="<!-- /ViMoon extension -->"
LAUNCHER="$TARGET/vimoon/launcher.js"

if [ "$NO_BUTTON" = "1" ]; then
  say "skipping the index.html button (--no-button). ViMoon lives at http://localhost:8790"
elif [ ! -f "$LAUNCHER" ]; then
  say "WARNING: launcher.js missing - no moon button, ViMoon still works at :8790"
else
  if grep -q "ViMoon extension v" "$INDEX" 2>/dev/null; then
    # already injected: replace the block in place (version bump friendly)
    python3 - "$INDEX" "$BEGIN" "$END" "$LAUNCHER" <<'PYEOF'
import io, sys
path, begin, end, launcher = sys.argv[1:5]
src = io.open(path, encoding="utf-8").read()
js = io.open(launcher, encoding="utf-8").read()
a = src.find(begin)
b = src.find(end)
if a == -1 or b == -1 or b < a:
    sys.exit("marker block not found - run uninstall.sh once, then install again")
block = begin + "\n<script>\n" + js + "\n</script>\n" + end
io.open(path, "w", encoding="utf-8").write(src[:a] + block + src[b + len(end):])
PYEOF
    if [ $? -eq 0 ]; then say "refreshed the injected launcher block in index.html"; else say "could not refresh the block - leaving index.html untouched"; fi
  else
    cp "$INDEX" "$INDEX.vimoon-bak"
    python3 - "$INDEX" "$BEGIN" "$END" "$LAUNCHER" <<'PYEOF'
import io, sys
path, begin, end, launcher = sys.argv[1:5]
src = io.open(path, encoding="utf-8").read()
js = io.open(launcher, encoding="utf-8").read()
block = begin + "\n<script>\n" + js + "\n</script>\n" + end
if "</body>" not in src:
    sys.exit("no </body> found")
io.open(path, "w", encoding="utf-8").write(
    src.replace("</body>", block + "\n</body>", 1))
PYEOF
    if [ $? -eq 0 ]; then
      say "moon button injected into index.html (backup: index.html.vimoon-bak)"
      say "kitsune serves index.html from disk with no-store caching, so a browser refresh shows it - no restart needed"
    else
      say "could not patch index.html - leaving it untouched; ViMoon still works at :8790"
    fi
  fi
fi

# ---------- 5. CSP: let the kitsune page embed + probe the editor ----------
# kitsune 2.0.4 ships a strict Content-Security-Policy (connect-src 'self',
# no frame-src). the moon button's overlay iframe and its health probe
# need http://localhost:8790 / http://127.0.0.1:8790 allowed. this is a
# narrow, reversible edit to server.py (backup: server.py.vimoon-bak) and
# needs the kitsune RESTART to take effect. --no-csp skips it: the button
# then opens ViMoon in a new tab instead of the overlay.
SRV="$TARGET/server.py"
if [ "$NO_CSP" = "1" ]; then
  say "skipping the CSP patch (--no-csp): the moon button will pop ViMoon out into its own tab"
elif grep -q "localhost:8790" "$SRV" 2>/dev/null; then
  say "server.py already allows the ViMoon origin - CSP ok"
elif grep -q "connect-src 'self'" "$SRV" 2>/dev/null; then
  cp "$SRV" "$SRV.vimoon-bak"
  python3 - "$SRV" <<'PYEOF'
import io, sys
path = sys.argv[1]
src = io.open(path, encoding="utf-8").read()
MOON = "http://localhost:8790 http://127.0.0.1:8790"
n = 0
if "img-src 'self' data:" in src:
    src = src.replace("img-src 'self' data:",
                      "img-src 'self' data: " + MOON, 1); n += 1
if "connect-src 'self'" in src:
    src = src.replace("connect-src 'self'",
                      "connect-src 'self' " + MOON, 1); n += 1
if "frame-ancestors 'none'" in src and "frame-src" not in src:
    src = src.replace("frame-ancestors 'none'",
                      "frame-src " + MOON + "; frame-ancestors 'none'", 1); n += 1
io.open(path, "w", encoding="utf-8").write(src)
print("[vimoon] CSP widened for the ViMoon origin (%d directive(s), backup: server.py.vimoon-bak)" % n)
PYEOF
  if [ $? -eq 0 ]; then
    CSP_PATCHED=1
  else
    say "could not patch the CSP - the moon button will pop out into a tab instead (still fully usable)"
  fi
else
  say "no 'connect-src' CSP found in server.py - nothing to widen"
fi

# ---------- done ----------
say ""
if [ "$CSP_PATCHED" = "1" ]; then
  say "one more step: the CSP change needs kitsune RESTARTED once -"
  say "    kitsune            # or: bash $TARGET/start.sh"
fi
say "done. two steps to the moon:"
say "  1) bash $TARGET/vimoon.sh          # start the editor server on :8790"
say "  2) refresh kitsune in the browser  # click the moon in the top bar"
say ""
say "or open the editor directly:  http://localhost:8790"
