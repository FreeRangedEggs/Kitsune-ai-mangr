kitsune//ai-mangr v2 - quick start
==================================

1. put this folder anywhere you like (example: ~/.server)
2. bash start.sh          -> web app on http://localhost:8788
3. open it, tap a bot, talk. everything stays on your machine.

--- your one address (the phone part) ---

the port is FIXED at 8788 and never changes - that's the feature.
the app always answers on the same address, so your phone bookmark or
home-screen icon never breaks.

  bash start.sh prints the address, e.g.:

    on this pc : http://localhost:8788
    from phone : http://192.168.1.23:8788   <- your one address

even easier: open the app on the pc and tap the PHONE BUTTON (top right).
it shows the address(es) plus a QR code - point your phone camera at it.

make it a phone app (once, 20 seconds):
  android: chrome -> open the address -> menu (3 dots) -> "add to home screen"
  iphone : safari -> open the address -> share -> "add to home screen"
from then on it opens like an app, full screen, no typing. ever.

tips for a truly stable address:
  - your router hands out LAN ips; ask it to keep yours reserved
    (dhcp static lease), OR
  - use the hostname form the phone menu also offers:
    http://<your-pc-name>.local:8788  - survives ip changes on
    iphone/android/most linux desktops (mDNS).

port taken by another program? a stale copy of this app is stopped
automatically. a foreign program keeps the port, and start REFUSES to
run rather than silently hopping to 8789 (a moving address is what used
to break phone bookmarks). it tells you what to do instead.

private by default? the server listens on your LAN so the phone can
reach it. to lock it back to this pc only:
  BIND=127.0.0.1 bash start.sh     (phone + tunnel stop working)

--- files in this folder ---

  server.py     the whole server - plain python3, zero dependencies
  index.html    the ui - lives RIGHT NEXT TO server.py
  start.sh      start / stop / status / warm-model
  tunnel.sh     temporary https link for away-from-home (QR in terminal)
  config/
    theme.conf    kitty-style theme config: edit a line, save, refresh
                  the browser. presets (catppuccin/gruvbox/dracula) are
                  commented out at the bottom of the file
    settings.conf app switches - the gear button writes it. single_model
                  on = before each reply every other loaded model is
                  dropped from ram, so two models never share your 8gb
  robot.png     the robot chip used by the bots-menu buttons
  logo.jpg      the fox logo (topbar + welcome screen + icons)
  icon-192.png  pwa icons for "add to home screen"
  icon-512.png
  avatar.png    the default profile picture for bots (swap it freely)
  .port         the port the server actually bound - written at boot,
                removed on shutdown, read by tunnel.sh
  sw.js         service worker (needed for "add to home screen")
  bots/         one .ai file per bot - see bots/README.txt
  chats/        chat history, one json file per chat
  knowledge/    files you attached to bots, one folder per bot (see below)
  avatars/      bot icons picked in the ui land here

older installs kept theme.conf / settings.conf next to server.py -
the server tucks them into config/ automatically on the first boot.

--- what's new in v2 ---

  - one fixed address: port never drifts, LAN access built in, QR in the ui
  - server.py slimmed down (the whole ui is no longer duplicated inside it)
  - code blocks + inline code render in chat (great with coder models)
  - copy button under every bot reply, export a chat as markdown
  - duplicate a bot with one tap (bots menu, the double-arrow)
  - paste screenshots / drag-drop images straight into the chat
  - enter-key behavior switch in settings (multiline typing on phones)
  - friendlier errors: "ollama is not reachable - start it with: ollama
    serve", "model 'x' is not installed - run: ollama pull x"
  - smoother streaming on phones (renders per screen frame, not per token)
  - mobile keyboard fixes, scroll-to-bottom chip, esc closes menus

--- bot .ai format (plain text, edit in vim, refresh to apply) ---

  name: "Aria"
  description: "who she is, how she talks"
  greeting: "*looks up* Sit by the fire."
  color: "#d4a373"
  model: "dolphin3:8b"
  temperature: "0.9"
  max_tokens: "400"
  icon: "avatars/aria-icon.png"

(see bots/README.txt for the full field list)

chat controls: under your last message -> edit / delete.
under the bot's last reply -> copy / redo / continue.
send becomes stop while a reply is streaming.

--- pictures (vision models) ---

the paperclip next to the input box attaches photos - up to 4 per
message, auto-shrunk to 1280px so phone pics stay light. you can also
paste (ctrl+v) or drag them in. the button only shows when the picked
model can actually see (llava, minicpm-v, moondream, gemma... - ollama
reports this itself). dolphin3 and most text models are blind, so
nothing changes for them: the server strips the pictures before they
reach a blind model, and keeps them saved in the chat for when you
switch back to a vision one.

--- v2.1: knowledge files + model maker ---

knowledge files (bot menu -> edit -> "+ add files"):
  attach text files (txt, md, py, json, csv, html ... not pdf - run
  "pdftotext file.pdf" first) and the bot reads them when it answers.
  - small pile (under ~6000 chars total): everything goes in the prompt
  - bigger pile: files are cut into chunks and the best matches for your
    last two messages are picked (keyword scoring, no extra software)
  - chunks per reply is adjustable (default 4, max 12)
  - files live in knowledge/<bot>/ - drop files there by hand if you like
  - the context window is raised to 4096 automatically when knowledge is
    used (set num_ctx yourself to override). more context = more ram
  - duplicating a bot copies its files, deleting a bot deletes them

model maker (bot form -> "model maker" section, all optional):
  style        character (roleplay) or assistant (tutor/coder: no forced
               in-character rules)
  system       your own system prompt, replaces the auto-built one
  examples     sample dialogue so the model copies the voice
  top_p, top_k, repeat_penalty, num_ctx, seed, stop (separate with |)
  "download as an ollama Modelfile" bakes the bot into a real model:
      ollama create mybot -f mybot.Modelfile

new .ai fields: mode, system, examples, top_p, top_k, repeat_penalty,
num_ctx, seed, stop, knowledge_chunks. caution: a line inside a
multi-line value that starts with one of these field names plus a colon
(like "mode: ...") is read as a new field.

--- v2.2: phone-friendly + settings menu ---

phones / tablets:
  - menus slide up as bottom sheets with a sticky save/cancel bar
  - bigger tap targets, notch + landscape safe areas, no iOS zoom when
    you tap into a text box, keyboard no longer covers the chat
  - the top bar wraps: bot + buttons on row one, the model picker below
  - the "open on phone" button hides itself when you are on a phone

settings menu (gear button), three sections:
  this device   text size, message width, compact spacing, enter-key
                behaviour. stored in THIS browser only, so phone and pc
                can be set up differently
  theme         presets (fox, amoled, light, catppuccin, gruvbox,
                dracula), a color picker for every color, font, base
                text size, bubble roundness. previews live, cancel undoes
                it. save writes config/theme.conf, so every device that
                opens the app gets the same look. "reset" clears it
  app           one-model-at-a-time, the pin lock + the terminal switch
                (config/settings.conf)
the settings menu only edits the active "key value" lines of theme.conf -
your comments and the commented presets stay untouched.

--- pin lock (optional, settings > app) ---

set a pin in settings > app and every page + api call needs an unlock,
on every device. what to know:

  - only a salted hash is stored - config/settings.conf grows three lines
    (pin_hash, pin_salt, pin_iters). the pin itself is never written down.
  - unlocking gives the device a session cookie (7 days). sessions live in
    memory: restarting the server signs every device out (unlock again).
  - while locked, the lock screen, the pwa manifest, sw.js and the icons
    stay reachable - everything else answers 401.
  - the lock screen rate-limits: 5 wrong tries from one ip = 30s wait.
  - changing the pin keeps other devices' sessions; to sign everything out
    at once, restart the server (or remove + set the pin and restart).

locked out? (the "?pin=off" recovery)
  1. stop the server (ctrl-c, or bash start.sh stop)
  2. open config/settings.conf and delete the pin_hash, pin_salt and
     pin_iters lines
  3. start again - the lock is gone. (tip: opening the app with ?pin=off
     on the url shows this hint on the lock screen.)

honest limits: the app talks plain http on your wifi, so this is casual
protection - it keeps flatmates, guests and drive-by lookers out of the
ui. it does NOT encrypt traffic; someone recording your wifi could still
read chats. want it tighter? BIND=127.0.0.1 bash start.sh (pc only), or
bash tunnel.sh for an https link when away from home.

curl for the new routes (pin "1234" as example):

  curl -i -c /tmp/ck.txt -X POST localhost:8788/api/pin/set \
       -d '{"pin":"1234"}'                       # set a pin (first time)
  curl -i localhost:8788/api/bots                # now 401 locked
  curl -i -c /tmp/ck.txt -X POST localhost:8788/api/unlock \
       -d '{"pin":"1234"}'                       # unlock, saves cookie
  curl -i -b /tmp/ck.txt localhost:8788/api/bots # works again
  curl -i -b /tmp/ck.txt -X POST localhost:8788/api/pin/change \
       -d '{"old":"1234","new":"5678"}'          # change (needs session)
  curl -i -b /tmp/ck.txt -X POST localhost:8788/api/pin/remove \
       -d '{"pin":"5678"}'                       # remove (needs session)

--- web terminal (optional - the + button left of the message bar, or settings > app) ---

a small console + file browser that runs on the machine the server runs
on - "ssh from the browser". open it with the + button at the left of the
message bar (it lives in settings > app too) - the + lands straight in
the file browser once the terminal is on. it stays OFF by default;
the switch is at the top of the terminal panel and writes  terminal on
into config/settings.conf (hand edits work the same, no restart needed).

what it does:
  - one shell command at a time, run in the project folder. output is
    capped, a command is killed after 120 seconds (long jobs want:
    nohup ollama pull big-model &). there is a stop button. one-tap
    presets for ollama list / ollama ps / files / disk / memory.
  - a file browser + plain-text editor that reaches your WHOLE home
    folder plus this project folder (the ~ button jumps home, blank
    means this project, absolute paths and .. work as long as they
    stay inside those two). edit text files up to 512kb; every save
    keeps the old copy next to the file as <file>.term-bak. server.py
    and index.html are write-locked here on purpose - edit those in a
    real editor and restart the server. binary files (photos, pdfs)
    refuse to open in the editor - the console handles those.
  - an import button on every file row: copies the file straight into
    the open bot's knowledge files - same rules as a browser upload
    (plain text, 2mb, 50 files per bot). no download-then-re-upload
    through the browser; the file never leaves the machine.

honest limits (read this part):
  - while the terminal is ON, anyone who can open the app can run
    anything on this machine. that is the point of a terminal - but it
    means: keep it off when you don't need it, and never expose this
    app to the public internet (tunnel.sh) with the terminal on.
  - when a pin is set, every terminal call must carry that pin too
    (type it once per visit in the panel). a borrowed browser session
    alone is then not enough to reach the shell, and wrong pins feed
    the same 5-strikes -> 30s lockout as the lock screen.

interactive programs (vim, top, a python repl) don't work - this is a
one-shot console, not a real tty. use  top -n 1 ,  python3 script.py ,
tail -n 50 logfile  - one command per run.

curl for the routes (terminal must be on; with a pin set add
"pin":"...." to every body):

  curl -s -X POST localhost:8788/api/terminal/state -d '{}'
  curl -s -X POST localhost:8788/api/terminal/enable -d '{"on":true}'
  curl -s -X POST localhost:8788/api/terminal/run -d '{"cmd":"echo hi"}'
  curl -s -X POST localhost:8788/api/terminal/stop -d '{}'
  curl -s -X POST localhost:8788/api/terminal/ls -d '{"path":"~"}'
  curl -s -X POST localhost:8788/api/terminal/read \
       -d '{"path":"~/notes/ideas.txt"}'
  curl -s -X POST localhost:8788/api/terminal/write \
       -d '{"path":"~/notes/todo.txt","text":"hello"}'
  curl -s -X POST localhost:8788/api/terminal/import \
       -d '{"path":"~/notes/lore.txt","bot":"aria.ai"}'

--- music player (the note button in the top bar) ---

a shuffle player for the songs in your Music folder (~/Music - the one
in your home directory; subfolders count as albums). press play and it
picks a random song; when a song ends the next random one starts by
itself; skip jumps straight to a different random song. play/pause,
skip, volume - that's the whole player. closing the panel keeps the
music going, and the note button glows while something plays.

formats: whatever your browser can decode - mp3, m4a/aac, ogg/opus,
flac, wav, webm audio. up to 2000 songs per scan.

honest notes:
  - read-only: it streams files out of ~/Music and touches nothing.
    every request is locked INSIDE that folder (realpath-checked), so
    "..", absolute paths and symlink tricks get refused - this stays a
    music player, not a file server for the disk.
  - with a pin set, the music routes are locked behind the session
    like every other api call - no extra pin typing needed.

curl for the routes:

  curl -s localhost:8788/api/music/list                # what it found
  curl -s -o /tmp/song.mp3 \
       "localhost:8788/api/music/file?id=song.mp3"     # stream one
  curl -s -H "Range: bytes=0-99" -o /tmp/piece \
       "localhost:8788/api/music/file?id=album/01%20song.mp3"


--- v4.2: fixes ---

  - terminal: "cd" now sticks. each command is its own shell, so the
    server tracks the working folder itself. the console starts in your
    home folder; cd, cd ~, cd .., cd -, cd /d D:\x, "cd x && cmd" all work
    and the prompt shows where you are. one-tap presets use windows
    commands (dir, tasklist, powershell) when the server runs on windows
  - the + button opens this device's file picker. pictures attach to the
    next message, .ai files become bots, text/code/csv files go into the
    open bot's knowledge. drag-drop does the same. the terminal + server
    file browser moved to the bots menu (">_ terminal") and settings > app
  - top bar: real svg icons (chats, bots, music, settings, phone) instead
    of symbol characters that some fonts draw as nothing, and a cleaner
    two-row layout on phones
  - phone: message box no longer clips its placeholder, tighter + / clip
    buttons, compact terminal button row
  - settings > app > "open the terminal" always jumped to the file
    browser (the click event was read as "go to files") - fixed
