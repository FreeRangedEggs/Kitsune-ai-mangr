#!/usr/bin/env bash
# if this got started by another shell (sh/dash/zsh), re-exec under bash -
# same reason as install.sh: parts below (process substitution) are bash-only.
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi
# ============================================================
# kitsune//ai-mangr - control the local ai chat server
#
#   bash start.sh          -> start (or restart) the web app (this pc only)
#   bash start.sh --lan    -> start it reachable from other devices on the wifi
#   bash start.sh warm     -> start it + load model into RAM now
#   bash start.sh warm m   -> same, but force a specific model
#   bash start.sh stop     -> stop it
#   bash start.sh status   -> running? ollama up? which ai models are installed?
#   bash start.sh uninstall -> remove the kitsune command (asks first)
#
# one address, always: the app claims port 8788 and KEEPS it. a stale
# copy of this app is stopped automatically; if some OTHER program owns
# the port, start fails loudly instead of quietly moving to a new port
# (a moving address breaks phone home-screen bookmarks - that's the
# whole point of the fixed port).
#
# phone on the same wifi: that is an explicit choice - bash start.sh --lan,
# or the setup wizard / settings > app toggle (needs a restart). the server
# warns at startup when the app is reachable from the network without a pin.
# away from home: bash tunnel.sh (temporary https url + QR).
# ============================================================
DIR="$(cd "$(dirname "$0")" && pwd)"
PID="$DIR/.server.pid"
LOG="$DIR/server.log"
PORT="${PORT:-8788}"
BIND="${BIND:-}"   # empty = the server decides (settings.conf lan switch, default 127.0.0.1)
OLLAMA="http://127.0.0.1:11434"

# the server is plain python. try python3 first, fall back to python
# (Windows Git Bash and some distros only ship the shorter name).
# empty means neither exists - start_server says so and gives up.
PY="$(command -v python3 2>/dev/null || command -v python 2>/dev/null || true)"

# the app binds 127.0.0.1 by default; --lan is the explicit opt-in
if [ "${1:-}" = "--lan" ]; then
  BIND="0.0.0.0"
  shift
fi

# --------------------------------------------------------------
# installed-model checks (all against ollama's own /api/tags)
# --------------------------------------------------------------

# is ollama answering at all?
ollama_up() { curl -s --max-time 4 "$OLLAMA/api/tags" >/dev/null 2>&1; }

# installed models as "name<TAB>bytes" lines; empty when ollama is down
# or has none. names and sizes are grepped separately and paired with
# paste - each field appears exactly once per model in /api/tags.
model_list() {
  local j
  j="$(curl -s --max-time 4 "$OLLAMA/api/tags" 2>/dev/null)"
  [ -n "$j" ] || return 0
  paste \
    <(printf '%s\n' "$j" | grep -o '"name": *"[^"]*"' | cut -d'"' -f4) \
    <(printf '%s\n' "$j" | grep -o '"size": *[0-9][0-9]*' | tr -dc '0-9\n') \
    2>/dev/null
}

# bytes -> human
human_size() {
  awk -v b="$1" 'BEGIN {
    if (b >= 1073741824) printf "%.1f GB", b / 1073741824
    else if (b >= 1048576) printf "%.0f MB", b / 1048576
    else printf "%d KB", int(b / 1024)
  }'
}

# the first bot that names a model: prints "<bot> <model>"; returns 1
# when no bot pins one (then the chat menu picks a model per chat)
default_model() {
  local f m
  for f in "$DIR"/bots/*.ai; do
    [ -f "$f" ] || continue
    m="$(sed -n 's/^model[[:space:]]*[=:][[:space:]]*//p' "$f" | head -n1 | tr -d '"\r')"
    if [ -n "$m" ]; then
      printf '%s %s\n' "$(basename "$f" .ai)" "$m"
      return 0
    fi
  done
  return 1
}

# is a model in ollama's list? bots may write the bare name where ollama
# lists it with :latest, so both count
model_installed() {
  local want="$1"
  model_list | cut -f1 | grep -qxF -e "$want" -e "$want:latest"
}

# one-line verdict used after start
model_check() {
  local M d name model
  if ! ollama_up; then
    echo "[ai-mangr] models    : ollama is not reachable - start it with: ollama serve"
    return 0
  fi
  M="$(model_list)"
  if [ -z "$M" ]; then
    echo "[ai-mangr] models    : none installed - get one with: ollama pull dolphin3:8b   (browse: ollama.com/library)"
    return 0
  fi
  if d="$(default_model)"; then
    name="${d%% *}"; model="${d#* }"
    if model_installed "$model"; then
      echo "[ai-mangr] models    : $(printf '%s\n' "$M" | wc -l | tr -d ' ') installed - bot '$name' uses '$model'"
    else
      echo "[ai-mangr] models    : bot '$name' wants '$model' - not installed. fix with: ollama pull $model"
    fi
  else
    echo "[ai-mangr] models    : $(printf '%s\n' "$M" | wc -l | tr -d ' ') installed - pick one in the chat menu"
  fi
}

# is the lan switch on in the app's settings.conf? (the wizard + settings write it)
lan_on() { grep -qix 'lan[[:space:]]*on' "$DIR/config/settings.conf" 2>/dev/null; }

is_up() { [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; }

stop_server() {
  if is_up; then
    kill "$(cat "$PID")" 2>/dev/null
    rm -f "$PID"
    echo "[ai-mangr] stopped"
  else
    rm -f "$PID"
    echo "[ai-mangr] was not running"
  fi
}

# pid listening on $PORT, empty if none (ss on debian, lsof/fuser as fallbacks)
port_pid() {
  local p
  p="$(ss -ltnp 2>/dev/null | grep "[:.]$PORT[[:space:]]" | grep -o 'pid=[0-9]*' | head -n1 | cut -d= -f2)"
  [ -z "$p" ] && p="$(lsof -t -iTCP:"$PORT" -sTCP:LISTEN 2>/dev/null | head -n1)"
  [ -z "$p" ] && p="$(fuser -n tcp "$PORT" 2>/dev/null | awk '{print $1}')"
  echo "$p"
}

# is the process on the port actually THIS app? probe its health endpoint
# instead of guessing from cmdline (works even if it was started from an
# old, since-moved copy of this folder)
port_is_kitsune() {
  local p="$1"
  curl -s --max-time 2 "http://127.0.0.1:$PORT/api/health" 2>/dev/null \
    | grep -q '"app":"kitsune//ai-mangr"'
}

# a stale copy of this app holding the port gets stopped (it would
# otherwise answer on the old code forever). anything else keeps the
# port - and the start below fails loudly rather than moving addresses.
free_port() {
  local p i
  p="$(port_pid)"
  [ -n "$p" ] || return 0
  if port_is_kitsune "$p"; then
    echo "[ai-mangr] a copy of this app is already on port $PORT (pid $p) - stopping it"
    kill "$p" 2>/dev/null
    for i in 1 2 3 4 5 6; do kill -0 "$p" 2>/dev/null || return 0; sleep 0.5; done
    kill -9 "$p" 2>/dev/null; sleep 0.5
  else
    echo "[ai-mangr] port $PORT is held by another program (pid $p) - not touching it"
  fi
}

lan_urls() {
  # best-effort LAN addresses for the phone (ipv4, private ranges)
  local ips=""
  if command -v hostname >/dev/null 2>&1; then
    ips="$(hostname -I 2>/dev/null)"
  fi
  [ -z "$ips" ] && ips="$(ip -4 -o addr show scope global 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | tr '\n' ' ')"
  for ip in $ips; do
    case "$ip" in
      10.*|192.168.*|172.1[6-9].*|172.2[0-9].*|172.3[01].*)
        echo "http://$ip:$PORT" ;;
    esac
  done
}

start_server() {
  if is_up; then
    echo "[ai-mangr] already running (pid $(cat "$PID")) - restarting"
    stop_server
  fi
  if [ -z "$PY" ]; then
    echo "[ai-mangr] FAILED to start - no python3 or python in your PATH."
    echo "[ai-mangr] install Python 3 first (Windows: python.org installer, tick 'Add python.exe to PATH'), then open a new terminal."
    exit 1
  fi
  free_port
  rm -f "$DIR/.port"   # stale port from a previous run must not fool us
  BIND="$BIND" PORT="$PORT" nohup "$PY" "$DIR/server.py" >> "$LOG" 2>&1 &
  NEWPID=$!
  echo $NEWPID > "$PID"
  # the server writes .port with the port it actually bound - wait for it,
  # then health check it. if the port was stolen the server refuses to
  # start (by design) and says so.
  ACT=""
  for i in $(seq 1 10); do
    kill -0 "$NEWPID" 2>/dev/null || break
    ACT="$(cat "$DIR/.port" 2>/dev/null | tr -cd '0-9')"
    [ -n "$ACT" ] && curl -s --max-time 2 "http://127.0.0.1:$ACT/api/health" 2>/dev/null | grep -q '"ok":true' && break
    ACT=""
    sleep 1
  done
  if [ -z "$ACT" ]; then
    if kill -0 "$NEWPID" 2>/dev/null; then
      kill "$NEWPID" 2>/dev/null; rm -f "$PID"
    fi
    echo "[ai-mangr] FAILED to start - last log lines:"
    tail -n 6 "$LOG"
    exit 1
  fi
  echo "[ai-mangr] running (pid $(cat "$PID"))"
  echo "[ai-mangr] on this pc : http://localhost:$ACT"
  FIRST=1
  if [ "$BIND" = "0.0.0.0" ] || lan_on; then
    for u in $(lan_urls); do
      [ $FIRST -eq 1 ] && { echo "[ai-mangr] from phone : $u   <- one address, always (same wifi)"; FIRST=0; } \
                        || echo "[ai-mangr]              $u"
    done
  fi
  if [ $FIRST -eq 1 ]; then
    if [ "$BIND" = "0.0.0.0" ] || lan_on; then
      echo "[ai-mangr] from phone : lan is on - no LAN ip found yet (connect to the network and restart)"
    else
      echo "[ai-mangr] from phone : off - this pc only (bash start.sh --lan to change)"
    fi
  fi
  if [ "$BIND" != "0.0.0.0" ] && ! lan_on; then
    echo "[ai-mangr] phone setup: --lan first; then open the url there -> share -> add to home screen"
  else
    echo "[ai-mangr] phone setup: open the url there -> share -> add to home screen"
  fi
  echo "[ai-mangr] the tap of the phone button in the app shows these + a QR code"
  echo "[ai-mangr] model     : loads on first message (30-60s) - or: bash start.sh warm"
  model_check
  echo "[ai-mangr] logs      : tail -f $LOG"
}

# the full ollama + models report, shared by status (both when the app
# is running and when it is not - model problems are worth reporting
# either way)
model_report() {
  if ollama_up; then
    echo "[ai-mangr] ollama: reachable"
    M="$(model_list)"
    if [ -n "$M" ]; then
      echo "[ai-mangr] installed models:"
      printf '%s\n' "$M" | while IFS=$'\t' read -r n s; do
        [ -n "$n" ] || continue
        echo "[ai-mangr]   - $n  ($(human_size "$s"))"
      done
    else
      echo "[ai-mangr] installed models: none"
      echo "[ai-mangr] get one with  : ollama pull dolphin3:8b   (browse: ollama.com/library)"
    fi
    if d="$(default_model)"; then
      name="${d%% *}"; model="${d#* }"
      if model_installed "$model"; then
        echo "[ai-mangr] bot '$name' wants '$model' - installed"
      else
        echo "[ai-mangr] bot '$name' wants '$model' - NOT installed. fix with: ollama pull $model"
      fi
    fi
    INRAM=$(curl -s --max-time 4 "$OLLAMA/api/ps" 2>/dev/null \
      | grep -o '"name":"[^"]*"' | cut -d'"' -f4 | paste -sd, -)
    echo "[ai-mangr] model in RAM: ${INRAM:-none (loads on first message)}"
  else
    echo "[ai-mangr] ollama: NOT reachable (start it: ollama serve)"
  fi
}

status_server() {
  local A P INRAM M d name model
  if is_up; then
    A="$(cat "$DIR/.port" 2>/dev/null | tr -cd '0-9')"
    A="${A:-$PORT}"
    echo "[ai-mangr] running (pid $(cat "$PID")) on http://localhost:$A"
    if [ "$BIND" = "0.0.0.0" ] || lan_on; then
      P=""
      for u in $(lan_urls); do echo "[ai-mangr] from phone : $u"; P=1; done
      [ -z "$P" ] && echo "[ai-mangr] from phone : lan is on - no LAN ip found yet"
    else
      echo "[ai-mangr] from phone : off - this pc only (bash start.sh --lan to change)"
    fi
    model_report
  else
    echo "[ai-mangr] not running"
    model_report
  fi
}

warm_model() {
  # model to warm: the argument, else the first bot that names one, else
  # dolphin3:8b
  M="$1"
  if [ -z "$M" ]; then
    M="$(default_model | awk '{print $2}')"
  fi
  [ -n "$M" ] || M="dolphin3:8b"
  if ! ollama_up; then
    echo "[ai-mangr] ollama not reachable - start it: ollama serve"
    exit 1
  fi
  if ! model_installed "$M"; then
    echo "[ai-mangr] $M is not installed - fix with: ollama pull $M"
    echo "[ai-mangr] (kitsune status lists every model that IS installed)"
    exit 1
  fi
  echo "[ai-mangr] warming $M into RAM (30-60s first time)..."
  R=$(curl -s --max-time 300 "$OLLAMA/api/generate" \
        -d "{\"model\":\"$M\",\"keep_alive\":-1}")
  if echo "$R" | grep -q '"error"'; then
    echo "[ai-mangr] warm failed: $(echo "$R" | head -c 200)"
    echo "[ai-mangr] fix with: ollama pull $M"
    exit 1
  fi
  if curl -s --max-time 5 "$OLLAMA/api/ps" | grep -q "\"name\":\"$M"; then
    echo "[ai-mangr] $M is in RAM - stays there until you stop it"
  else
    echo "[ai-mangr] warm request sent (verify with: bash start.sh status)"
  fi
}

case "$1" in
  ""|start|restart) start_server ;;
  warm)             is_up || start_server; warm_model "$2" ;;
  stop)             stop_server ;;
  status)           status_server ;;
  uninstall)        shift; exec bash "$DIR/uninstall.sh" "$@" ;;
  *) echo "usage: bash start.sh [--lan] [start|stop|status|warm [model]|uninstall]" ;;
esac
